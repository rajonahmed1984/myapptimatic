<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('title', 'MyApptimatic'); ?></title>
<?php if(!empty($portalBranding['favicon_url'])): ?>
    <link rel="icon" href="<?php echo e($portalBranding['favicon_url']); ?>">
<?php endif; ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>