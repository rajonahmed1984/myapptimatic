<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="bg-guest">
    <main class="min-h-screen px-6 py-12">
        <div class="mx-auto flex min-h-[70vh] max-w-6xl flex-col gap-10">
            <?php
                $wideForm = request()->routeIs('register');
            ?>
            <div class="w-full">
                <div class="mb-8 flex flex-wrap items-center justify-between border-b gap-4">
                    <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3">
                        <?php if(!empty($portalBranding['logo_url'])): ?>
                            <img src="<?php echo e($portalBranding['logo_url']); ?>" alt="Company logo" class="h-12 rounded-xl p-1">
                        <?php else: ?>
                            <div class="grid h-12 w-12 place-items-center rounded-xl bg-white/20 text-lg font-semibold text-white">Apptimatic</div>
                        <?php endif; ?>
                    </a>
                    <div class="text-sm text-slate-600">
                        <a href="<?php echo e(route('login')); ?>" class="text-teal-600 hover:text-teal-500">Sign in</a>
                        <span class="mx-2 text-slate-300">|</span>
                        <a href="<?php echo e(route('register')); ?>" class="text-teal-600 hover:text-teal-500">Register</a>
                    </div>
                </div>
                <div class="mx-auto w-full max-w-md <?php echo e($wideForm ? 'md:max-w-[50rem]' : ''); ?>">
                    <div class="card p-8">
                    <?php if($errors->any()): ?>
                        <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
                            <ul class="space-y-1">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('status')): ?>
                        <div class="mb-6 rounded-2xl border border-teal-200 bg-teal-50 p-4 text-sm text-teal-700">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <div class="mt-6 text-center text-xs text-slate-500">
                        Copyright © <?php echo e(now()->year); ?> <a href="https://apptimatic.com" class="font-semibold text-teal-600 hover:text-teal-500">Apptimatic</a>. All Rights Reserved.
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/layouts/guest.blade.php ENDPATH**/ ?>