<?php $__env->startSection('content'); ?>
    <div style="font-family:Arial, sans-serif;font-size:14px;line-height:1.6;color:#334155;">
        <?php echo $bodyHtml; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/emails/generic.blade.php ENDPATH**/ ?>