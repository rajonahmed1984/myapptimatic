<?php $__env->startSection('title', 'Edit Customer'); ?>
<?php $__env->startSection('page-title', 'Edit Customer'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card p-6">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <div class="section-label">Customer</div>
                <h1 class="mt-2 text-2xl font-semibold text-slate-900"><?php echo e($customer->name); ?></h1>
                <div class="mt-1 text-sm text-slate-500">Client ID: <?php echo e($customer->id); ?></div>
            </div>
            <div class="text-sm text-slate-600">
                <div>Status: <?php echo e(ucfirst($customer->status)); ?></div>
                <div>Created: <?php echo e($customer->created_at?->format($globalDateFormat) ?? '--'); ?></div>
            </div>
        </div>

        <?php echo $__env->make('admin.customers.partials.tabs', ['customer' => $customer, 'activeTab' => 'profile'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <form method="POST" action="<?php echo e(route('admin.customers.update', $customer)); ?>" class="mt-6 space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="grid gap-4 md:grid-cols-2">
                <div>
                    <label class="text-sm text-slate-600">Name</label>
                    <input name="name" value="<?php echo e(old('name', $customer->name)); ?>" required class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm" />
                </div>
                <div>
                    <label class="text-sm text-slate-600">Company Name</label>
                    <input name="company_name" value="<?php echo e(old('company_name', $customer->company_name)); ?>" class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm" />
                </div>
                <div>
                    <label class="text-sm text-slate-600">Email</label>
                    <input name="email" type="email" value="<?php echo e(old('email', $customer->email)); ?>" class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm" />
                </div>
                <div>
                    <label class="text-sm text-slate-600">Phone</label>
                    <input name="phone" value="<?php echo e(old('phone', $customer->phone)); ?>" class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm" />
                </div>                
                <div>
                    <label class="text-sm text-slate-600">Address</label>
                    <textarea name="address" rows="2" class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm"><?php echo e(old('address', $customer->address)); ?></textarea>
                </div>
                <div>
                    <label class="text-sm text-slate-600">Notes</label>
                    <textarea name="notes" rows="2" class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm"><?php echo e(old('notes', $customer->notes)); ?></textarea>
                </div>
                <div>
                    <label class="text-sm text-slate-600">Override access until</label>
                    <input name="access_override_until" type="date" value="<?php echo e(old('access_override_until', optional($customer->access_override_until)->format('Y-m-d'))); ?>" class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm" />
                </div>
                <div>
                    <label class="text-sm text-slate-600">Status</label>
                    <select name="status" class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm">
                        <option value="active" <?php if($customer->status === 'active'): echo 'selected'; endif; ?>>Active</option>
                        <option value="inactive" <?php if($customer->status === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="rounded-full bg-teal-500 px-5 py-2 text-sm font-semibold text-white">Update customer</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/admin/customers/edit.blade.php ENDPATH**/ ?>