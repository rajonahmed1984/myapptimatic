<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="bg-dashboard">
    <div class="min-h-screen md:flex">
        <aside class="sidebar hidden w-64 flex-col px-6 py-7 md:flex">
            <div class="flex items-center gap-3">
                <?php
                    $sidebarImage = $portalBranding['favicon_url'] ?? ($portalBranding['logo_url'] ?? null);
                ?>
                <?php if(!empty($sidebarImage)): ?>
                    <img src="<?php echo e($sidebarImage); ?>" alt="Brand mark" class="h-11 w-11 rounded-2xl bg-white p-1">
                <?php else: ?>
                    <div class="grid h-11 w-11 place-items-center rounded-2xl bg-white/10 text-lg font-semibold text-white">LM</div>
                <?php endif; ?>
                <div>
                    <div class="text-xs uppercase tracking-[0.35em] text-slate-400">Admin</div>
                    <div class="text-lg font-semibold text-white"><?php echo e($portalBranding['company_name'] ?? 'License Portal'); ?></div>
                </div>
            </div>

            <?php ($invoiceMenuActive = request()->routeIs('admin.invoices.*')); ?>
            <?php ($logMenuActive = request()->routeIs('admin.logs.*')); ?>
            <nav class="mt-10 space-y-2 text-sm">
                <a class="<?php echo e(request()->routeIs('admin.dashboard') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Dashboard
                </a>
                <a class="<?php echo e(request()->routeIs('admin.customers.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.customers.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Customers
                </a>
                <a class="<?php echo e(request()->routeIs('admin.products.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.products.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Products
                </a>
                <a class="<?php echo e(request()->routeIs('admin.plans.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.plans.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Plans
                </a>
                <a class="<?php echo e(request()->routeIs('admin.orders.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.orders.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Orders
                </a>
                <a class="<?php echo e(request()->routeIs('admin.subscriptions.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.subscriptions.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Subscriptions
                </a>
                <a class="<?php echo e(request()->routeIs('admin.licenses.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.licenses.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Licenses
                </a>
                <a class="<?php echo e(request()->routeIs('admin.invoices.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.invoices.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Invoices
                </a>
                <?php if($invoiceMenuActive): ?>
                    <div class="ml-6 space-y-1 text-xs text-slate-400">
                        <a href="<?php echo e(route('admin.invoices.index')); ?>" class="block <?php echo e(request()->routeIs('admin.invoices.index') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">All invoices</a>
                        <a href="<?php echo e(route('admin.invoices.paid')); ?>" class="block <?php echo e(request()->routeIs('admin.invoices.paid') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Paid</a>
                        <a href="<?php echo e(route('admin.invoices.unpaid')); ?>" class="block <?php echo e(request()->routeIs('admin.invoices.unpaid') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Unpaid</a>
                        <a href="<?php echo e(route('admin.invoices.overdue')); ?>" class="block <?php echo e(request()->routeIs('admin.invoices.overdue') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Overdue</a>
                        <a href="<?php echo e(route('admin.invoices.cancelled')); ?>" class="block <?php echo e(request()->routeIs('admin.invoices.cancelled') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Cancelled</a>
                        <a href="<?php echo e(route('admin.invoices.refunded')); ?>" class="block <?php echo e(request()->routeIs('admin.invoices.refunded') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Refunded</a>
                    </div>
                <?php endif; ?>
                <a class="<?php echo e(request()->routeIs('admin.payment-gateways.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.payment-gateways.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Payment Gateways
                </a>
                <a class="<?php echo e(request()->routeIs('admin.payment-proofs.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.payment-proofs.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    <span>Manual Payments</span>
                    <?php if(($adminHeaderStats['pending_manual_payments'] ?? 0) > 0): ?>
                        <span class="ml-auto rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700"><?php echo e($adminHeaderStats['pending_manual_payments']); ?></span>
                    <?php endif; ?>
                </a>
                <a class="<?php echo e(request()->routeIs('admin.accounting.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.accounting.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Accounting
                </a>
                <a class="<?php echo e(request()->routeIs('admin.support-tickets.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.support-tickets.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    <span>Support</span>
                    <?php if(($adminHeaderStats['tickets_waiting'] ?? 0) > 0): ?>
                        <span class="ml-auto rounded-full bg-rose-100 px-2 py-0.5 text-xs font-semibold text-rose-700"><?php echo e($adminHeaderStats['tickets_waiting']); ?></span>
                    <?php endif; ?>
                </a>
                <a class="<?php echo e(request()->routeIs('admin.requests.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.requests.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Requests
                </a>
                <a class="<?php echo e(request()->routeIs('admin.affiliates.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.affiliates.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Affiliates
                </a>
                <a class="<?php echo e(request()->routeIs('admin.profile.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.profile.edit')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Profile
                </a>
                <a class="<?php echo e(request()->routeIs('admin.admins.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.admins.index')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Admin Users
                </a>
                <a class="<?php echo e(request()->routeIs('admin.settings.*') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.settings.edit')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Settings
                </a>
                <a class="<?php echo e(request()->routeIs('admin.automation-status') ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.automation-status')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Automation Status
                </a>
                <a class="<?php echo e($logMenuActive ? 'nav-link nav-link-active' : 'nav-link'); ?>" href="<?php echo e(route('admin.logs.activity')); ?>">
                    <span class="h-2 w-2 rounded-full bg-current"></span>
                    Logs
                </a>
                <?php if($logMenuActive): ?>
                    <div class="ml-6 space-y-1 text-xs text-slate-400">
                        <a href="<?php echo e(route('admin.logs.activity')); ?>" class="block <?php echo e(request()->routeIs('admin.logs.activity') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Activity</a>
                        <a href="<?php echo e(route('admin.logs.admin')); ?>" class="block <?php echo e(request()->routeIs('admin.logs.admin') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Admin</a>
                        <a href="<?php echo e(route('admin.logs.module')); ?>" class="block <?php echo e(request()->routeIs('admin.logs.module') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Module</a>
                        <a href="<?php echo e(route('admin.logs.email')); ?>" class="block <?php echo e(request()->routeIs('admin.logs.email') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Email</a>
                        <a href="<?php echo e(route('admin.logs.ticket-mail-import')); ?>" class="block <?php echo e(request()->routeIs('admin.logs.ticket-mail-import') ? 'text-teal-300' : 'hover:text-slate-200'); ?>">Ticket Mail Import</a>
                    </div>
                <?php endif; ?>
            </nav>

            <div class="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4 text-xs text-slate-300">
                Billing cycle runs daily via scheduler. Verify task setup for production.
            </div>
        </aside>

        <div class="flex-1">
            <header class="sticky top-0 z-20 border-b border-slate-200/70 bg-white/80 backdrop-blur">
                <div class="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-4">
                    <div>
                        <div class="section-label">Admin workspace</div>
                        <div class="text-lg font-semibold text-slate-900"><?php echo $__env->yieldContent('page-title', 'Overview'); ?></div>
                    </div>
                    <?php if(!empty($adminHeaderStats)): ?>
                        <div class="stats hidden flex-wrap items-center gap-3 text-xs text-slate-500 lg:flex">
                            <a href="<?php echo e(route('admin.orders.index', ['status' => 'pending'])); ?>" class="flex items-center gap-2">
                                <span class="stat"><?php echo e($adminHeaderStats['pending_orders'] ?? 0); ?></span>
                                Pending Orders
                            </a>
                            <span class="text-slate-300">|</span>
                            <a href="<?php echo e(route('admin.invoices.overdue')); ?>" class="flex items-center gap-2">
                                <span class="stat"><?php echo e($adminHeaderStats['overdue_invoices'] ?? 0); ?></span>
                                Overdue Invoices
                            </a>
                            <span class="text-slate-300">|</span>
                            <a href="<?php echo e(route('admin.support-tickets.index', ['status' => 'customer_reply'])); ?>" class="flex items-center gap-2">
                                <span class="stat"><?php echo e($adminHeaderStats['tickets_waiting'] ?? 0); ?></span>
                                Ticket(s) Awaiting Reply
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="hidden items-center gap-4 md:flex">
                        <div class="text-right text-sm">
                            <div class="font-semibold text-slate-900"><?php echo e(auth()->user()->name); ?></div>
                            <div class="text-xs text-slate-500">Administrator</div>
                        </div>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="rounded-full border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 transition hover:border-teal-300 hover:text-teal-600">
                                Sign out
                            </button>
                        </form>
                    </div>
                </div>

                <div class="mx-auto flex max-w-6xl px-6 pb-4 md:hidden">
                    <details class="w-full rounded-2xl border border-slate-200 bg-white/90 p-4">
                        <summary class="cursor-pointer text-sm font-semibold text-slate-700">Menu</summary>
                        <nav class="mt-3 grid gap-2 text-sm">
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-slate-700 hover:text-teal-600">Dashboard</a>
                            <a href="<?php echo e(route('admin.automation-status')); ?>" class="text-slate-700 hover:text-teal-600">Automation Status</a>
                            <a href="<?php echo e(route('admin.customers.index')); ?>" class="text-slate-700 hover:text-teal-600">Customers</a>
                            <a href="<?php echo e(route('admin.products.index')); ?>" class="text-slate-700 hover:text-teal-600">Products</a>
                            <a href="<?php echo e(route('admin.plans.index')); ?>" class="text-slate-700 hover:text-teal-600">Plans</a>
                            <a href="<?php echo e(route('admin.subscriptions.index')); ?>" class="text-slate-700 hover:text-teal-600">Subscriptions</a>
                            <a href="<?php echo e(route('admin.orders.index')); ?>" class="text-slate-700 hover:text-teal-600">Orders</a>
                            <a href="<?php echo e(route('admin.licenses.index')); ?>" class="text-slate-700 hover:text-teal-600">Licenses</a>
                            <a href="<?php echo e(route('admin.invoices.index')); ?>" class="text-slate-700 hover:text-teal-600">Invoices</a>
                            <div class="grid gap-1 pl-3 text-xs text-slate-500">
                                <a href="<?php echo e(route('admin.invoices.index')); ?>" class="hover:text-teal-600">All invoices</a>
                                <a href="<?php echo e(route('admin.invoices.paid')); ?>" class="hover:text-teal-600">Paid</a>
                                <a href="<?php echo e(route('admin.invoices.unpaid')); ?>" class="hover:text-teal-600">Unpaid</a>
                                <a href="<?php echo e(route('admin.invoices.overdue')); ?>" class="hover:text-teal-600">Overdue</a>
                                <a href="<?php echo e(route('admin.invoices.cancelled')); ?>" class="hover:text-teal-600">Cancelled</a>
                                <a href="<?php echo e(route('admin.invoices.refunded')); ?>" class="hover:text-teal-600">Refunded</a>
                            </div>
                            <a href="<?php echo e(route('admin.payment-gateways.index')); ?>" class="text-slate-700 hover:text-teal-600">Payment Gateways</a>
                            <a href="<?php echo e(route('admin.payment-proofs.index')); ?>" class="flex items-center justify-between text-slate-700 hover:text-teal-600">
                                <span>Manual Payments</span>
                                <?php if(($adminHeaderStats['pending_manual_payments'] ?? 0) > 0): ?>
                                    <span class="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700"><?php echo e($adminHeaderStats['pending_manual_payments']); ?></span>
                                <?php endif; ?>
                            </a>
                            <a href="<?php echo e(route('admin.accounting.index')); ?>" class="text-slate-700 hover:text-teal-600">Accounting</a>
                            <a href="<?php echo e(route('admin.support-tickets.index')); ?>" class="text-slate-700 hover:text-teal-600">Support</a>
                            <a href="<?php echo e(route('admin.requests.index')); ?>" class="text-slate-700 hover:text-teal-600">Requests</a>
                            <a href="<?php echo e(route('admin.profile.edit')); ?>" class="text-slate-700 hover:text-teal-600">Profile</a>
                            <a href="<?php echo e(route('admin.admins.index')); ?>" class="text-slate-700 hover:text-teal-600">Admin Users</a>
                            <a href="<?php echo e(route('admin.settings.edit')); ?>" class="text-slate-700 hover:text-teal-600">Settings</a>
                            <a href="<?php echo e(route('admin.logs.activity')); ?>" class="text-slate-700 hover:text-teal-600">Activity Log</a>
                            <a href="<?php echo e(route('admin.logs.admin')); ?>" class="text-slate-700 hover:text-teal-600">Admin Log</a>
                            <a href="<?php echo e(route('admin.logs.module')); ?>" class="text-slate-700 hover:text-teal-600">Module Log</a>
                            <a href="<?php echo e(route('admin.logs.email')); ?>" class="text-slate-700 hover:text-teal-600">Email Message Log</a>
                            <a href="<?php echo e(route('admin.logs.ticket-mail-import')); ?>" class="text-slate-700 hover:text-teal-600">Ticket Mail Import Log</a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-left text-slate-700 hover:text-teal-600">Sign out</button>
                            </form>
                        </nav>
                    </details>
                </div>
            </header>

            <main class="mx-auto max-w-6xl px-6 py-10 fade-in">
                <?php if($errors->any()): ?>
                    <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
                        <ul class="space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(session('status')): ?>
                    <div class="mb-6 rounded-2xl border border-teal-200 bg-teal-50 p-4 text-sm text-teal-700">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/layouts/admin.blade.php ENDPATH**/ ?>