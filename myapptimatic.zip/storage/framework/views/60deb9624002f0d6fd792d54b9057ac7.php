<?php $__env->startSection('title', 'Admin Sign In'); ?>

<?php $__env->startSection('content'); ?>
    <div class="section-label">Admin login</div>
    <h2 class="mt-3 text-2xl font-semibold text-slate-900">Sign in to the control desk</h2>
    <p class="mt-2 text-sm text-slate-600">Manage products, plans, invoices, and customer access.</p>

    <?php if(session('status')): ?>
        <div class="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-700">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form class="mt-8 space-y-5" method="POST" action="<?php echo e(route('admin.login.attempt')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label class="text-sm text-slate-600">Email</label>
            <input
                type="email"
                name="email"
                value="<?php echo e(old('email')); ?>"
                required
                class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-800 focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-200"
            />
        </div>
        <div>
            <label class="text-sm text-slate-600">Password</label>
            <input
                type="password"
                name="password"
                required
                class="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-800 focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-200"
            />
        </div>
        <div class="flex items-center justify-between text-sm text-slate-500">
            <label class="flex items-center gap-2">
                <input type="checkbox" name="remember" class="rounded border-slate-300 text-teal-500 focus:ring-teal-200" />
                Remember me
            </label>
            <a href="<?php echo e(route('admin.password.request')); ?>" class="text-teal-600 hover:text-teal-500">Forgot password?</a>
        </div>
        <?php if(config('recaptcha.enabled') && config('recaptcha.site_key')): ?>
            <div class="flex justify-center">
                <div class="g-recaptcha" data-sitekey="<?php echo e(config('recaptcha.site_key')); ?>" data-action="ADMIN_LOGIN"></div>
            </div>
        <?php endif; ?>
        <button
            type="submit"
            class="w-full rounded-xl bg-teal-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-teal-500"
        >
            Sign in
        </button>
    </form>

    <p class="mt-6 text-xs text-slate-500">
        Client account? Use the <a href="<?php echo e(route('login')); ?>" class="font-semibold text-teal-600 hover:text-teal-500">client login</a>.
    </p>

    <?php if(config('recaptcha.enabled') && config('recaptcha.site_key')): ?>
        <script src="https://www.google.com/recaptcha/enterprise.js" async defer></script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/auth/admin-login.blade.php ENDPATH**/ ?>