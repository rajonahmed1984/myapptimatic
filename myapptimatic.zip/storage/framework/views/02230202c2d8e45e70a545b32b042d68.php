<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status', 'label' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status', 'label' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    use App\Support\StatusColorHelper;
    $colors = StatusColorHelper::getStatusColors($status);
    $displayLabel = $label ?? ucfirst(str_replace('_', ' ', $status));
?>

<div class="inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold <?php echo e($colors['bg']); ?> <?php echo e($colors['text']); ?>">
    <?php echo e($displayLabel); ?>

</div>
<?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/components/status-badge.blade.php ENDPATH**/ ?>