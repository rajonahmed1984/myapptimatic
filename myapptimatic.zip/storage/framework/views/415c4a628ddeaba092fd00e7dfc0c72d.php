<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('page-title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex items-center justify-between">
        <h1 class="text-2xl font-semibold text-slate-900">Customers</h1>
        <a href="<?php echo e(route('admin.customers.create')); ?>" class="rounded-full bg-teal-500 px-4 py-2 text-sm font-semibold text-white">New Customer</a>
    </div>

    <div class="card overflow-hidden">
        <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs uppercase tracking-[0.25em] text-slate-500">
                <tr>
                    <th class="px-4 py-3">Client ID</th>
                    <th class="px-4 py-3">Name</th>
                    <th class="px-4 py-3">Company Name</th>
                    <th class="px-4 py-3">Email</th>
                    <th class="px-4 py-3">Services</th>
                    <th class="px-4 py-3">Created</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b border-slate-100">
                        <td class="px-4 py-3 text-slate-500">
                            <a href="<?php echo e(route('admin.customers.show', $customer)); ?>" class="hover:text-teal-600"><?php echo e($customer->id); ?></a>
                        </td>
                        <td class="px-4 py-3 font-medium text-slate-900">
                            <a href="<?php echo e(route('admin.customers.show', $customer)); ?>" class="hover:text-teal-600"><?php echo e($customer->name); ?></a>
                        </td>
                        <td class="px-4 py-3 text-slate-500"><?php echo e($customer->company_name ?: '--'); ?></td>
                        <td class="px-4 py-3 text-slate-500"><?php echo e($customer->email); ?></td>
                        <td class="px-4 py-3 text-slate-500">
                            <?php echo e($customer->active_subscriptions_count); ?> (<?php echo e($customer->subscriptions_count); ?>)
                        </td>
                        <td class="px-4 py-3 text-slate-500"><?php echo e($customer->created_at?->format($globalDateFormat) ?? '--'); ?></td>
                        <td class="px-4 py-3">
                            <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $customer->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customer->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-right">
                            <div class="flex items-center justify-end gap-3">
                                <form method="POST" action="<?php echo e(route('admin.customers.destroy', $customer)); ?>" onsubmit="return confirm('Delete this customer? This will remove related subscriptions and invoices.');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-rose-600 hover:text-rose-500">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="px-4 py-6 text-center text-slate-500">No customers yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>