<?php
    $tabs = [
        ['key' => 'summary', 'label' => 'Summary', 'href' => route('admin.customers.show', $customer)],
        ['key' => 'profile', 'label' => 'Profile', 'href' => route('admin.customers.edit', $customer)],
        ['key' => 'services', 'label' => 'Products/Services', 'href' => route('admin.customers.show', ['customer' => $customer, 'tab' => 'services'])],
        ['key' => 'invoices', 'label' => 'Invoices', 'href' => route('admin.customers.show', ['customer' => $customer, 'tab' => 'invoices'])],
        ['key' => 'tickets', 'label' => 'Tickets', 'href' => route('admin.customers.show', ['customer' => $customer, 'tab' => 'tickets'])],
        ['key' => 'emails', 'label' => 'Emails', 'href' => route('admin.customers.show', ['customer' => $customer, 'tab' => 'emails'])],
        ['key' => 'log', 'label' => 'Log', 'href' => route('admin.customers.show', ['customer' => $customer, 'tab' => 'log'])],
    ];
?>

<div class="mt-6 flex flex-wrap gap-2 text-sm">
    <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php ($isActive = $activeTab === $item['key']); ?>
        <a href="<?php echo e($item['href']); ?>" class="rounded-full border px-4 py-2 <?php echo e($isActive ? 'border-teal-200 bg-teal-50 text-teal-600' : 'border-slate-200 text-slate-500 hover:text-teal-600'); ?>">
            <?php echo e($item['label']); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/admin/customers/partials/tabs.blade.php ENDPATH**/ ?>