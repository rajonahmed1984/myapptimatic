<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="bg-guest">
    <main class="min-h-screen px-6 py-12">
        <div class="mx-auto max-w-6xl">
            <div class="mb-8 flex flex-wrap items-center justify-between border-b gap-4">
                <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3">
                    <?php if(!empty($portalBranding['logo_url'])): ?>
                        <img src="<?php echo e($portalBranding['logo_url']); ?>" alt="Company logo" class="h-12 rounded-xl p-1">
                    <?php else: ?>
                        <div class="grid h-12 w-12 place-items-center rounded-xl bg-white/20 text-lg font-semibold text-white">Apptimatic</div>
                    <?php endif; ?>
                </a>
                <div class="text-sm text-slate-600">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(auth()->user()->isAdmin() ? route('admin.dashboard') : route('client.dashboard')); ?>" class="text-teal-600 hover:text-teal-500">Go to dashboard</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-teal-600 hover:text-teal-500">Sign in</a>
                        <span class="mx-2 text-slate-300">|</span>
                        <a href="<?php echo e(route('register')); ?>" class="text-teal-600 hover:text-teal-500">Register</a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($errors->any()): ?>
                <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
                    <ul class="space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('status')): ?>
                <div class="mb-6 rounded-2xl border border-teal-200 bg-teal-50 p-4 text-sm text-teal-700">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>

            <div class="mt-10 text-center text-xs text-slate-500">
                Copyright © <?php echo e(now()->year); ?> <a href="https://apptimatic.com" class="font-semibold text-teal-600 hover:text-teal-500">Apptimatic</a>. All Rights Reserved.
            </div>
        </div>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/layouts/public.blade.php ENDPATH**/ ?>