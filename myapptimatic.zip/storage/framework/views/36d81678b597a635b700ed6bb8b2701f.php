<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <div class="section-label">Products</div>
        <h1 class="mt-2 text-3xl font-semibold text-slate-900">Choose a service plan</h1>
        <p class="mt-2 text-sm text-slate-600">Browse available products and start your order.</p>
    </div>

    <?php if($products->isEmpty()): ?>
        <div class="card p-6 text-sm text-slate-600">No active products are available right now.</div>
    <?php else: ?>
        <div class="grid gap-6 md:grid-cols-2">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($minPrice = $product->plans->min('price')); ?>
                <div class="card p-6">
                    <div>
                        <div class="text-xl font-semibold text-slate-900"><?php echo e($product->name); ?></div>
                        <?php if($product->description): ?>
                            <p class="mt-2 text-sm text-slate-500"><?php echo e($product->description); ?></p>
                        <?php endif; ?>
                        <div class="mt-3 flex items-center justify-between gap-4">
                            <div class="text-sm text-slate-600">
                                <?php echo e($product->plans->count()); ?> plan(s)
                                <?php if($minPrice !== null): ?>
                                    <span class="mx-2 text-slate-300">|</span>
                                    Starts at <?php echo e($currency); ?> <?php echo e(number_format((float) $minPrice, 2)); ?>

                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('products.public.show', $product)); ?>" class="rounded-full border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600">View plans</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapptimatic\resources\views/public/products/index.blade.php ENDPATH**/ ?>