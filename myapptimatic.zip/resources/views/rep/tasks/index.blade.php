@extends('layouts.rep')

@section('title', 'Tasks')
@section('page-title', 'Tasks')

@section('content')
    @include('tasks.partials.index')
@endsection
