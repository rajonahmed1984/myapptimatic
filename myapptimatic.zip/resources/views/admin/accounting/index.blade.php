@extends('layouts.admin')

@section('title', $pageTitle)
@section('page-title', $pageTitle)

@section('content')
    <div class="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div class="flex-1">
            <form id="accountingSearchForm" method="GET" action="{{ url()->current() }}" class="flex items-center gap-3">
                <div class="relative w-full max-w-sm">
                    <input
                        type="text"
                        name="search"
                        value="{{ $search ?? request('search') }}"
                        placeholder="Search entries..."
                        class="w-full rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm"
                        hx-get="{{ url()->current() }}"
                        hx-trigger="keyup changed delay:300ms"
                        hx-target="#accountingTable"
                        hx-swap="outerHTML"
                        hx-push-url="true"
                        hx-include="#accountingSearchForm"
                    />
                </div>
            </form>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <a href="{{ route('admin.accounting.create', ['type' => 'payment']) }}" class="rounded-full bg-teal-500 px-4 py-2 text-sm font-semibold text-white">New Payment</a>
            <a href="{{ route('admin.accounting.create', ['type' => 'refund']) }}" class="rounded-full border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600">New Refund</a>
            <a href="{{ route('admin.accounting.create', ['type' => 'credit']) }}" class="rounded-full border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600">New Credit</a>
            <a href="{{ route('admin.accounting.create', ['type' => 'expense']) }}" class="rounded-full border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600">New Expense</a>
        </div>
    </div>
{{-- 
    <div class="mb-6 flex flex-wrap gap-2 text-sm">
        <a href="{{ route('admin.accounting.index') }}" class="{{ $scope === 'ledger' ? 'rounded-full bg-slate-900 px-4 py-2 font-semibold text-white' : 'rounded-full border border-slate-300 px-4 py-2 font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600' }}">Ledger</a>
        <a href="{{ route('admin.accounting.transactions') }}" class="{{ $scope === 'transactions' ? 'rounded-full bg-slate-900 px-4 py-2 font-semibold text-white' : 'rounded-full border border-slate-300 px-4 py-2 font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600' }}">Transactions</a>
        <a href="{{ route('admin.accounting.refunds') }}" class="{{ $scope === 'refunds' ? 'rounded-full bg-slate-900 px-4 py-2 font-semibold text-white' : 'rounded-full border border-slate-300 px-4 py-2 font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600' }}">Refunds</a>
        <a href="{{ route('admin.accounting.credits') }}" class="{{ $scope === 'credits' ? 'rounded-full bg-slate-900 px-4 py-2 font-semibold text-white' : 'rounded-full border border-slate-300 px-4 py-2 font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600' }}">Credits</a>
        <a href="{{ route('admin.accounting.expenses') }}" class="{{ $scope === 'expenses' ? 'rounded-full bg-slate-900 px-4 py-2 font-semibold text-white' : 'rounded-full border border-slate-300 px-4 py-2 font-semibold text-slate-600 hover:border-teal-300 hover:text-teal-600' }}">Expenses</a>
    </div> --}}

    @include('admin.accounting.partials.table', ['entries' => $entries])
@endsection
