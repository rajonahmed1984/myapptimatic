<div class="mt-4">{{ $expenses->links() }}</div>
