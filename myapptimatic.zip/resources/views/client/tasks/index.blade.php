@extends('layouts.client')

@section('title', 'Tasks')
@section('page-title', 'Tasks')

@section('content')
    @include('tasks.partials.index')
@endsection
