<?php

return [
    'enabled' => env('TASK_STATUS_EMAILS', true),
];
