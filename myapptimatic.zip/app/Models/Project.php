<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Enums\Role;
use App\Models\Employee;
use App\Models\SalesRepresentative;
use App\Models\User;
use App\Models\ProjectOverhead;

class Project extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'customer_id',
        'order_id',
        'subscription_id',
        'advance_invoice_id',
        'final_invoice_id',
        'name',
        'type',
        'status',
        'start_date',
        'expected_end_date',
        'due_date',
        'description',
        'notes',
        'total_budget',
        'initial_payment_amount',
        'currency',
        'sales_rep_ids',
        'budget_amount',
        'software_overhead',
        'website_overhead',
        'contract_file_path',
        'contract_original_name',
        'proposal_file_path',
        'proposal_original_name',
        'contract_amount',
        'contract_employee_total_earned',
        'contract_employee_payable',
        'contract_employee_payout_status',
        'contract_employee_payout_reference',
    ];

    protected $casts = [
        'start_date' => 'date',
        'expected_end_date' => 'date',
        'due_date' => 'date',
        'total_budget' => 'decimal:2',
        'initial_payment_amount' => 'decimal:2',
        'budget_amount' => 'decimal:2',
        'software_overhead' => 'decimal:2',
        'website_overhead' => 'decimal:2',
        'sales_rep_ids' => 'array',
        'contract_amount' => 'decimal:2',
        'contract_employee_total_earned' => 'decimal:2',
        'contract_employee_payable' => 'decimal:2',
    ];

    protected static function booted(): void
    {
        static::deleting(function (Project $project): void {
            if ($project->isForceDeleting()) {
                $project->maintenances()->forceDelete();
            } else {
                $project->maintenances()->delete();
            }
        });
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    public function advanceInvoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class, 'advance_invoice_id');
    }

    public function finalInvoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class, 'final_invoice_id');
    }

    public function tasks(): HasMany
    {
        return $this->hasMany(ProjectTask::class);
    }

    public function subtasks(): HasManyThrough
    {
        return $this->hasManyThrough(
            ProjectTaskSubtask::class,
            ProjectTask::class,
            'project_id',
            'project_task_id',
            'id',
            'id'
        );
    }

    public function messages(): HasMany
    {
        return $this->hasMany(ProjectMessage::class);
    }

    public function maintenances(): HasMany
    {
        return $this->hasMany(ProjectMaintenance::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(\App\Models\Invoice::class);
    }

    public function projectClients(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'project_user')
            ->where('role', Role::CLIENT_PROJECT)
            ->withTimestamps();
    }

    public function overheads(): HasMany
    {
        return $this->hasMany(ProjectOverhead::class);
    }

    public function employees()
    {
        return $this->belongsToMany(Employee::class, 'employee_project')->withTimestamps();
    }

    public function salesRepresentatives()
    {
        return $this->belongsToMany(SalesRepresentative::class, 'project_sales_representative')
            ->withPivot('amount')
            ->withTimestamps();
    }

    public function getSalesRepTotalAttribute(): float
    {
        return (float) $this->salesRepresentatives
            ->sum(fn ($rep) => (float) ($rep->pivot?->amount ?? 0));
    }

    public function getOverheadTotalAttribute(): float
    {
        $relationTotal = (float) $this->overheads
            ->sum(fn ($overhead) => (float) ($overhead->amount ?? 0));

        return $relationTotal + $this->getColumnOverheadTotal();
    }

    private function getColumnOverheadTotal(): float
    {
        return (float) ($this->software_overhead ?? 0) + (float) ($this->website_overhead ?? 0);
    }

    public function getRemainingBudgetAttribute(): ?float
    {
        if ($this->total_budget === null) {
            return null;
        }

        $budgetWithOverhead = (float) $this->total_budget + $this->overhead_total;
        $initialPayment = (float) ($this->initial_payment_amount ?? 0);

        return $budgetWithOverhead - $initialPayment;
    }
}
