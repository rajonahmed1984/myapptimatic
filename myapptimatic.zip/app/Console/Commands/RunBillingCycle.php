<?php

namespace App\Console\Commands;

use App\Models\Invoice;
use App\Models\License;
use App\Models\Setting;
use App\Models\Subscription;
use App\Jobs\SendCronSummaryEmail;
use App\Jobs\SendInvoiceReminderNotification;
use App\Jobs\SendLicenseExpiryNoticeNotification;
use App\Jobs\SendTicketAdminReminderNotification;
use App\Jobs\SendTicketAutoCloseNotification;
use App\Jobs\SendTicketFeedbackNotification;
use App\Services\BillingService;
use App\Services\MaintenanceBillingService;
use App\Services\StatusUpdateService;
use App\Models\SupportTicket;
use App\Support\SystemLogger;
use Carbon\Carbon;
use Illuminate\Console\Command;

class RunBillingCycle extends Command
{
    protected $signature = 'billing:run';

    protected $description = 'Generate invoices, mark overdue, apply late fees, and run automation.';

    public function __construct(
        private BillingService $billingService,
        private MaintenanceBillingService $maintenanceBillingService,
        private StatusUpdateService $statusUpdateService
    )
    {
        parent::__construct();
    }

    public function handle(): int
    {
        // Long-running process: start from whatever the settings table says now,
        // not from a cache a previous command in this worker filled.
        Setting::flushCache();

        $startedAt = Carbon::now();
        Setting::setValue('billing_last_started_at', $startedAt->toDateTimeString());
        Setting::setValue('billing_last_status', 'running');
        Setting::setValue('billing_last_error', '');
        $metrics = $this->emptyMetrics();
        $stepErrors = [];

        SystemLogger::write('module', 'Billing run started.', [
            'started_at' => $startedAt->toDateTimeString(),
        ]);

        try {
            $today = Carbon::today();

            $runStep = function (string $step, callable $fn) use (&$metrics, &$stepErrors) {
                try {
                    return $fn();
                } catch (\Throwable $e) {
                    $stepErrors[$step] = $e->getMessage();
                    SystemLogger::write('module', 'Billing step failed.', [
                        'step' => $step,
                        'error' => $e->getMessage(),
                    ], level: 'error');

                    return null;
                }
            };

            $invoiceMetrics = $runStep('generate_invoices', fn () => $this->generateInvoices($today));
            if ($invoiceMetrics) {
                $metrics['invoices_generated'] = $invoiceMetrics['generated'];
                $metrics['fixed_term_terminations'] = $invoiceMetrics['fixed_term_terminations'];
            }

            $maintenanceMetrics = $runStep('maintenance_invoices', fn () => $this->maintenanceBillingService->generateInvoicesForDueMaintenances($today));
            if ($maintenanceMetrics) {
                $metrics['maintenance_invoices_generated'] = $maintenanceMetrics['generated'];
                $metrics['maintenance_invoices_skipped'] = $maintenanceMetrics['skipped'];
            }

            $metrics['invoices_overdue'] = $runStep('invoices_overdue', fn () => $this->statusUpdateService->updateInvoiceOverdueStatus($today)) ?? 0;
            $metrics['late_fees_added'] = $runStep('late_fees', fn () => $this->applyLateFees($today)) ?? 0;
            $metrics['auto_cancellations'] = $runStep('auto_cancellations', fn () => $this->applyAutoCancellation($today)) ?? 0;
            $metrics['suspensions'] = $runStep('suspensions', fn () => $this->statusUpdateService->updateSubscriptionSuspensionStatus($today)) ?? 0;
            $metrics['terminations'] = $runStep('terminations', fn () => $this->statusUpdateService->updateSubscriptionTerminationStatus($today)) ?? 0;
            $metrics['unsuspensions'] = $runStep('unsuspensions', fn () => $this->statusUpdateService->updateSubscriptionUnsuspensionStatus()) ?? 0;
            $metrics['client_status_updates'] = $runStep('client_status_updates', fn () => $this->statusUpdateService->updateCustomerStatus()) ?? 0;
            $metrics['licenses_expired'] = $runStep('licenses_expired', fn () => $this->statusUpdateService->updateLicenseExpiryStatus($today)) ?? 0;
            $metrics['invoice_reminders_sent'] = $runStep('invoice_reminders', fn () => $this->sendInvoiceReminders($today)) ?? 0;
            $metrics['ticket_auto_closed'] = $runStep('ticket_auto_close', fn () => $this->statusUpdateService->updateSupportTicketAutoCloseStatus($today)) ?? 0;
            $metrics['ticket_admin_reminders'] = $runStep('ticket_admin_reminders', fn () => $this->sendTicketAdminReminders($today)) ?? 0;
            $metrics['ticket_feedback_requests'] = $runStep('ticket_feedback', fn () => $this->sendTicketFeedbackRequests($today)) ?? 0;
            $metrics['license_expiry_notices'] = $runStep('license_expiry_notices', fn () => $this->sendLicenseExpiryNotices($today)) ?? 0;
            $metrics['tickets_deleted'] = $runStep('ticket_cleanup', fn () => $this->cleanupClosedTickets($today)) ?? 0;

            Setting::setValue('billing_last_run_at', Carbon::now()->toDateTimeString());
            Setting::setValue('billing_last_status', 'success');
            Setting::setValue('billing_last_metrics', json_encode($metrics));
            Setting::setValue('billing_last_error', $stepErrors ? json_encode($stepErrors) : '');

            $this->info('Billing run completed.');
            $this->sendCronSummary('success', $metrics, $startedAt, Carbon::now(), null);

            SystemLogger::write('module', 'Billing run completed.', [
                'started_at' => $startedAt->toDateTimeString(),
                'finished_at' => Carbon::now()->toDateTimeString(),
                'metrics' => [
                    'invoices_generated' => $metrics['invoices_generated'] ?? 0,
                    'invoices_overdue' => $metrics['invoices_overdue'] ?? 0,
                    'suspensions' => $metrics['suspensions'] ?? 0,
                    'terminations' => $metrics['terminations'] ?? 0,
                ],
            ]);

            return self::SUCCESS;
        } catch (\Throwable $e) {
            Setting::setValue('billing_last_run_at', Carbon::now()->toDateTimeString());
            Setting::setValue('billing_last_status', 'failed');
            Setting::setValue('billing_last_error', substr($e->getMessage(), 0, 500));
            Setting::setValue('billing_last_metrics', json_encode($metrics));

            $this->error('Billing run failed: ' . $e->getMessage());
            $this->sendCronSummary('failed', $metrics, $startedAt, Carbon::now(), $e->getMessage());

            SystemLogger::write('module', 'Billing run failed.', [
                'started_at' => $startedAt->toDateTimeString(),
                'error' => $e->getMessage(),
            ], level: 'error');

            return self::FAILURE;
        }
    }

    private function generateInvoices(Carbon $today): array
    {
        $count = 0;
        $fixedTermTerminations = 0;
        $isSqlite = \Illuminate\Support\Facades\DB::connection()->getDriverName() === 'sqlite';

        Subscription::query()
            ->with(['plan', 'customer'])
            ->whereIn('status', ['active', 'suspended'])
            ->where(function ($query) use ($today, $isSqlite) {
                $query->whereDate('next_invoice_at', '<=', $today->toDateString())
                    ->orWhere(function ($q) use ($today, $isSqlite) {
                        if ($isSqlite) {
                            $q->whereRaw("strftime('%d', next_invoice_at) = '01'")
                              ->whereRaw("date(next_invoice_at, '-10 days') <= ?", [$today->toDateString()]);
                        } else {
                            $q->whereRaw("DAY(next_invoice_at) = 1")
                              ->whereRaw("DATE_SUB(next_invoice_at, INTERVAL 10 DAY) <= ?", [$today->toDateString()]);
                        }
                    });
            })
            ->orderBy('id')
            ->chunkById(200, function ($subscriptions) use (&$count, &$fixedTermTerminations, $today) {
                foreach ($subscriptions as $subscription) {
                    // auto_renew=false must stop billing the same way cancel_at_period_end does —
                    // previously only cancel_at_period_end was honored here, so a subscription with
                    // auto_renew turned off kept being invoiced forever.
                    $stopsAtPeriodEnd = (bool) $subscription->cancel_at_period_end || ! $subscription->auto_renew;

                    if ($stopsAtPeriodEnd && $subscription->current_period_end->lessThanOrEqualTo($today)) {
                        $subscription->update([
                            'status' => 'cancelled',
                            'auto_renew' => false,
                        ]);
                        $fixedTermTerminations++;
                        continue;
                    }

                    if ($stopsAtPeriodEnd && $subscription->current_period_end->greaterThan($today)) {
                        $subscription->update([
                            'next_invoice_at' => $subscription->current_period_end->toDateString(),
                        ]);
                        continue;
                    }

                    $invoice = $this->billingService->generateInvoiceForSubscription($subscription, $today);
                    if ($invoice) {
                        $count++;
                    }
                }
            });

        return [
            'generated' => $count,
            'fixed_term_terminations' => $fixedTermTerminations,
        ];
    }

    private function applyLateFees(Carbon $today): int
    {
        $count = 0;
        $lateFeeDays = (int) Setting::getValue('late_fee_days');
        $lateFeeAmount = (float) Setting::getValue('late_fee_amount');
        $lateFeeType = Setting::getValue('late_fee_type');
        $now = Carbon::now();

        if ($lateFeeDays <= 0 || $lateFeeAmount <= 0) {
            return $count;
        }

        $targetDate = $today->copy()->subDays($lateFeeDays);

        Invoice::query()
            ->whereIn('status', ['unpaid', 'overdue'])
            ->whereNull('late_fee_applied_at')
            ->whereDate('due_date', '<=', $targetDate->toDateString())
            ->orderBy('id')
            ->chunkById(200, function ($invoices) use (&$count, $lateFeeType, $lateFeeAmount, $now) {
                foreach ($invoices as $invoice) {
                    $lateFee = $lateFeeType === 'percent'
                        ? ($invoice->subtotal * ($lateFeeAmount / 100))
                        : $lateFeeAmount;

                    if ($lateFee <= 0) {
                        continue;
                    }

                    $invoice->update([
                        'late_fee' => $invoice->late_fee + $lateFee,
                        'late_fee_applied_at' => $now,
                    ]);
                    app(\App\Services\InvoiceVatService::class)->applyToInvoice($invoice);
                    $count++;
                }
            });

        return $count;
    }

    private function applyAutoCancellation(Carbon $today): int
    {
        if (! Setting::getValue('enable_auto_cancellation')) {
            return 0;
        }

        $days = (int) Setting::getValue('auto_cancellation_days');

        // The shipped default is 0, which would write off every open invoice
        // due today or earlier the moment the toggle is switched on. Require a
        // deliberate, positive window.
        if ($days <= 0) {
            SystemLogger::write('module', 'Auto-cancellation skipped: auto_cancellation_days must be greater than zero.', [
                'auto_cancellation_days' => $days,
            ], level: 'warning');

            return 0;
        }

        $targetDate = $today->copy()->subDays($days);
        $count = 0;

        Invoice::query()
            ->whereIn('status', ['unpaid', 'overdue'])
            ->whereDate('due_date', '<=', $targetDate->toDateString())
            ->orderBy('id')
            ->chunkById(200, function ($invoices) use (&$count) {
                foreach ($invoices as $invoice) {
                    $previousStatus = (string) $invoice->status;
                    $invoice->update(['status' => 'cancelled']);

                    \App\Models\StatusAuditLog::logChange(
                        Invoice::class,
                        $invoice->id,
                        $previousStatus,
                        'cancelled',
                        'auto_cancellation'
                    );

                    $count++;
                }
            });

        return $count;
    }

    private function sendInvoiceReminders(Carbon $today): int
    {
        if (! Setting::getValue('payment_reminder_emails')) {
            return 0;
        }

        $sent = 0;

        $isSqlite = \Illuminate\Support\Facades\DB::connection()->getDriverName() === 'sqlite';
        $dayConditionRaw = $isSqlite ? "strftime('%d', due_date) = '01'" : "DAY(due_date) = 1";

        // Special reminders for invoices due on the 1st of the month
        Invoice::query()
            ->whereIn('status', ['unpaid', 'overdue'])
            ->whereRaw($dayConditionRaw)
            ->orderBy('id')
            ->chunk(100, function ($invoices) use ($today, &$sent) {
                foreach ($invoices as $invoice) {
                    $dueDate = Carbon::parse($invoice->due_date);
                    $issueDate = Carbon::parse($invoice->issue_date);
                    $needsReminder = false;
                    $sentColumn = null;

                    // 1. Created day reminder (10 days before due date, or the issue date)
                    if (is_null($invoice->reminder_created_day_sent_at)) {
                        $targetDate = $dueDate->copy()->subDays(10);
                        if ($today->isSameDay($targetDate) || $today->isSameDay($issueDate)) {
                            $needsReminder = true;
                            $sentColumn = 'reminder_created_day_sent_at';
                        }
                    }

                    // 2. 5 days before due date
                    if (!$needsReminder && is_null($invoice->reminder_5d_before_sent_at)) {
                        $targetDate = $dueDate->copy()->subDays(5);
                        if ($today->isSameDay($targetDate)) {
                            $needsReminder = true;
                            $sentColumn = 'reminder_5d_before_sent_at';
                        }
                    }

                    // 3. 3 days before due date
                    if (!$needsReminder && is_null($invoice->reminder_3d_before_sent_at)) {
                        $targetDate = $dueDate->copy()->subDays(3);
                        if ($today->isSameDay($targetDate)) {
                            $needsReminder = true;
                            $sentColumn = 'reminder_3d_before_sent_at';
                        }
                    }

                    // 4. 1 day before due date
                    if (!$needsReminder && is_null($invoice->reminder_1d_before_sent_at)) {
                        $targetDate = $dueDate->copy()->subDays(1);
                        if ($today->isSameDay($targetDate)) {
                            $needsReminder = true;
                            $sentColumn = 'reminder_1d_before_sent_at';
                        }
                    }

                    if ($needsReminder && $sentColumn) {
                        SendInvoiceReminderNotification::dispatch($invoice->id, 'invoice_payment_reminder');
                        $invoice->update([$sentColumn => Carbon::now()]);
                        $sent++;
                    }
                }
            });

        // Standard reminders (excluding 1st of the month invoices)
        $unpaidDays = (int) Setting::getValue('invoice_unpaid_reminder_days');
        if ($unpaidDays > 0) {
            $targetDate = $today->copy()->addDays($unpaidDays);
            $sent += $this->sendReminderBatch(
                $targetDate,
                'invoice_payment_reminder',
                'reminder_sent_at',
                ['unpaid']
            );
        }

        $firstDays = (int) Setting::getValue('first_overdue_reminder_days');
        if ($firstDays > 0) {
            $targetDate = $today->copy()->subDays($firstDays);
            $sent += $this->sendReminderBatch(
                $targetDate,
                'invoice_overdue_first_notice',
                'first_overdue_reminder_sent_at',
                ['unpaid', 'overdue']
            );
        }

        $secondDays = (int) Setting::getValue('second_overdue_reminder_days');
        if ($secondDays > 0) {
            $targetDate = $today->copy()->subDays($secondDays);
            $sent += $this->sendReminderBatch(
                $targetDate,
                'invoice_overdue_second_notice',
                'second_overdue_reminder_sent_at',
                ['unpaid', 'overdue']
            );
        }

        $thirdDays = (int) Setting::getValue('third_overdue_reminder_days');
        if ($thirdDays > 0) {
            $targetDate = $today->copy()->subDays($thirdDays);
            $sent += $this->sendReminderBatch(
                $targetDate,
                'invoice_overdue_third_notice',
                'third_overdue_reminder_sent_at',
                ['unpaid', 'overdue']
            );
        }

        return $sent;
    }

    private function sendTicketAdminReminders(Carbon $today): int
    {
        $days = (int) Setting::getValue('ticket_admin_reminder_days');
        if ($days <= 0) {
            return 0;
        }

        $threshold = $today->copy()->subDays($days)->endOfDay();
        $count = 0;
        $now = Carbon::now();

        SupportTicket::query()
            ->select('id')
            ->where('status', 'customer_reply')
            ->whereNotNull('last_reply_at')
            ->where('last_reply_at', '<=', $threshold)
            ->whereNull('admin_reminder_sent_at')
            ->orderBy('id')
            ->chunkById(200, function ($tickets) use (&$count, $now) {
                $ids = $tickets->pluck('id')->all();
                foreach ($ids as $ticketId) {
                    SendTicketAdminReminderNotification::dispatch($ticketId);
                }

                if (! empty($ids)) {
                    SupportTicket::query()
                        ->whereIn('id', $ids)
                        ->update(['admin_reminder_sent_at' => $now]);
                    $count += count($ids);
                }
            });

        return $count;
    }

    private function sendTicketFeedbackRequests(Carbon $today): int
    {
        $days = (int) Setting::getValue('ticket_feedback_days');
        if ($days <= 0) {
            return 0;
        }

        $threshold = $today->copy()->subDays($days)->endOfDay();
        $count = 0;
        $now = Carbon::now();

        SupportTicket::query()
            ->select('id')
            ->where('status', 'closed')
            ->whereNotNull('closed_at')
            ->where('closed_at', '<=', $threshold)
            ->whereNull('feedback_sent_at')
            ->orderBy('id')
            ->chunkById(200, function ($tickets) use (&$count, $now) {
                $ids = $tickets->pluck('id')->all();
                foreach ($ids as $ticketId) {
                    SendTicketFeedbackNotification::dispatch($ticketId);
                }

                if (! empty($ids)) {
                    SupportTicket::query()
                        ->whereIn('id', $ids)
                        ->update(['feedback_sent_at' => $now]);
                    $count += count($ids);
                }
            });

        return $count;
    }

    private function sendLicenseExpiryNotices(Carbon $today): int
    {
        $count = 0;
        $firstDays = (int) Setting::getValue('license_expiry_first_notice_days');
        $secondDays = (int) Setting::getValue('license_expiry_second_notice_days');
        $now = Carbon::now();

        if ($firstDays > 0) {
            $targetDate = $today->copy()->addDays($firstDays)->toDateString();
            License::query()
                ->select('id')
                ->where('status', 'active')
                ->whereDate('expires_at', $targetDate)
                ->whereNull('expiry_first_notice_sent_at')
                ->orderBy('id')
                ->chunkById(200, function ($licenses) use (&$count, $now) {
                    $ids = $licenses->pluck('id')->all();
                    foreach ($ids as $licenseId) {
                        SendLicenseExpiryNoticeNotification::dispatch($licenseId, 'license_expiry_notice');
                    }

                    if (! empty($ids)) {
                        License::query()
                            ->whereIn('id', $ids)
                            ->update(['expiry_first_notice_sent_at' => $now]);
                        $count += count($ids);
                    }
                });
        }

        if ($secondDays > 0) {
            $targetDate = $today->copy()->addDays($secondDays)->toDateString();
            License::query()
                ->select('id')
                ->where('status', 'active')
                ->whereDate('expires_at', $targetDate)
                ->whereNull('expiry_second_notice_sent_at')
                ->orderBy('id')
                ->chunkById(200, function ($licenses) use (&$count, $now) {
                    $ids = $licenses->pluck('id')->all();
                    foreach ($ids as $licenseId) {
                        SendLicenseExpiryNoticeNotification::dispatch($licenseId, 'license_expiry_notice');
                    }

                    if (! empty($ids)) {
                        License::query()
                            ->whereIn('id', $ids)
                            ->update(['expiry_second_notice_sent_at' => $now]);
                        $count += count($ids);
                    }
                });
        }

        License::query()
            ->select('id')
            ->where('status', 'active')
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', $today->toDateString())
            ->whereNull('expiry_expired_notice_sent_at')
            ->orderBy('id')
            ->chunkById(200, function ($licenses) use (&$count, $now) {
                $ids = $licenses->pluck('id')->all();
                foreach ($ids as $licenseId) {
                    SendLicenseExpiryNoticeNotification::dispatch($licenseId, 'license_expired_notice');
                }

                if (! empty($ids)) {
                    License::query()
                        ->whereIn('id', $ids)
                        ->update(['expiry_expired_notice_sent_at' => $now]);
                    $count += count($ids);
                }
            });

        return $count;
    }

    private function cleanupClosedTickets(Carbon $today): int
    {
        $days = (int) Setting::getValue('ticket_cleanup_days');
        if ($days <= 0) {
            return 0;
        }

        $threshold = $today->copy()->subDays($days)->toDateTimeString();

        return SupportTicket::query()
            ->where('status', 'closed')
            ->whereNotNull('closed_at')
            ->where('closed_at', '<=', $threshold)
            ->delete();
    }

    private function sendReminderBatch(
        Carbon $targetDate,
        string $templateKey,
        string $sentColumn,
        array $statuses
    ): int {
        $count = 0;
        $now = Carbon::now();

        $isSqlite = \Illuminate\Support\Facades\DB::connection()->getDriverName() === 'sqlite';
        $notDayConditionRaw = $isSqlite ? "strftime('%d', due_date) != '01'" : "DAY(due_date) != 1";

        Invoice::query()
            ->select('id')
            ->whereIn('status', $statuses)
            ->whereDate('due_date', $targetDate->toDateString())
            ->whereNull($sentColumn)
            ->whereRaw($notDayConditionRaw)
            ->orderBy('id')
            ->chunkById(200, function ($invoices) use (&$count, $templateKey, $sentColumn, $now) {
                $ids = $invoices->pluck('id')->all();
                foreach ($ids as $invoiceId) {
                    SendInvoiceReminderNotification::dispatch($invoiceId, $templateKey);
                }

                if (! empty($ids)) {
                    Invoice::query()
                        ->whereIn('id', $ids)
                        ->update([$sentColumn => $now]);
                    $count += count($ids);
                }
            });

        return $count;
    }

    private function emptyMetrics(): array
    {
        return [
            'invoices_generated' => 0,
            'maintenance_invoices_generated' => 0,
            'maintenance_invoices_skipped' => 0,
            'invoices_overdue' => 0,
            'late_fees_added' => 0,
            'auto_cancellations' => 0,
            'suspensions' => 0,
            'terminations' => 0,
            'unsuspensions' => 0,
            'client_status_updates' => 0,
            'invoice_reminders_sent' => 0,
            'ticket_auto_closed' => 0,
            'ticket_admin_reminders' => 0,
            'ticket_feedback_requests' => 0,
            'license_expiry_notices' => 0,
            'tickets_deleted' => 0,
            'fixed_term_terminations' => 0,
        ];
    }

    private function sendCronSummary(
        string $status,
        array $metrics,
        Carbon $startedAt,
        Carbon $finishedAt,
        ?string $errorMessage
    ): void {
        SendCronSummaryEmail::dispatch(
            $status,
            $metrics,
            $startedAt->toDateTimeString(),
            $finishedAt->toDateTimeString(),
            $errorMessage
        );
    }
}
