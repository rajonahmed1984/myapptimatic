<?php

namespace App\Policies;

use App\Models\ProjectTask;
use App\Models\User;
use App\Models\Employee;
use App\Models\SalesRepresentative;

class ProjectTaskPolicy
{
    public function view($actor, ProjectTask $task): bool
    {
        $project = $task->project;
        
        if (!$project) {
            return false;
        }

        if ($actor instanceof User) {
            if ($actor->isAdmin()) {
                return true;
            }

            // Check both regular clients and project-specific clients
            if ($actor->isClient() || $actor->isClientProject()) {
                // Check if user belongs to the project's customer
                if ($actor->customer_id !== $project->customer_id) {
                    return false;
                }
                
                // Project-specific users can view all tasks in their assigned project
                if ($actor->isClientProject() && $actor->project_id === $project->id) {
                    return true;
                }
                
                // Regular clients can only view tasks marked as customer_visible
                return $task->customer_visible;
            }

            if ($actor->isEmployee()) {
                $employeeId = $actor->employee?->id;
                return $employeeId && (
                    $project->employees()->whereKey($employeeId)->exists() ||
                    ($task->assigned_type === 'employee' && $task->assigned_id === $employeeId)
                );
            }

            if ($actor->isSales()) {
                $repId = SalesRepresentative::where('user_id', $actor->id)->value('id');
                return $repId && (
                    $project->salesRepresentatives()->whereKey($repId)->exists() ||
                    ($task->assigned_type === 'sales_rep' && $task->assigned_id === $repId)
                );
            }
        }

        if ($actor instanceof Employee) {
            return $project->employees()->whereKey($actor->id)->exists() ||
                ($task->assigned_type === 'employee' && $task->assigned_id === $actor->id);
        }

        return false;
    }

    public function create($actor, ProjectTask $task): bool
    {
        return $this->view($actor, $task);
    }

    public function update($actor, ProjectTask $task): bool
    {
        if (! $this->view($actor, $task)) {
            return false;
        }

        if ($actor instanceof User && $actor->isAdmin() && $actor->isMasterAdmin()) {
            return true;
        }

        if ($actor instanceof Employee) {
            if ($this->isEmployeeAssignee($task, $actor->id, $actor->user_id ?? null)) {
                return true;
            }
        }

        if ($actor instanceof User && $actor->isEmployee()) {
            $employeeId = $actor->employee?->id;
            if ($employeeId && $this->isEmployeeAssignee($task, $employeeId, $actor->id)) {
                return true;
            }
        }

        $actorId = $this->actorUserId($actor);
        return $actorId !== null && $task->created_by !== null && $task->created_by === $actorId;
    }

    public function delete($actor, ProjectTask $task): bool
    {
        if (! ($actor instanceof User)) {
            return false;
        }

        if ($actor->isSales()) {
            return false;
        }

        if ($actor->isMasterAdmin()) {
            return $this->view($actor, $task);
        }

        return false;
    }

    public function comment($actor, ProjectTask $task): bool
    {
        return $this->view($actor, $task);
    }

    public function upload($actor, ProjectTask $task): bool
    {
        return $this->comment($actor, $task);
    }

    private function actorUserId($actor): ?int
    {
        if ($actor instanceof User) {
            return $actor->id;
        }

        if ($actor instanceof Employee) {
            return $actor->user_id;
        }

        return null;
    }

    private function isEmployeeAssignee(ProjectTask $task, int $employeeId, ?int $userId = null): bool
    {
        if ($task->assigned_type === 'employee' && (int) $task->assigned_id === $employeeId) {
            return true;
        }

        if ($userId && (int) $task->assignee_id === $userId) {
            return true;
        }

        return $task->assignments()
            ->where('assignee_type', 'employee')
            ->where('assignee_id', $employeeId)
            ->exists();
    }
}
