<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AccountingEntry;
use App\Models\CommissionAuditLog;
use App\Models\CommissionPayout;
use App\Models\Customer;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\PaymentGateway;
use App\Models\PaymentMethod;
use App\Models\Project;
use App\Models\SalesRepresentative;
use App\Models\Setting;
use App\Models\TaxSetting;
use App\Services\AdminNotificationService;
use App\Services\BillingService;
use App\Services\ClientNotificationService;
use App\Services\CommissionService;
use App\Services\InvoicePaymentCompletionService;
use App\Services\InvoiceVatService;
use App\Services\SalesRepNotificationService;
use App\Support\AjaxResponse;
use App\Support\Branding;
use App\Support\SystemLogger;
use Carbon\Carbon;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response as InertiaResponse;

class InvoiceController extends Controller
{
    public function __construct(private BillingService $billingService) {}

    public function index()
    {
        return $this->listByStatus(null, 'All Invoices');
    }

    public function projectInvoices(Project $project)
    {
        return $this->listByStatus(null, 'Project Invoices: '.$project->name, $project);
    }

    public function create(Request $request): InertiaResponse
    {
        $customers = Customer::query()
            ->orderBy('name')
            ->get(['id', 'name', 'company_name', 'email']);

        $selectedCustomerId = $request->query('customer_id');
        $issueDate = now()->toDateString();
        $dueDays = (int) Setting::getValue('invoice_due_days', 0);
        $dueDate = $dueDays > 0 ? now()->addDays($dueDays)->toDateString() : $issueDate;

        return Inertia::render('Admin/Invoices/Create', [
            'pageTitle' => 'Create Invoice',
            'customers' => $customers->map(fn (Customer $customer) => [
                'id' => $customer->id,
                'name' => $customer->name,
                'company_name' => $customer->company_name,
                'email' => $customer->email,
                'label' => $this->customerLabel($customer),
            ])->values(),
            'form' => [
                'action' => route('admin.invoices.store'),
                'method' => 'POST',
                'fields' => [
                    'customer_id' => (string) old('customer_id', (string) ($selectedCustomerId ?? '')),
                    'issue_date' => (string) old('issue_date', $issueDate),
                    'due_date' => (string) old('due_date', $dueDate),
                    'notes' => (string) old('notes', ''),
                    'items' => collect(old('items', [['description' => '', 'quantity' => 1, 'unit_price' => 0]]))
                        ->map(fn ($item) => [
                            'description' => (string) ($item['description'] ?? ''),
                            'quantity' => (int) ($item['quantity'] ?? 1),
                            'unit_price' => (string) ($item['unit_price'] ?? 0),
                        ])
                        ->values(),
                ],
            ],
            'routes' => [
                'index' => route('admin.invoices.index'),
            ],
        ]);
    }

    public function store(Request $request, InvoiceVatService $vatService): RedirectResponse
    {
        $data = $request->validate([
            'customer_id' => ['required', 'exists:customers,id'],
            'issue_date' => ['required', 'date'],
            'due_date' => ['required', 'date', 'after_or_equal:issue_date'],
            'notes' => ['nullable', 'string'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.description' => ['required', 'string', 'max:255'],
            'items.*.quantity' => ['required', 'integer', 'min:1'],
            'items.*.unit_price' => ['required', 'numeric', 'min:0'],
        ]);

        $items = collect($data['items'])
            ->map(function ($item) {
                $quantity = (int) $item['quantity'];
                $unitPrice = (float) $item['unit_price'];

                return [
                    'description' => $item['description'],
                    'quantity' => $quantity,
                    'unit_price' => $unitPrice,
                    'line_total' => round($quantity * $unitPrice, 2),
                ];
            })
            ->values();

        $subtotal = (float) $items->sum('line_total');
        if ($subtotal <= 0) {
            return back()->withErrors(['items' => 'Invoice total must be greater than zero.'])->withInput();
        }

        $issueDate = Carbon::parse($data['issue_date']);
        $taxData = $vatService->calculateTotals($subtotal, 0.0, $issueDate);
        $currency = strtoupper((string) Setting::getValue('currency'));

        $invoice = DB::transaction(function () use ($data, $items, $subtotal, $taxData, $currency) {
            $invoice = Invoice::create([
                'customer_id' => $data['customer_id'],
                'number' => $this->billingService->nextInvoiceNumber(),
                'status' => 'unpaid',
                'issue_date' => $data['issue_date'],
                'due_date' => $data['due_date'],
                'subtotal' => $subtotal,
                'tax_rate_percent' => $taxData['tax_rate_percent'],
                'tax_mode' => $taxData['tax_mode'],
                'tax_amount' => $taxData['tax_amount'],
                'late_fee' => 0,
                'total' => $taxData['total'],
                'currency' => $currency,
                'notes' => $data['notes'] ?? null,
                'type' => 'manual',
            ]);

            foreach ($items as $item) {
                InvoiceItem::create([
                    'invoice_id' => $invoice->id,
                    'description' => $item['description'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'line_total' => $item['line_total'],
                ]);
            }

            return $invoice;
        });

        SystemLogger::write('activity', 'Manual invoice created.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'total' => $invoice->total,
            'currency' => $invoice->currency,
        ], $request->user()?->id, $request->ip());

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', 'Invoice created.');
    }

    public function paid()
    {
        return $this->listByStatus('paid', 'Paid Invoices');
    }

    public function unpaid()
    {
        return $this->listByStatus('unpaid', 'Unpaid Invoices');
    }

    public function overdue()
    {
        return $this->listByStatus('overdue', 'Overdue Invoices');
    }

    public function cancelled()
    {
        return $this->listByStatus('cancelled', 'Cancelled Invoices');
    }

    public function refunded()
    {
        return $this->listByStatus('refunded', 'Refunded Invoices');
    }

    public function show(Invoice $invoice): InertiaResponse
    {
        $invoice->load([
            'customer',
            'customer.defaultSalesRep:id,name,email,status',
            'items',
            'accountingEntries.paymentGateway',
            'subscription.salesRep:id,name,email,status',
            'orders.salesRep:id,name,email,status',
            'project.salesRepresentatives:id,name,email,status',
            'maintenance.salesRepresentatives:id,name,email,status',
            'maintenance.project.salesRepresentatives:id,name,email,status',
            'paymentProofs.paymentGateway',
            'paymentProofs.reviewer',
        ]);

        return Inertia::render('Admin/Invoices/Show', [
            'pageTitle' => 'Invoice Details',
            'invoice' => $this->serializeInvoiceDetails($invoice),
            'sales_rep_collection_options' => $this->invoiceSalesRepOptions($invoice)
                ->map(fn (SalesRepresentative $salesRep) => [
                    'id' => $salesRep->id,
                    'name' => $salesRep->name,
                    'email' => $salesRep->email,
                    'label' => trim($salesRep->name.' '.($salesRep->email ? '('.$salesRep->email.')' : '')),
                ])
                ->values()
                ->all(),
            'payment_methods' => PaymentMethod::commissionPayoutDropdownOptions()
                ->map(fn ($method) => ['code' => $method->code, 'name' => $method->name])
                ->values()
                ->all(),
            'payment_gateways' => PaymentGateway::query()
                ->orderBy('sort_order')
                ->orderBy('name')
                ->get(['id', 'name'])
                ->map(fn (PaymentGateway $gateway) => [
                    'id' => $gateway->id,
                    'name' => (string) $gateway->name,
                ])
                ->values()
                ->all(),
            'routes' => [
                'index' => route('admin.invoices.index'),
                'client_view' => route('admin.invoices.client-view', $invoice),
                'download' => route('admin.invoices.download', $invoice),
                'update' => route('admin.invoices.update', $invoice),
                'mark_paid' => route('admin.invoices.mark-paid', $invoice),
                'recalculate' => route('admin.invoices.recalculate', $invoice),
                'add_payment' => route('admin.invoices.add-payment', $invoice),
                'add_credit' => route('admin.invoices.add-credit', $invoice),
                'add_refund' => route('admin.invoices.add-refund', $invoice),
                'collect_by_sales_rep' => route('admin.invoices.collect-by-sales-rep', $invoice),
                'record_payment' => route('admin.accounting.create', [
                    'type' => 'payment',
                    'invoice_id' => $invoice->id,
                    'scope' => 'ledger',
                ]),
                'record_refund' => route('admin.accounting.create', [
                    'type' => 'refund',
                    'invoice_id' => $invoice->id,
                    'scope' => 'ledger',
                ]),
            ],
            'status_options' => ['unpaid', 'overdue', 'paid', 'cancelled', 'refunded'],
        ]);
    }

    public function clientView(Request $request, Invoice $invoice): InertiaResponse
    {
        return Inertia::render('Client/Invoices/Pay', $this->invoicePayProps($request, $invoice, 'admin.invoices.download'));
    }

    public function download(Invoice $invoice): Response
    {
        $invoice->load(['items', 'customer', 'subscription.plan.product', 'accountingEntries.paymentGateway']);

        $html = view('client.invoices.pdf', [
            'invoice' => $invoice,
            'payToText' => Setting::getValue('pay_to_text'),
            'companyEmail' => Setting::getValue('company_email'),
        ])->render();

        $pdf = app('dompdf.wrapper')->loadHTML($html);

        return $pdf->download('invoice-'.($invoice->number ?? $invoice->id).'.pdf');
    }

    public function markPaid(
        Request $request,
        Invoice $invoice,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications,
        CommissionService $commissionService,
        SalesRepNotificationService $salesRepNotifications
    ): RedirectResponse|JsonResponse {
        if (in_array((string) $invoice->status, ['cancelled', 'refunded'], true)) {
            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'Cancelled or refunded invoices cannot be marked as paid.');
        }

        $wasPaid = (string) $invoice->status === 'paid';

        // Marking an invoice paid by hand still has to leave a payment behind,
        // otherwise every outstanding-balance query keeps counting the full
        // amount as owed on an invoice the UI calls "paid".
        DB::transaction(function () use ($invoice, $wasPaid, $request) {
            if ($wasPaid) {
                return;
            }

            $settled = (float) AccountingEntry::query()
                ->where('invoice_id', $invoice->id)
                ->whereIn('type', ['payment', 'credit'])
                ->sum('amount');

            $outstanding = round(max(0, (float) $invoice->total - $settled), 2);

            if ($outstanding > 0.009) {
                AccountingEntry::create([
                    'entry_date' => Carbon::today()->toDateString(),
                    'type' => 'payment',
                    'amount' => $outstanding,
                    'currency' => (string) $invoice->currency,
                    'description' => 'Payment for invoice #'.(string) ($invoice->number ?? $invoice->id),
                    'reference' => (string) ($invoice->number ?? $invoice->id),
                    'customer_id' => $invoice->customer_id,
                    'invoice_id' => $invoice->id,
                    'payment_gateway_id' => null,
                    'created_by' => $request->user()?->id,
                    'metadata' => ['transaction_fee' => 0, 'source' => 'manual_mark_paid'],
                ]);
            }
        });

        if (! $wasPaid) {
            $this->runInvoicePaidPostProcessing(
                $request,
                $invoice,
                $adminNotifications,
                $clientNotifications,
                $commissionService,
                $salesRepNotifications,
                null,
                'manual_mark_paid'
            );
        }

        SystemLogger::write('activity', 'Invoice marked as paid.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
        ], $request->user()?->id, $request->ip());

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                route('admin.invoices.show', $invoice),
                'Invoice marked as paid.'
            );
        }

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', 'Invoice marked as paid.');
    }

    public function storePayment(
        Request $request,
        Invoice $invoice,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications,
        CommissionService $commissionService,
        SalesRepNotificationService $salesRepNotifications
    ): RedirectResponse {
        if (in_array((string) $invoice->status, ['cancelled', 'refunded'], true)) {
            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'Payment cannot be added to cancelled or refunded invoices.');
        }

        $data = $request->validate([
            'entry_date' => ['required', 'date'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'payment_gateway_id' => ['nullable', 'exists:payment_gateways,id'],
            'reference' => ['nullable', 'string', 'max:255'],
            'transaction_fee' => ['nullable', 'numeric', 'min:0'],
            'description' => ['nullable', 'string'],
        ]);

        $paymentAmount = round((float) $data['amount'], 2);
        $creditTotal = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'credit')
            ->sum('amount');
        $paidTotalBefore = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'payment')
            ->sum('amount');
        $outstandingBefore = round(max(0, (float) $invoice->total - ($paidTotalBefore + $creditTotal)), 2);

        if ($outstandingBefore <= 0) {
            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'Invoice has no outstanding balance.');
        }

        if ($paymentAmount > $outstandingBefore) {
            return back()
                ->withErrors(['amount' => 'Payment amount cannot exceed outstanding balance.'])
                ->withInput();
        }

        $reference = trim((string) ($data['reference'] ?? ''));
        $description = trim((string) ($data['description'] ?? ''));
        $gatewayId = isset($data['payment_gateway_id']) && $data['payment_gateway_id'] !== ''
            ? (int) $data['payment_gateway_id']
            : null;
        $previousStatus = (string) $invoice->status;

        // The gateway's cut does not reduce what the customer has settled — the
        // invoice is credited the full amount — but it has to be recorded so the
        // invoice can show what actually landed in the account.
        $transactionFee = round((float) ($data['transaction_fee'] ?? 0), 2);

        AccountingEntry::create([
            'entry_date' => Carbon::parse((string) $data['entry_date'])->toDateString(),
            'type' => 'payment',
            'amount' => $paymentAmount,
            'currency' => (string) $invoice->currency,
            'description' => $description !== '' ? $description : 'Payment for invoice #'.(string) ($invoice->number ?? $invoice->id),
            'reference' => $reference !== '' ? $reference : (string) ($invoice->number ?? $invoice->id),
            'customer_id' => $invoice->customer_id,
            'invoice_id' => $invoice->id,
            'payment_gateway_id' => $gatewayId,
            'created_by' => $request->user()?->id,
            'metadata' => [
                'transaction_fee' => $transactionFee,
                'net_amount' => round($paymentAmount - $transactionFee, 2),
            ],
        ]);

        $paidTotalAfter = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'payment')
            ->sum('amount');
        $outstandingAfter = round(max(0, (float) $invoice->total - ($paidTotalAfter + $creditTotal)), 2);
        $marksPaid = $outstandingAfter <= 0;

        if ($marksPaid && $previousStatus !== 'paid') {
            $this->runInvoicePaidPostProcessing(
                $request,
                $invoice,
                $adminNotifications,
                $clientNotifications,
                $commissionService,
                $salesRepNotifications,
                $reference !== '' ? $reference : null,
                'invoice_add_payment'
            );
        }

        SystemLogger::write('activity', $marksPaid ? 'Invoice payment added and marked paid.' : 'Invoice partial payment added.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'amount' => $paymentAmount,
            'outstanding_before' => $outstandingBefore,
            'outstanding_after' => $outstandingAfter,
            'currency' => $invoice->currency,
            'payment_gateway_id' => $gatewayId,
            'transaction_fee' => $transactionFee,
        ], $request->user()?->id, $request->ip());

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', $marksPaid ? 'Payment added and invoice marked as paid.' : 'Payment added. Invoice still has outstanding balance.');
    }

    public function storeCredit(
        Request $request,
        Invoice $invoice,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications,
        CommissionService $commissionService,
        SalesRepNotificationService $salesRepNotifications
    ): RedirectResponse {
        if (in_array((string) $invoice->status, ['cancelled', 'refunded'], true)) {
            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'Credit cannot be applied to cancelled or refunded invoices.');
        }

        $data = $request->validate([
            'entry_date' => ['required', 'date'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'reference' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $creditAmount = round((float) $data['amount'], 2);
        $paidTotal = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'payment')
            ->sum('amount');
        $creditTotalBefore = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'credit')
            ->sum('amount');
        $outstandingBefore = round(max(0, (float) $invoice->total - ($paidTotal + $creditTotalBefore)), 2);

        if ($outstandingBefore <= 0) {
            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'Invoice has no outstanding balance for additional credit.');
        }

        if ($creditAmount > $outstandingBefore) {
            return back()
                ->withErrors(['amount' => 'Credit amount cannot exceed outstanding balance.'])
                ->withInput();
        }

        $reference = trim((string) ($data['reference'] ?? ''));
        $description = trim((string) ($data['description'] ?? ''));
        $previousStatus = (string) $invoice->status;

        AccountingEntry::create([
            'entry_date' => Carbon::parse((string) $data['entry_date'])->toDateString(),
            'type' => 'credit',
            'amount' => $creditAmount,
            'currency' => (string) $invoice->currency,
            'description' => $description !== '' ? $description : 'Credit applied to invoice #'.(string) ($invoice->number ?? $invoice->id),
            'reference' => $reference !== '' ? $reference : 'credit-'.(string) ($invoice->number ?? $invoice->id),
            'customer_id' => $invoice->customer_id,
            'invoice_id' => $invoice->id,
            'payment_gateway_id' => null,
            'created_by' => $request->user()?->id,
        ]);

        $creditTotalAfter = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'credit')
            ->sum('amount');
        $outstandingAfter = round(max(0, (float) $invoice->total - ($paidTotal + $creditTotalAfter)), 2);
        $marksPaid = $outstandingAfter <= 0;

        if ($marksPaid && $previousStatus !== 'paid') {
            $this->runInvoicePaidPostProcessing(
                $request,
                $invoice,
                $adminNotifications,
                $clientNotifications,
                $commissionService,
                $salesRepNotifications,
                $reference !== '' ? $reference : null,
                'invoice_add_credit'
            );
        }

        SystemLogger::write('activity', $marksPaid ? 'Invoice credit added and marked paid.' : 'Invoice credit added.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'amount' => $creditAmount,
            'outstanding_before' => $outstandingBefore,
            'outstanding_after' => $outstandingAfter,
            'currency' => $invoice->currency,
        ], $request->user()?->id, $request->ip());

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', $marksPaid ? 'Credit applied and invoice marked as paid.' : 'Credit applied successfully.');
    }

    public function storeRefund(Request $request, Invoice $invoice): RedirectResponse
    {
        if (! in_array((string) $invoice->status, ['paid', 'refunded'], true)) {
            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'Refund can only be added for paid/refunded invoices.');
        }

        $data = $request->validate([
            'entry_date' => ['required', 'date'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'payment_gateway_id' => ['nullable', 'exists:payment_gateways,id'],
            'reference' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $refundAmount = round((float) $data['amount'], 2);
        $paidTotal = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'payment')
            ->sum('amount');
        $refundedTotalBefore = (float) AccountingEntry::query()
            ->where('invoice_id', $invoice->id)
            ->where('type', 'refund')
            ->sum('amount');
        $refundableBalance = round(max(0, $paidTotal - $refundedTotalBefore), 2);

        if ($refundableBalance <= 0) {
            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'No refundable payment balance found for this invoice.');
        }

        if ($refundAmount > $refundableBalance) {
            return back()
                ->withErrors(['amount' => 'Refund amount cannot exceed paid balance.'])
                ->withInput();
        }

        $reference = trim((string) ($data['reference'] ?? ''));
        $description = trim((string) ($data['description'] ?? ''));
        $gatewayId = isset($data['payment_gateway_id']) && $data['payment_gateway_id'] !== ''
            ? (int) $data['payment_gateway_id']
            : null;

        if ($gatewayId) {
            $gateway = PaymentGateway::find($gatewayId);
            if ($gateway && $gateway->driver === 'bkash_api') {
                $attempt = \App\Models\PaymentAttempt::where('invoice_id', $invoice->id)
                    ->where('payment_gateway_id', $gatewayId)
                    ->where('status', 'paid')
                    ->latest()
                    ->first();

                if (! $attempt) {
                    return back()
                        ->withErrors(['payment_gateway_id' => 'No paid bKash API payment record found for this invoice.'])
                        ->withInput();
                }

                $refundResult = app(\App\Services\PaymentService::class)->refundBkash($attempt, $refundAmount, $description ?: 'Refund');
                if ($refundResult['status'] === 'error') {
                    return back()
                        ->withErrors(['amount' => 'bKash live refund failed: '.$refundResult['message']])
                        ->withInput();
                }

                if (! empty($refundResult['refund_trx_id'])) {
                    $reference = $refundResult['refund_trx_id'];
                }
            }
        }

        AccountingEntry::create([
            'entry_date' => Carbon::parse((string) $data['entry_date'])->toDateString(),
            'type' => 'refund',
            'amount' => $refundAmount,
            'currency' => (string) $invoice->currency,
            'description' => $description !== '' ? $description : 'Refund for invoice #'.(string) ($invoice->number ?? $invoice->id),
            'reference' => $reference !== '' ? $reference : 'refund-'.(string) ($invoice->number ?? $invoice->id),
            'customer_id' => $invoice->customer_id,
            'invoice_id' => $invoice->id,
            'payment_gateway_id' => $gatewayId,
            'created_by' => $request->user()?->id,
        ]);

        SystemLogger::write('activity', 'Invoice refund recorded.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'amount' => $refundAmount,
            'refundable_balance_before' => $refundableBalance,
            'currency' => $invoice->currency,
            'payment_gateway_id' => $gatewayId,
        ], $request->user()?->id, $request->ip());

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', 'Refund recorded successfully.');
    }

    public function collectBySalesRep(
        Request $request,
        Invoice $invoice,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications,
        CommissionService $commissionService,
        SalesRepNotificationService $salesRepNotifications
    ): RedirectResponse|JsonResponse {
        $invoice->loadMissing([
            'customer.defaultSalesRep:id,name,email,status',
            'subscription.salesRep:id,name,email,status',
            'orders.salesRep:id,name,email,status',
            'project.salesRepresentatives:id,name,email,status',
            'maintenance.salesRepresentatives:id,name,email,status',
            'maintenance.project.salesRepresentatives:id,name,email,status',
            'accountingEntries',
        ]);

        if ($invoice->status === 'paid') {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('Invoice is already marked as paid.', 422);
            }

            return redirect()->route('admin.invoices.show', $invoice)
                ->with('error', 'Invoice is already marked as paid.');
        }

        if (! Schema::hasColumn('accounting_entries', 'metadata')) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('Collected-by-sales-rep flow requires the latest accounting entry migration.', 422);
            }

            return back()
                ->withErrors(['sales_rep_id' => 'Collected-by-sales-rep flow requires the latest accounting entry migration.'])
                ->withInput();
        }

        $data = $request->validate([
            'sales_rep_id' => ['required', 'integer'],
            'collected_amount' => ['required', 'numeric', 'min:0.01'],
            'reference' => ['nullable', 'string', 'max:255'],
            'note' => ['nullable', 'string'],
            'retained_amount' => ['nullable', 'numeric', 'min:0'],
            'payout_method' => ['nullable', Rule::in(PaymentMethod::allowedCommissionPayoutCodes())],
        ]);

        $salesRep = $this->invoiceSalesRepOptions($invoice)
            ->first(fn (SalesRepresentative $item) => $item->id === (int) $data['sales_rep_id']);

        if (! $salesRep) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('Select a valid sales representative for this invoice.', 422, [
                    'sales_rep_id' => ['Select a valid sales representative for this invoice.'],
                ]);
            }

            return back()
                ->withErrors(['sales_rep_id' => 'Select a valid sales representative for this invoice.'])
                ->withInput();
        }

        $creditTotal = (float) $invoice->accountingEntries->where('type', 'credit')->sum('amount');
        $paidTotal = (float) $invoice->accountingEntries->where('type', 'payment')->sum('amount');
        $outstandingAmount = round(max(0, (float) $invoice->total - ($paidTotal + $creditTotal)), 2);
        $paymentAmount = round((float) ($data['collected_amount'] ?? 0), 2);
        $retainedAmount = round((float) ($data['retained_amount'] ?? 0), 2);
        $reference = trim((string) ($data['reference'] ?? ''));
        $note = trim((string) ($data['note'] ?? ''));
        $payoutMethod = trim((string) ($data['payout_method'] ?? ''));

        if ($outstandingAmount <= 0) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('No payable amount remains on this invoice.', 422);
            }

            return back()->withErrors(['sales_rep_id' => 'No payable amount remains on this invoice.'])->withInput();
        }

        if ($paymentAmount > $outstandingAmount) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('Collected amount cannot exceed the outstanding invoice amount.', 422, [
                    'collected_amount' => ['Collected amount cannot exceed the outstanding invoice amount.'],
                ]);
            }

            return back()
                ->withErrors(['collected_amount' => 'Collected amount cannot exceed the outstanding invoice amount.'])
                ->withInput();
        }

        if ($retainedAmount > $paymentAmount) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('Retained amount cannot exceed the collected invoice amount.', 422, [
                    'retained_amount' => ['Retained amount cannot exceed the collected invoice amount.'],
                ]);
            }

            return back()
                ->withErrors(['retained_amount' => 'Retained amount cannot exceed the collected invoice amount.'])
                ->withInput();
        }

        if ($retainedAmount > 0 && ! Schema::hasColumn('commission_payouts', 'type')) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('Sales rep retained collection requires the latest commission payout migration.', 422, [
                    'retained_amount' => ['Sales rep retained collection requires the latest commission payout migration.'],
                ]);
            }

            return back()
                ->withErrors(['retained_amount' => 'Sales rep retained collection requires the latest commission payout migration.'])
                ->withInput();
        }

        $invoiceNumber = is_numeric($invoice->number) ? (string) $invoice->number : (string) $invoice->id;
        $previousStatus = (string) $invoice->status;
        $marksInvoicePaid = round($paymentAmount, 2) >= round($outstandingAmount, 2);

        DB::transaction(function () use (
            $request,
            $invoice,
            $salesRep,
            $paymentAmount,
            $paidTotal,
            $creditTotal,
            $outstandingAmount,
            $retainedAmount,
            $reference,
            $note,
            $payoutMethod,
            $invoiceNumber,
            $previousStatus,
            $marksInvoicePaid,
        ): void {
            AccountingEntry::create([
                'entry_date' => Carbon::today(),
                'type' => 'payment',
                'amount' => $paymentAmount,
                'currency' => (string) $invoice->currency,
                'description' => 'Collected by sales representative: '.$salesRep->name,
                'reference' => $reference !== '' ? $reference : 'sales-rep-collection-'.$invoiceNumber,
                'customer_id' => $invoice->customer_id,
                'invoice_id' => $invoice->id,
                'payment_gateway_id' => null,
                'created_by' => $request->user()?->id,
                'metadata' => [
                    'payment_mode' => 'sales_rep_collection',
                    'collected_by_sales_rep_id' => $salesRep->id,
                    'collected_by_sales_rep_name' => $salesRep->name,
                    'invoice_number' => $invoiceNumber,
                    'invoice_total' => (float) $invoice->total,
                    'paid_total_before_collection' => $paidTotal,
                    'credit_total' => $creditTotal,
                    'outstanding_before_collection' => $outstandingAmount,
                    'collected_amount' => $paymentAmount,
                    'retained_amount' => $retainedAmount,
                    'invoice_marked_paid' => $marksInvoicePaid,
                    'note' => $note !== '' ? $note : null,
                ],
            ]);

            if ($marksInvoicePaid) {
                $invoice->update([
                    'status' => 'paid',
                    'paid_at' => $invoice->paid_at ?? Carbon::now(),
                ]);

                \App\Models\StatusAuditLog::logChange(
                    Invoice::class,
                    $invoice->id,
                    $previousStatus,
                    'paid',
                    'sales_rep_collection',
                    $request->user()?->id,
                    [
                        'sales_rep_id' => $salesRep->id,
                        'sales_rep_name' => $salesRep->name,
                        'reference' => $reference !== '' ? $reference : null,
                        'collected_amount' => $paymentAmount,
                        'retained_amount' => $retainedAmount,
                    ]
                );
            }

            if ($retainedAmount <= 0) {
                return;
            }

            $payoutPayload = [
                'sales_representative_id' => $salesRep->id,
                'type' => 'advance',
                'total_amount' => $retainedAmount,
                'currency' => (string) $invoice->currency,
                'payout_method' => $payoutMethod !== '' ? $payoutMethod : null,
                'reference' => $reference !== '' ? $reference : 'invoice-'.$invoiceNumber.'-collection',
                'note' => $note !== '' ? $note : 'Retained from invoice collection.',
                'status' => 'paid',
                'paid_at' => Carbon::now(),
            ];

            if (Schema::hasColumn('commission_payouts', 'project_id')) {
                $payoutPayload['project_id'] = $invoice->project_id ?: $invoice->maintenance?->project_id;
            }

            $payout = CommissionPayout::create($payoutPayload);

            CommissionAuditLog::create([
                'sales_representative_id' => $salesRep->id,
                'commission_payout_id' => $payout->id,
                'action' => 'advance_payment',
                'status_from' => null,
                'status_to' => 'paid',
                'description' => 'Invoice collection retained by sales representative.',
                'metadata' => [
                    'amount' => $retainedAmount,
                    'currency' => (string) $invoice->currency,
                    'source_type' => 'invoice',
                    'source_id' => $invoice->id,
                    'source_label' => 'Invoice #'.$invoiceNumber.' collection',
                    'invoice_id' => $invoice->id,
                    'invoice_number' => $invoiceNumber,
                    'invoice_total' => (float) $invoice->total,
                    'collected_amount' => $paymentAmount,
                    'sales_rep_id' => $salesRep->id,
                    'sales_rep_name' => $salesRep->name,
                    'reference' => $reference !== '' ? $reference : null,
                    'note' => $note !== '' ? $note : null,
                ],
                'created_by' => $request->user()?->id,
            ]);
        });

        $freshInvoice = $invoice->fresh('customer');

        if ($marksInvoicePaid && $freshInvoice) {
            $this->runInvoicePaidPostProcessing(
                $request,
                $freshInvoice,
                $adminNotifications,
                $clientNotifications,
                $commissionService,
                $salesRepNotifications,
                $reference !== '' ? $reference : null
            );
        }

        SystemLogger::write('activity', $marksInvoicePaid ? 'Invoice marked as paid via sales representative collection.' : 'Partial invoice collection recorded via sales representative.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'sales_representative_id' => $salesRep->id,
            'payment_amount' => $paymentAmount,
            'paid_total_before_collection' => $paidTotal,
            'outstanding_before_collection' => $outstandingAmount,
            'retained_amount' => $retainedAmount,
            'currency' => $invoice->currency,
            'invoice_marked_paid' => $marksInvoicePaid,
        ], $request->user()?->id, $request->ip());

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                route('admin.invoices.show', $invoice),
                $marksInvoicePaid
                    ? 'Invoice marked as paid via sales representative.'
                    : 'Collected payment saved. Invoice still has an outstanding balance.'
            );
        }

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', $marksInvoicePaid
                ? 'Invoice marked as paid via sales representative.'
                : 'Collected payment saved. Invoice still has an outstanding balance.');
    }

    public function recalculate(Request $request, Invoice $invoice): RedirectResponse|JsonResponse
    {
        if (! in_array($invoice->status, ['unpaid', 'overdue'], true)) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('Only unpaid or overdue invoices can be recalculated.', 422);
            }

            return redirect()->route('admin.invoices.show', $invoice)
                ->with('status', 'Only unpaid or overdue invoices can be recalculated.');
        }

        $this->billingService->recalculateInvoice($invoice);

        SystemLogger::write('activity', 'Invoice recalculated.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
        ]);

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                route('admin.invoices.show', $invoice),
                'Invoice recalculated.'
            );
        }

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', 'Invoice recalculated.');
    }

    public function update(
        Request $request,
        Invoice $invoice,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications,
        CommissionService $commissionService,
        InvoiceVatService $vatService,
        SalesRepNotificationService $salesRepNotifications
    ): RedirectResponse|JsonResponse {
        $invoice->loadMissing('items');
        $wasPaid = $invoice->status === 'paid';
        $previousStatus = $invoice->status;
        $data = $request->validate([
            'status' => ['required', Rule::in(['unpaid', 'overdue', 'paid', 'cancelled', 'refunded'])],
            'issue_date' => ['required', 'date'],
            'due_date' => ['required', 'date', 'after_or_equal:issue_date'],
            'notes' => ['nullable', 'string'],
            'items' => ['nullable', 'array'],
            'items.*.description' => ['nullable', 'string', 'max:255'],
            'items.*.amount' => ['nullable', 'numeric', 'min:0'],
            'new_items' => ['nullable', 'array'],
            'new_items.*.description' => ['nullable', 'string', 'max:255'],
            'new_items.*.amount' => ['nullable', 'numeric', 'min:0'],
        ]);

        $updates = [
            'status' => $data['status'],
            'issue_date' => $data['issue_date'],
            'due_date' => $data['due_date'],
            'notes' => $data['notes'] ?? null,
        ];

        if ($data['status'] === 'paid') {
            $updates['paid_at'] = $invoice->paid_at ?? Carbon::now();
        } else {
            $updates['paid_at'] = null;
        }

        if ($data['status'] === 'overdue') {
            $updates['overdue_at'] = $invoice->overdue_at ?? Carbon::now();
        } else {
            $updates['overdue_at'] = null;
        }

        $itemInputs = is_array($request->input('items')) ? $request->input('items') : [];
        $newItemInputs = is_array($request->input('new_items')) ? $request->input('new_items') : [];
        $shouldSyncItems = $request->has('items') || $request->has('new_items');

        $itemUpdates = [];
        $itemCreates = [];
        $validationErrors = [];

        if ($shouldSyncItems) {
            $subtotal = 0.0;

            foreach ($invoice->items as $item) {
                $row = $itemInputs[$item->id] ?? $itemInputs[(string) $item->id] ?? [];
                if (! is_array($row)) {
                    $row = [];
                }

                $description = trim((string) ($row['description'] ?? $item->description ?? ''));
                $amountRaw = $row['amount'] ?? $item->line_total;

                if ($description === '') {
                    $validationErrors["items.{$item->id}.description"] = 'Description is required.';
                }
                if ($amountRaw === null || trim((string) $amountRaw) === '') {
                    $validationErrors["items.{$item->id}.amount"] = 'Amount is required.';
                    $amountRaw = 0;
                }

                $amount = round((float) $amountRaw, 2);
                if ($amount < 0) {
                    $validationErrors["items.{$item->id}.amount"] = 'Amount must be 0 or greater.';
                }

                $itemUpdates[] = [
                    'model' => $item,
                    'description' => $description,
                    'amount' => $amount,
                ];
                $subtotal += $amount;
            }

            foreach ($newItemInputs as $index => $row) {
                if (! is_array($row)) {
                    continue;
                }

                $description = trim((string) ($row['description'] ?? ''));
                $amountRaw = $row['amount'] ?? null;
                $amountProvided = $amountRaw !== null && trim((string) $amountRaw) !== '';
                $hasAnyValue = $description !== '' || $amountProvided;

                if (! $hasAnyValue) {
                    continue;
                }

                if ($description === '') {
                    $validationErrors["new_items.{$index}.description"] = 'Description is required for new line item.';
                }
                if (! $amountProvided) {
                    $validationErrors["new_items.{$index}.amount"] = 'Amount is required for new line item.';
                    $amountRaw = 0;
                }

                $amount = round((float) $amountRaw, 2);
                if ($amount < 0) {
                    $validationErrors["new_items.{$index}.amount"] = 'Amount must be 0 or greater.';
                }

                $itemCreates[] = [
                    'description' => $description,
                    'amount' => $amount,
                ];
                $subtotal += $amount;
            }

            if ($subtotal <= 0) {
                $validationErrors['items'] = 'Invoice total must be greater than zero.';
            }

            if ($validationErrors !== []) {
                throw ValidationException::withMessages($validationErrors);
            }

            $taxData = $vatService->calculateTotals($subtotal, 0.0, Carbon::parse($data['issue_date']));
            $updates['subtotal'] = $subtotal;
            $updates['tax_rate_percent'] = $taxData['tax_rate_percent'];
            $updates['tax_mode'] = $taxData['tax_mode'];
            $updates['tax_amount'] = $taxData['tax_amount'];
            $updates['total'] = $taxData['total'];
        }

        DB::transaction(function () use ($invoice, $updates, $itemUpdates, $itemCreates, $shouldSyncItems) {
            if ($shouldSyncItems) {
                foreach ($itemUpdates as $itemUpdate) {
                    /** @var InvoiceItem $itemModel */
                    $itemModel = $itemUpdate['model'];
                    $amount = (float) $itemUpdate['amount'];
                    $itemModel->update([
                        'description' => $itemUpdate['description'],
                        'quantity' => 1,
                        'unit_price' => $amount,
                        'line_total' => $amount,
                    ]);
                }

                foreach ($itemCreates as $itemCreate) {
                    $amount = (float) $itemCreate['amount'];
                    InvoiceItem::create([
                        'invoice_id' => $invoice->id,
                        'description' => $itemCreate['description'],
                        'quantity' => 1,
                        'unit_price' => $amount,
                        'line_total' => $amount,
                    ]);
                }
            }

            $invoice->update($updates);
        });

        $statusChanged = $previousStatus !== $data['status'];
        if (! $wasPaid && $data['status'] === 'paid') {
            $adminNotifications->sendInvoicePaid($invoice->fresh('customer'));

            // Check if customer has any remaining unpaid/overdue invoices
            // If not, clear the billing block
            $hasUnpaidInvoices = Invoice::query()
                ->where('customer_id', $invoice->customer_id)
                ->whereIn('status', ['unpaid', 'overdue'])
                ->whereRaw(
                    "(COALESCE(total, 0) - COALESCE((SELECT SUM(CASE WHEN type IN ('payment', 'credit') THEN amount ELSE 0 END) FROM accounting_entries WHERE accounting_entries.invoice_id = invoices.id), 0)) > 0.009"
                )
                ->exists();

            if (! $hasUnpaidInvoices) {
                // Customer has no more unpaid invoices, restore access immediately
                \App\Models\Customer::query()
                    ->where('id', $invoice->customer_id)
                    ->update(['access_override_until' => null]);
            }
        }

        if ($statusChanged) {
            $freshInvoice = $invoice->fresh('customer');
            try {
                $clientNotifications->sendInvoicePaymentStatusNotification($freshInvoice, 'admin_update', null);
            } catch (\Throwable $e) {
                SystemLogger::write('module', 'Client invoice payment status notification failed on admin invoice update.', [
                    'invoice_id' => $invoice->id,
                    'status' => $data['status'],
                    'error' => $e->getMessage(),
                ], level: 'error');
            }

            try {
                $salesRepNotifications->sendInvoicePaymentStatusToRelatedSalesReps($freshInvoice, 'admin_update', null);
            } catch (\Throwable $e) {
                SystemLogger::write('module', 'Sales rep invoice payment status notification failed on admin invoice update.', [
                    'invoice_id' => $invoice->id,
                    'status' => $data['status'],
                    'error' => $e->getMessage(),
                ], level: 'error');
            }
        }

        SystemLogger::write('activity', 'Invoice updated.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'from_status' => $previousStatus,
            'to_status' => $data['status'],
        ], $request->user()?->id, $request->ip());

        \App\Models\StatusAuditLog::logChange(
            Invoice::class,
            $invoice->id,
            $previousStatus,
            $data['status'],
            'admin_update',
            $request->user()?->id
        );

        // Commission creation or reversal based on status transitions.
        try {
            if (! $wasPaid && $data['status'] === 'paid') {
                $commissionService->createOrUpdateEarningOnInvoicePaid($invoice->fresh('subscription.customer'));
            }

            if (in_array($data['status'], ['cancelled', 'refunded'], true)) {
                $commissionService->reverseEarningsOnRefund($invoice);
            }
        } catch (\Throwable $e) {
            SystemLogger::write('module', 'Commission update failed on invoice admin update.', [
                'invoice_id' => $invoice->id,
                'from_status' => $previousStatus,
                'to_status' => $data['status'],
                'error' => $e->getMessage(),
            ], level: 'error');
        }

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                route('admin.invoices.show', $invoice),
                'Invoice updated.'
            );
        }

        return redirect()->route('admin.invoices.show', $invoice)
            ->with('status', 'Invoice updated.');
    }

    public function destroy(Request $request, Invoice $invoice): RedirectResponse|JsonResponse
    {
        SystemLogger::write('activity', 'Invoice deleted.', [
            'invoice_id' => $invoice->id,
            'customer_id' => $invoice->customer_id,
            'status' => $invoice->status,
        ]);

        $invoice->delete();

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                $this->listRedirectFromRequest($request),
                'Invoice deleted.'
            );
        }

        return redirect()->route('admin.invoices.index')
            ->with('status', 'Invoice deleted.');
    }

    private function listByStatus(?string $status, string $title, ?Project $project = null): InertiaResponse
    {
        $search = trim((string) request()->query('search', ''));

        $query = Invoice::query()
            ->with(['customer', 'subscription.plan.product', 'maintenance.project'])
            ->withSum([
                'accountingEntries as list_payment_total' => fn (Builder $entries) => $entries->where('type', 'payment'),
            ], 'amount')
            ->withSum([
                'accountingEntries as list_credit_total' => fn (Builder $entries) => $entries->where('type', 'credit'),
            ], 'amount')
            ->withExists([
                'paymentProofs as list_has_pending_proof' => fn (Builder $proofs) => $proofs->where('status', 'pending'),
                'paymentProofs as list_has_rejected_proof' => fn (Builder $proofs) => $proofs->where('status', 'rejected'),
            ])
            ->latest('issue_date');

        if ($project) {
            $query->where('project_id', $project->id);
        }

        if ($status === 'unpaid') {
            $query->whereIn('status', ['unpaid', 'overdue'])
                ->whereRaw($this->outstandingAmountSql().' > 0.009');
        } elseif ($status === 'overdue') {
            $query->where('status', 'overdue')
                ->whereRaw($this->outstandingAmountSql().' > 0.009');
        } elseif ($status === 'paid') {
            $query->where(function ($inner) {
                $inner->where('status', 'paid')
                    ->orWhere(function ($effectivePaid) {
                        $effectivePaid->whereIn('status', ['unpaid', 'overdue'])
                            ->whereRaw($this->outstandingAmountSql().' <= 0.009');
                    });
            });
        } elseif ($status) {
            $query->where('status', $status);
        }

        if ($search !== '') {
            $query->where(function ($inner) use ($search) {
                $inner->where('number', 'like', '%'.$search.'%')
                    ->orWhere('status', 'like', '%'.$search.'%')
                    ->orWhereHas('customer', function ($customerQuery) use ($search) {
                        $customerQuery->where('name', 'like', '%'.$search.'%');
                    })
                    ->orWhereHas('subscription.plan', function ($planQuery) use ($search) {
                        $planQuery->where('name', 'like', '%'.$search.'%')
                            ->orWhereHas('product', function ($productQuery) use ($search) {
                                $productQuery->where('name', 'like', '%'.$search.'%');
                            });
                    })
                    ->orWhereHas('maintenance', function ($maintenanceQuery) use ($search) {
                        $maintenanceQuery->where('title', 'like', '%'.$search.'%');
                    });

                if (is_numeric($search)) {
                    $inner->orWhere('id', (int) $search);
                }
            });
        }

        $invoiceInsights = $this->invoiceInsights(clone $query);

        $payload = [
            'invoices' => $query->paginate(30)->withQueryString(),
            'title' => $title,
            'statusFilter' => $status,
            'search' => $search,
            'project' => $project,
        ];

        /** @var LengthAwarePaginator $paginator */
        $paginator = $payload['invoices'];

        return Inertia::render('Admin/Invoices/Index', [
            'pageTitle' => $title,
            'statusFilter' => $status,
            'filters' => [
                'search' => $search,
            ],
            'invoiceInsights' => $invoiceInsights,
            'project' => $project ? [
                'id' => $project->id,
                'name' => $project->name,
            ] : null,
            'invoices' => $paginator->getCollection()
                ->map(fn (Invoice $invoice) => $this->serializeInvoiceListItem($invoice))
                ->values(),
            'pagination' => $this->paginationPayload($paginator),
            'routes' => [
                'index' => route('admin.invoices.index'),
                'paid' => route('admin.invoices.paid'),
                'unpaid' => route('admin.invoices.unpaid'),
                'overdue' => route('admin.invoices.overdue'),
                'cancelled' => route('admin.invoices.cancelled'),
                'refunded' => route('admin.invoices.refunded'),
                'create' => route('admin.invoices.create'),
                'current' => url()->current(),
            ],
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private function invoiceInsights(Builder $query): array
    {
        $currency = (string) ((clone $query)
            ->setEagerLoads([])
            ->value('currency') ?: Setting::getValue('currency', 'BDT'));

        $filteredInvoices = (clone $query)
            ->setEagerLoads([])
            ->reorder()
            ->select([
                'invoices.id',
                'invoices.status',
                'invoices.total',
            ]);

        $accountingTotals = AccountingEntry::query()
            ->selectRaw(
                "invoice_id, SUM(CASE WHEN type IN ('payment', 'credit') THEN amount ELSE 0 END) as collected"
            )
            ->whereNotNull('invoice_id')
            ->groupBy('invoice_id');

        $proofFlags = DB::table('payment_proofs')
            ->selectRaw(
                "invoice_id, MAX(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as has_pending_proof, "
                ."MAX(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as has_rejected_proof"
            )
            ->groupBy('invoice_id');

        $collectedSql = 'COALESCE(accounting_totals.collected, 0)';
        $outstandingSql = "CASE WHEN COALESCE(filtered_invoices.total, 0) - {$collectedSql} > 0 "
            ."THEN COALESCE(filtered_invoices.total, 0) - {$collectedSql} ELSE 0 END";
        $effectivelyPaidSql = "filtered_invoices.status = 'paid' OR "
            ."(filtered_invoices.status IN ('unpaid', 'overdue') AND {$outstandingSql} <= 0.009)";
        $effectiveOverdueSql = "filtered_invoices.status = 'overdue' AND {$outstandingSql} > 0.009";

        $insights = DB::query()
            ->fromSub($filteredInvoices, 'filtered_invoices')
            ->leftJoinSub($accountingTotals, 'accounting_totals', function ($join): void {
                $join->on('accounting_totals.invoice_id', '=', 'filtered_invoices.id');
            })
            ->leftJoinSub($proofFlags, 'proof_flags', function ($join): void {
                $join->on('proof_flags.invoice_id', '=', 'filtered_invoices.id');
            })
            ->selectRaw(
                "COUNT(*) as invoice_count,
                COALESCE(SUM(filtered_invoices.total), 0) as billed,
                COALESCE(SUM({$collectedSql}), 0) as collected,
                COALESCE(SUM({$outstandingSql}), 0) as outstanding,
                SUM(CASE WHEN {$effectivelyPaidSql} THEN 1 ELSE 0 END) as paid_count,
                SUM(CASE WHEN filtered_invoices.status = 'unpaid' AND {$outstandingSql} > 0.009 THEN 1 ELSE 0 END) as unpaid_count,
                SUM(CASE WHEN {$effectiveOverdueSql} THEN 1 ELSE 0 END) as overdue_count,
                SUM(CASE WHEN filtered_invoices.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count,
                SUM(CASE WHEN filtered_invoices.status = 'refunded' THEN 1 ELSE 0 END) as refunded_count,
                SUM(CASE WHEN {$collectedSql} > 0 AND {$outstandingSql} > 0 THEN 1 ELSE 0 END) as partial_count,
                COALESCE(SUM(CASE WHEN {$effectiveOverdueSql} THEN {$outstandingSql} ELSE 0 END), 0) as overdue_amount,
                SUM(CASE WHEN COALESCE(proof_flags.has_pending_proof, 0) = 1 THEN 1 ELSE 0 END) as pending_proof_count,
                SUM(CASE WHEN COALESCE(proof_flags.has_rejected_proof, 0) = 1 THEN 1 ELSE 0 END) as rejected_proof_count"
            )
            ->first();

        return [
            'overview' => [
                'count' => (int) ($insights->invoice_count ?? 0),
                'billed_display' => $this->formatMoney($currency, (float) ($insights->billed ?? 0)),
                'collected_display' => $this->formatMoney($currency, (float) ($insights->collected ?? 0)),
                'outstanding_display' => $this->formatMoney($currency, (float) ($insights->outstanding ?? 0)),
            ],
            'statuses' => [
                'paid' => (int) ($insights->paid_count ?? 0),
                'unpaid' => (int) ($insights->unpaid_count ?? 0),
                'overdue' => (int) ($insights->overdue_count ?? 0),
                'cancelled' => (int) ($insights->cancelled_count ?? 0),
                'refunded' => (int) ($insights->refunded_count ?? 0),
                'partial' => (int) ($insights->partial_count ?? 0),
            ],
            'watchlist' => [
                'overdue_count' => (int) ($insights->overdue_count ?? 0),
                'overdue_amount_display' => $this->formatMoney($currency, (float) ($insights->overdue_amount ?? 0)),
                'pending_proof_count' => (int) ($insights->pending_proof_count ?? 0),
                'rejected_proof_count' => (int) ($insights->rejected_proof_count ?? 0),
            ],
        ];
    }

    private function listRedirectFromRequest(Request $request): string
    {
        $statusFilter = trim((string) $request->input('status_filter', ''));
        $status = in_array($statusFilter, ['paid', 'unpaid', 'overdue', 'cancelled', 'refunded'], true)
            ? $statusFilter
            : null;
        $search = trim((string) $request->input('search', ''));
        $project = null;
        $projectId = (int) $request->input('project_id', 0);
        if ($projectId > 0) {
            $project = Project::query()->find($projectId);
        }
        $listUrl = $this->statusListUrl($status, $project);
        if ($search === '') {
            return $listUrl;
        }

        $separator = str_contains($listUrl, '?') ? '&' : '?';

        return $listUrl.$separator.http_build_query(['search' => $search]);
    }

    private function customerLabel(Customer $customer): string
    {
        $label = $customer->name;

        if ($customer->company_name) {
            $label .= ' - '.$customer->company_name;
        }

        if ($customer->email) {
            $label .= ' ('.$customer->email.')';
        }

        return $label;
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeInvoiceListItem(Invoice $invoice): array
    {
        $creditTotal = (float) ($invoice->list_credit_total ?? 0);
        $paidTotal = (float) ($invoice->list_payment_total ?? 0);
        $paidAmount = $paidTotal + $creditTotal;
        $outstandingAmount = max(0, (float) $invoice->total - $paidAmount);
        $effectiveStatus = $this->effectiveInvoiceStatus((string) $invoice->status, $outstandingAmount);
        $isPartial = $paidAmount > 0 && $paidAmount < (float) $invoice->total;

        return [
            'id' => $invoice->id,
            'number_display' => is_numeric($invoice->number) ? (string) $invoice->number : (string) $invoice->id,
            'customer_name' => $invoice->customer?->name,
            'customer_company_name' => $invoice->customer?->company_name,
            'customer_route' => $invoice->customer ? route('admin.customers.show', $invoice->customer) : null,
            'total_display' => sprintf('%s %s', (string) $invoice->currency, number_format((float) $invoice->total, 2)),
            'paid_at_display' => $invoice->paid_at?->format((string) config('app.date_format', 'd-m-Y')) ?? '--',
            'due_date_display' => $invoice->due_date?->format((string) config('app.date_format', 'd-m-Y')) ?? '--',
            'status' => $effectiveStatus,
            'status_label' => ucfirst($effectiveStatus),
            'status_class' => $this->statusClass($effectiveStatus),
            'has_pending_proof' => (bool) $invoice->list_has_pending_proof,
            'has_rejected_proof' => (bool) $invoice->list_has_rejected_proof,
            'is_partial' => $isPartial,
            'paid_amount_display' => sprintf('%s %s', (string) $invoice->currency, number_format($paidAmount, 2)),
            'routes' => [
                'show' => route('admin.invoices.show', $invoice),
                'destroy' => route('admin.invoices.destroy', $invoice),
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeInvoiceDetails(Invoice $invoice): array
    {
        $creditTotal = (float) $invoice->accountingEntries->where('type', 'credit')->sum('amount');
        $paidTotal = (float) $invoice->accountingEntries->where('type', 'payment')->sum('amount');
        $taxSetting = \App\Models\TaxSetting::current();
        $taxLabel = 'VAT';
        $taxNote = $taxSetting->renderNote($invoice->tax_rate_percent);
        $hasTax = $invoice->tax_amount !== null && $invoice->tax_rate_percent !== null && $invoice->tax_mode;
        $discountAmount = $creditTotal;
        $payableAmount = max(0, (float) $invoice->total - $discountAmount);
        $outstandingAmount = max(0, (float) $invoice->total - ($paidTotal + $creditTotal));
        $feeTotal = round((float) $invoice->accountingEntries
            ->where('type', 'payment')
            ->sum(fn ($entry) => (float) (is_array($entry->metadata) ? ($entry->metadata['transaction_fee'] ?? 0) : 0)), 2);
        $netReceived = round($paidTotal - $feeTotal, 2);
        $effectiveStatus = $this->effectiveInvoiceStatus((string) $invoice->status, $outstandingAmount);
        $companyName = (string) Setting::getValue('company_name', config('app.name', 'MyApptimatic'));
        $companyEmail = (string) Setting::getValue('company_email');
        $payToText = (string) Setting::getValue('pay_to_text');
        $companyLogoUrl = Branding::url(Setting::getValue('company_logo_path'));
        $salesRepCollection = $this->resolveSalesRepCollectionSummary($invoice);

        return [
            'id' => $invoice->id,
            'number_display' => is_numeric($invoice->number) ? (string) $invoice->number : (string) $invoice->id,
            'status' => $effectiveStatus,
            'status_label' => strtoupper($effectiveStatus),
            'status_class' => $this->statusClass($effectiveStatus),
            'issue_date_display' => $invoice->issue_date?->format((string) config('app.date_format', 'd-m-Y')) ?? '--',
            'due_date_display' => $invoice->due_date?->format((string) config('app.date_format', 'd-m-Y')) ?? '--',
            'paid_at_display' => $invoice->paid_at?->format((string) config('app.date_format', 'd-m-Y')) ?? null,
            'issue_date_value' => (string) old('issue_date', $invoice->issue_date?->format(config('app.date_format', 'd-m-Y'))),
            'due_date_value' => (string) old('due_date', $invoice->due_date?->format(config('app.date_format', 'd-m-Y'))),
            'notes_value' => (string) old('notes', $invoice->notes ?? ''),
            'selected_status' => (string) old('status', $effectiveStatus),
            'currency' => (string) $invoice->currency,
            'customer' => [
                'id' => $invoice->customer?->id,
                'name' => $invoice->customer?->name ?? '--',
                'email' => $invoice->customer?->email ?? '--',
                'address' => $invoice->customer?->address ?? '--',
                'show_route' => $invoice->customer ? route('admin.customers.show', $invoice->customer) : null,
            ],
            'company' => [
                'name' => $companyName,
                'logo_url' => $companyLogoUrl,
                'email' => $companyEmail !== '' ? $companyEmail : '--',
                'pay_to_text' => $payToText !== '' ? $payToText : 'Billing Department',
            ],
            'items' => $invoice->items->map(fn (InvoiceItem $item) => [
                'id' => $item->id,
                'description' => $item->description,
                'line_total_value' => number_format((float) $item->line_total, 2, '.', ''),
                'line_total_display' => sprintf(
                    '%s %s',
                    (string) $invoice->currency,
                    number_format((float) $item->line_total, 2)
                ),
            ])->values(),
            'totals' => [
                'total_display' => sprintf('%s %s', (string) $invoice->currency, number_format((float) $invoice->total, 2)),
                'subtotal_display' => sprintf('%s %s', (string) $invoice->currency, number_format((float) $invoice->subtotal, 2)),
                'has_tax' => $hasTax,
                'tax_label' => $taxLabel,
                'tax_rate_display' => rtrim(rtrim(number_format((float) $invoice->tax_rate_percent, 2, '.', ''), '0'), '.'),
                'tax_mode' => $invoice->tax_mode,
                'tax_amount_display' => sprintf('%s %s', (string) $invoice->currency, number_format((float) $invoice->tax_amount, 2)),
                'tax_note' => $taxNote,
                'credit_display' => sprintf('%s %s', (string) $invoice->currency, number_format($discountAmount, 2)),
                'discount_display' => '- '.(string) $invoice->currency.' '.number_format($discountAmount, 2),
                'paid_display' => '- '.(string) $invoice->currency.' '.number_format($paidTotal, 2),
                'collected_display' => sprintf('%s %s', (string) $invoice->currency, number_format($paidTotal, 2)),
                'collected_value' => number_format($paidTotal, 2, '.', ''),
                'transaction_fee_total' => $feeTotal,
                'transaction_fee_display' => sprintf('%s %s', (string) $invoice->currency, number_format($feeTotal, 2)),
                'net_received_display' => sprintf('%s %s', (string) $invoice->currency, number_format($netReceived, 2)),
                'payable_display' => sprintf('%s %s', (string) $invoice->currency, number_format($payableAmount, 2)),
                'outstanding_display' => sprintf('%s %s', (string) $invoice->currency, number_format($outstandingAmount, 2)),
                'outstanding_value' => number_format($outstandingAmount, 2, '.', ''),
            ],
            'notes' => $invoice->notes,
            'payment_method_display' => (string) (
                $invoice->paymentProofs->sortByDesc('id')->first()?->paymentGateway?->name
                ?? $invoice->accountingEntries->sortByDesc('id')->first()?->paymentGateway?->name
                ?? '--'
            ),
            'sales_rep_collection' => $salesRepCollection,
            'accounting_entries' => $invoice->accountingEntries->map(function ($entry) {
                $metadata = is_array($entry->metadata) ? $entry->metadata : [];
                $collectedBySalesRepName = trim((string) ($metadata['collected_by_sales_rep_name'] ?? ''));
                $retainedAmount = (float) ($metadata['retained_amount'] ?? 0);
                $transactionFee = (float) ($metadata['transaction_fee'] ?? $metadata['fees'] ?? 0);

                return [
                    'id' => $entry->id,
                    'type' => (string) $entry->type,
                    'type_label' => ucfirst((string) $entry->type),
                    'status_label' => ucfirst((string) $entry->type),
                    'entry_date_display' => $entry->entry_date?->format((string) config('app.date_format', 'd-m-Y')) ?? '--',
                    'gateway_name' => $entry->paymentGateway?->name,
                    'description' => $entry->description,
                    'reference' => $entry->reference ?: '--',
                    'transaction_fee_display' => sprintf('%s %s', (string) $entry->currency, number_format($transactionFee, 2)),
                    'sales_rep_collection' => $collectedBySalesRepName !== '' ? [
                        'sales_rep_name' => $collectedBySalesRepName,
                        'retained_amount_display' => sprintf('%s %s', (string) $entry->currency, number_format($retainedAmount, 2)),
                        'reference' => $entry->reference ?: '--',
                        'note' => (string) ($metadata['note'] ?? ''),
                    ] : null,
                    'amount_display' => sprintf(
                        '%s%s %s',
                        $entry->isOutflow() ? '-' : '+',
                        (string) $entry->currency,
                        number_format((float) $entry->amount, 2)
                    ),
                    'amount_class' => $entry->isOutflow() ? 'text-rose-600' : 'text-emerald-600',
                ];
            })->values(),
            'payment_proofs' => $invoice->paymentProofs->map(function ($proof) use ($invoice) {
                return [
                    'id' => $proof->id,
                    'gateway_name' => $proof->paymentGateway?->name ?? 'Manual',
                    'amount_display' => sprintf('%s %s', (string) $invoice->currency, number_format((float) $proof->amount, 2)),
                    'reference' => $proof->reference ?: '--',
                    'status' => $proof->status,
                    'status_label' => ucfirst((string) $proof->status),
                    'paid_at_display' => $proof->paid_at?->format((string) config('app.date_format', 'd-m-Y')),
                    'notes' => $proof->notes,
                    'reviewer_name' => $proof->reviewer?->name,
                    'attachment_url' => $proof->attachment_url,
                    'attachment_path' => $proof->attachment_path,
                    'can_review' => $proof->status === 'pending',
                    'routes' => [
                        'approve' => route('admin.payment-proofs.approve', $proof),
                        'reject' => route('admin.payment-proofs.reject', $proof),
                    ],
                ];
            })->values(),
            'can_record_payment' => in_array($effectiveStatus, ['unpaid', 'overdue'], true) && $outstandingAmount > 0,
            'can_record_refund' => $invoice->status === 'paid',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function invoicePayProps(Request $request, Invoice $invoice, string $downloadRouteName): array
    {
        $invoice->load([
            'items',
            'customer',
            'subscription.plan.product',
            'accountingEntries.paymentGateway',
            'paymentProofs.paymentGateway',
            'paymentProofs.paymentAttempt',
        ]);

        $taxSetting = TaxSetting::current();
        $paidTotal = (float) $invoice->accountingEntries->where('type', 'payment')->sum('amount');
        $creditTotal = (float) $invoice->accountingEntries->where('type', 'credit')->sum('amount');
        $settledTotal = $paidTotal + $creditTotal;
        $hasTax = $invoice->tax_amount !== null && $invoice->tax_rate_percent !== null && $invoice->tax_mode;
        $payableAmount = max(0, (float) $invoice->total - $settledTotal);
        $effectiveStatus = $this->effectiveInvoiceStatus((string) $invoice->status, $payableAmount);
        $displayNumber = is_numeric($invoice->number) ? (string) $invoice->number : (string) $invoice->id;
        $dateFormat = config('app.date_format', 'd-m-Y');
        $portalBranding = (array) (view()->shared('portalBranding') ?? []);
        $companyName = (string) ($portalBranding['company_name'] ?? Setting::getValue('company_name', config('app.name', 'Apptimatic')));
        $companyLogoUrl = $portalBranding['logo_url'] ?? Branding::url(Setting::getValue('company_logo_path'));
        $pendingProof = $invoice->paymentProofs->firstWhere('status', 'pending');
        $rejectedProof = $invoice->paymentProofs->firstWhere('status', 'rejected');

        $gateways = PaymentGateway::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->get();

        return [
            'invoice' => [
                'id' => $invoice->id,
                'number_display' => $displayNumber,
                'status' => $effectiveStatus,
                'status_label' => strtoupper($effectiveStatus),
                'status_class' => strtolower($effectiveStatus),
                'issue_date_display' => $invoice->issue_date?->format($dateFormat) ?? '--',
                'due_date_display' => $invoice->due_date?->format($dateFormat) ?? '--',
                'paid_at_display' => $invoice->paid_at?->format($dateFormat),
                'currency' => (string) $invoice->currency,
                'customer' => [
                    'name' => $invoice->customer?->name ?? '--',
                    'email' => $invoice->customer?->email ?? '--',
                    'address' => $invoice->customer?->address ?? '--',
                ],
                'items' => $invoice->items->map(function ($item) use ($invoice) {
                    return [
                        'id' => $item->id,
                        'description' => (string) $item->description,
                        'line_total_display' => (string) $invoice->currency.' '.number_format((float) $item->line_total, 2),
                    ];
                })->values()->all(),
                'subtotal_display' => (string) $invoice->currency.' '.number_format((float) $invoice->subtotal, 2),
                'has_tax' => (bool) $hasTax,
                'tax_mode' => $invoice->tax_mode,
                'tax_amount_display' => (string) $invoice->currency.' '.number_format((float) $invoice->tax_amount, 2),
                'tax_rate_percent_display' => $invoice->tax_rate_percent !== null
                    ? rtrim(rtrim(number_format((float) $invoice->tax_rate_percent, 2, '.', ''), '0'), '.')
                    : null,
                'discount_display' => (string) $invoice->currency.' '.number_format($creditTotal, 2),
                'paid_amount_display' => (string) $invoice->currency.' '.number_format($paidTotal, 2),
                'payable_amount_display' => (string) $invoice->currency.' '.number_format($payableAmount, 2),
                'is_payable' => in_array($effectiveStatus, ['unpaid', 'overdue'], true) && $payableAmount > 0,
                'pending_proof' => (bool) $pendingProof,
                'rejected_proof' => (bool) $rejectedProof,
            ],
            'tax' => [
                'label' => 'VAT',
                'note' => $taxSetting->renderNote($invoice->tax_rate_percent),
            ],
            'company' => [
                'name' => $companyName,
                'logo_url' => $companyLogoUrl,
                'email' => Setting::getValue('company_email') ?: 'support@example.com',
                'pay_to' => Setting::getValue('pay_to_text') ?: 'Billing Department',
            ],
            'payment_instructions' => Setting::getValue('payment_instructions'),
            'gateways' => $gateways->map(function ($gateway) {
                return [
                    'id' => $gateway->id,
                    'name' => (string) $gateway->name,
                    'driver' => (string) $gateway->driver,
                    'payment_url' => (string) ($gateway->settings['payment_url'] ?? ''),
                    'instructions' => (string) ($gateway->settings['instructions'] ?? ''),
                    'button_label' => (string) ($gateway->settings['button_label'] ?? ''),
                ];
            })->values()->all(),
            'routes' => [
                'checkout' => route('client.invoices.checkout', $invoice),
                'download' => route($downloadRouteName, $invoice),
            ],
        ];
    }

    /**
     * Everything that must happen once an invoice is settled. The real work
     * lives in InvoicePaymentCompletionService so the admin screens, the
     * gateway callbacks and the payment-proof approval cannot drift apart.
     */
    private function runInvoicePaidPostProcessing(
        Request $request,
        Invoice $invoice,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications,
        CommissionService $commissionService,
        SalesRepNotificationService $salesRepNotifications,
        ?string $reference = null,
        string $reason = 'invoice_add_payment'
    ): void {
        app(InvoicePaymentCompletionService::class)->complete($invoice, [
            'reason' => $reason,
            'reference' => $reference,
            'actor_id' => $request->user()?->id,
        ]);
    }

    /**
     * @return Collection<int, SalesRepresentative>
     */
    private function invoiceSalesRepOptions(Invoice $invoice): Collection
    {
        $salesReps = collect();

        if ($invoice->customer?->defaultSalesRep instanceof SalesRepresentative) {
            $salesReps->push($invoice->customer->defaultSalesRep);
        }

        if ($invoice->subscription?->salesRep instanceof SalesRepresentative) {
            $salesReps->push($invoice->subscription->salesRep);
        }

        foreach ($invoice->orders ?? [] as $order) {
            if ($order->salesRep instanceof SalesRepresentative) {
                $salesReps->push($order->salesRep);
            }
        }

        foreach ($invoice->project?->salesRepresentatives ?? [] as $salesRep) {
            if ($salesRep instanceof SalesRepresentative) {
                $salesReps->push($salesRep);
            }
        }

        foreach ($invoice->maintenance?->salesRepresentatives ?? [] as $salesRep) {
            if ($salesRep instanceof SalesRepresentative) {
                $salesReps->push($salesRep);
            }
        }

        foreach ($invoice->maintenance?->project?->salesRepresentatives ?? [] as $salesRep) {
            if ($salesRep instanceof SalesRepresentative) {
                $salesReps->push($salesRep);
            }
        }

        $resolved = $salesReps
            ->filter(fn ($salesRep) => $salesRep instanceof SalesRepresentative && (string) $salesRep->status === 'active')
            ->unique('id')
            ->values();

        if ($resolved->isNotEmpty()) {
            return $resolved;
        }

        return SalesRepresentative::query()
            ->where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'email', 'status']);
    }

    /**
     * @return array<string, mixed>|null
     */
    private function resolveSalesRepCollectionSummary(Invoice $invoice): ?array
    {
        $entry = $invoice->accountingEntries
            ->filter(fn (AccountingEntry $item) => $item->type === 'payment')
            ->sortByDesc('id')
            ->first(function (AccountingEntry $item) {
                $metadata = is_array($item->metadata) ? $item->metadata : [];

                return (string) ($metadata['payment_mode'] ?? '') === 'sales_rep_collection';
            });

        if (! $entry) {
            return null;
        }

        $metadata = is_array($entry->metadata) ? $entry->metadata : [];
        $salesRepName = trim((string) ($metadata['collected_by_sales_rep_name'] ?? ''));
        if ($salesRepName === '') {
            return null;
        }

        $retainedAmount = (float) ($metadata['retained_amount'] ?? 0);

        return [
            'sales_rep_name' => $salesRepName,
            'reference' => $entry->reference ?: '--',
            'collected_amount_display' => sprintf('%s %s', (string) $entry->currency, number_format((float) $entry->amount, 2)),
            'retained_amount_display' => sprintf('%s %s', (string) $entry->currency, number_format($retainedAmount, 2)),
            'note' => (string) ($metadata['note'] ?? ''),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function paginationPayload(LengthAwarePaginator $paginator): array
    {
        return [
            'current_page' => $paginator->currentPage(),
            'last_page' => $paginator->lastPage(),
            'per_page' => $paginator->perPage(),
            'total' => $paginator->total(),
            'from' => $paginator->firstItem(),
            'to' => $paginator->lastItem(),
            'previous_url' => $paginator->previousPageUrl(),
            'next_url' => $paginator->nextPageUrl(),
            'has_pages' => $paginator->hasPages(),
        ];
    }

    public function bulkRemind(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'invoice_ids' => ['required', 'array'],
            'invoice_ids.*' => ['exists:invoices,id'],
        ]);

        $invoices = Invoice::whereIn('id', $data['invoice_ids'])->get();
        $sentCount = 0;

        foreach ($invoices as $invoice) {
            if (! in_array($invoice->status, ['unpaid', 'overdue'], true)) {
                continue;
            }

            $templateKey = $invoice->status === 'overdue' ? 'invoice_overdue_first_notice' : 'invoice_payment_reminder';

            \App\Jobs\SendInvoiceReminderNotification::dispatch($invoice->id, $templateKey);

            $now = Carbon::now();
            if ($invoice->status === 'overdue') {
                $invoice->update([
                    'first_overdue_reminder_sent_at' => $now,
                ]);
            } else {
                $invoice->update([
                    'reminder_sent_at' => $now,
                ]);
            }

            $sentCount++;
        }

        if ($sentCount === 0) {
            return redirect()->back()->with('error', 'No unpaid or overdue invoices were selected.');
        }

        return redirect()->back()->with('status', "Sent {$sentCount} invoice reminder(s) successfully.");
    }

    public function bulkMarkPaid(
        Request $request,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications,
        CommissionService $commissionService,
        SalesRepNotificationService $salesRepNotifications
    ): RedirectResponse {
        $data = $request->validate([
            'invoice_ids' => ['required', 'array'],
            'invoice_ids.*' => ['exists:invoices,id'],
        ]);

        $invoices = Invoice::whereIn('id', $data['invoice_ids'])->get();
        $updatedCount = 0;

        foreach ($invoices as $invoice) {
            if ($invoice->status === 'paid') {
                continue;
            }

            $this->runInvoicePaidPostProcessing(
                $request,
                $invoice,
                $adminNotifications,
                $clientNotifications,
                $commissionService,
                $salesRepNotifications,
                null,
                'manual_mark_paid'
            );

            SystemLogger::write('activity', 'Invoice marked as paid (bulk).', [
                'invoice_id' => $invoice->id,
                'customer_id' => $invoice->customer_id,
            ], $request->user()?->id, $request->ip());

            $updatedCount++;
        }

        if ($updatedCount === 0) {
            return redirect()->back()->with('error', 'No unpaid invoices were selected.');
        }

        return redirect()->back()->with('status', "Marked {$updatedCount} invoice(s) as paid successfully.");
    }

    public function bulkMarkUnpaid(Request $request, CommissionService $commissionService): RedirectResponse
    {
        $data = $request->validate([
            'invoice_ids' => ['required', 'array'],
            'invoice_ids.*' => ['exists:invoices,id'],
        ]);

        $invoices = Invoice::whereIn('id', $data['invoice_ids'])->get();
        $updatedCount = 0;

        foreach ($invoices as $invoice) {
            if ($invoice->status === 'unpaid') {
                continue;
            }

            $previousStatus = $invoice->status;
            $invoice->update([
                'status' => 'unpaid',
                'paid_at' => null,
                'overdue_at' => null,
            ]);

            \App\Models\StatusAuditLog::logChange(
                Invoice::class,
                $invoice->id,
                $previousStatus,
                'unpaid',
                'admin_update',
                $request->user()?->id
            );

            try {
                $commissionService->reverseEarningsOnRefund($invoice);
            } catch (\Throwable $e) {
                SystemLogger::write('module', 'Commission update failed on invoice bulk unpaid.', [
                    'invoice_id' => $invoice->id,
                    'error' => $e->getMessage(),
                ], level: 'error');
            }

            SystemLogger::write('activity', 'Invoice marked as unpaid (bulk).', [
                'invoice_id' => $invoice->id,
                'customer_id' => $invoice->customer_id,
            ], $request->user()?->id, $request->ip());

            $updatedCount++;
        }

        if ($updatedCount === 0) {
            return redirect()->back()->with('error', 'No invoices were selected or they are already unpaid.');
        }

        return redirect()->back()->with('status', "Marked {$updatedCount} invoice(s) as unpaid successfully.");
    }

    public function bulkMarkCancelled(Request $request, CommissionService $commissionService): RedirectResponse
    {
        $data = $request->validate([
            'invoice_ids' => ['required', 'array'],
            'invoice_ids.*' => ['exists:invoices,id'],
        ]);

        $invoices = Invoice::whereIn('id', $data['invoice_ids'])->get();
        $updatedCount = 0;

        foreach ($invoices as $invoice) {
            if ($invoice->status === 'cancelled') {
                continue;
            }

            $previousStatus = $invoice->status;
            $invoice->update([
                'status' => 'cancelled',
                'paid_at' => null,
                'overdue_at' => null,
            ]);

            \App\Models\StatusAuditLog::logChange(
                Invoice::class,
                $invoice->id,
                $previousStatus,
                'cancelled',
                'admin_update',
                $request->user()?->id
            );

            try {
                $commissionService->reverseEarningsOnRefund($invoice);
            } catch (\Throwable $e) {
                SystemLogger::write('module', 'Commission update failed on invoice bulk cancel.', [
                    'invoice_id' => $invoice->id,
                    'error' => $e->getMessage(),
                ], level: 'error');
            }

            SystemLogger::write('activity', 'Invoice marked as cancelled (bulk).', [
                'invoice_id' => $invoice->id,
                'customer_id' => $invoice->customer_id,
            ], $request->user()?->id, $request->ip());

            $updatedCount++;
        }

        if ($updatedCount === 0) {
            return redirect()->back()->with('error', 'No invoices were selected or they are already cancelled.');
        }

        return redirect()->back()->with('status', "Marked {$updatedCount} invoice(s) as cancelled successfully.");
    }

    public function bulkDuplicate(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'invoice_ids' => ['required', 'array'],
            'invoice_ids.*' => ['exists:invoices,id'],
        ]);

        $invoices = Invoice::with('items')->whereIn('id', $data['invoice_ids'])->get();
        $duplicatedCount = 0;

        $dueDays = (int) Setting::getValue('invoice_due_days', 0);
        $issueDate = Carbon::today();
        $dueDate = $dueDays > 0 ? Carbon::today()->addDays($dueDays) : Carbon::today();

        DB::transaction(function () use ($invoices, $issueDate, $dueDate, &$duplicatedCount, $request) {
            foreach ($invoices as $originalInvoice) {
                $newInvoice = Invoice::create([
                    'customer_id' => $originalInvoice->customer_id,
                    'subscription_id' => $originalInvoice->subscription_id,
                    'project_id' => $originalInvoice->project_id,
                    'maintenance_id' => $originalInvoice->maintenance_id,
                    'number' => $this->billingService->nextInvoiceNumber(),
                    'status' => 'unpaid',
                    'issue_date' => $issueDate,
                    'due_date' => $dueDate,
                    'subtotal' => $originalInvoice->subtotal,
                    'tax_rate_percent' => $originalInvoice->tax_rate_percent,
                    'tax_mode' => $originalInvoice->tax_mode,
                    'tax_amount' => $originalInvoice->tax_amount,
                    'late_fee' => 0,
                    'total' => $originalInvoice->total,
                    'currency' => $originalInvoice->currency,
                    'notes' => $originalInvoice->notes,
                    'type' => 'manual',
                ]);

                foreach ($originalInvoice->items as $item) {
                    InvoiceItem::create([
                        'invoice_id' => $newInvoice->id,
                        'description' => $item->description,
                        'quantity' => $item->quantity,
                        'unit_price' => $item->unit_price,
                        'line_total' => $item->line_total,
                    ]);
                }

                SystemLogger::write('activity', 'Invoice duplicated (bulk).', [
                    'original_invoice_id' => $originalInvoice->id,
                    'new_invoice_id' => $newInvoice->id,
                    'customer_id' => $newInvoice->customer_id,
                ], $request->user()?->id, $request->ip());

                $duplicatedCount++;
            }
        });

        if ($duplicatedCount === 0) {
            return redirect()->back()->with('error', 'No invoices were selected.');
        }

        return redirect()->back()->with('status', "Duplicated {$duplicatedCount} invoice(s) successfully.");
    }

    public function bulkMerge(Request $request, InvoiceVatService $vatService, CommissionService $commissionService): RedirectResponse
    {
        $data = $request->validate([
            'invoice_ids' => ['required', 'array', 'min:2'],
            'invoice_ids.*' => ['exists:invoices,id'],
        ]);

        $invoices = Invoice::with('items')->whereIn('id', $data['invoice_ids'])->get();

        if ($invoices->count() < 2) {
            return redirect()->back()->with('error', 'Select at least 2 invoices to merge.');
        }

        $customerId = $invoices->first()->customer_id;
        $currency = $invoices->first()->currency;

        foreach ($invoices as $invoice) {
            if ($invoice->customer_id !== $customerId) {
                return redirect()->back()->with('error', 'All selected invoices must belong to the same customer.');
            }
            if ($invoice->currency !== $currency) {
                return redirect()->back()->with('error', 'All selected invoices must have the same currency.');
            }
        }

        $dueDays = (int) Setting::getValue('invoice_due_days', 0);
        $issueDate = Carbon::today();
        $dueDate = $dueDays > 0 ? Carbon::today()->addDays($dueDays) : Carbon::today();

        $aggregatedItems = [];
        $subtotal = 0.0;
        $originalInvoiceNumbers = [];

        foreach ($invoices as $invoice) {
            $numberDisplay = is_numeric($invoice->number) ? (string) $invoice->number : (string) $invoice->id;
            $originalInvoiceNumbers[] = '#'.$numberDisplay;

            foreach ($invoice->items as $item) {
                $aggregatedItems[] = [
                    'description' => $item->description." (From invoice #{$numberDisplay})",
                    'quantity' => $item->quantity,
                    'unit_price' => $item->unit_price,
                    'line_total' => $item->line_total,
                ];
                $subtotal += (float) $item->line_total;
            }
        }

        $taxData = $vatService->calculateTotals($subtotal, 0.0, $issueDate);

        $mergedInvoiceNotes = 'Merged from invoices: '.implode(', ', $originalInvoiceNumbers);

        $newInvoice = DB::transaction(function () use (
            $customerId,
            $currency,
            $issueDate,
            $dueDate,
            $subtotal,
            $taxData,
            $mergedInvoiceNotes,
            $aggregatedItems,
            $invoices,
            $commissionService,
            $request
        ) {
            $newInvoice = Invoice::create([
                'customer_id' => $customerId,
                'number' => $this->billingService->nextInvoiceNumber(),
                'status' => 'unpaid',
                'issue_date' => $issueDate,
                'due_date' => $dueDate,
                'subtotal' => $subtotal,
                'tax_rate_percent' => $taxData['tax_rate_percent'],
                'tax_mode' => $taxData['tax_mode'],
                'tax_amount' => $taxData['tax_amount'],
                'late_fee' => 0,
                'total' => $taxData['total'],
                'currency' => $currency,
                'notes' => $mergedInvoiceNotes,
                'type' => 'manual',
            ]);

            foreach ($aggregatedItems as $item) {
                InvoiceItem::create([
                    'invoice_id' => $newInvoice->id,
                    'description' => $item['description'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'line_total' => $item['line_total'],
                ]);
            }

            $newInvoiceNumber = is_numeric($newInvoice->number) ? (string) $newInvoice->number : (string) $newInvoice->id;

            foreach ($invoices as $originalInvoice) {
                $previousStatus = $originalInvoice->status;
                $originalNotes = $originalInvoice->notes ? $originalInvoice->notes."\n" : '';
                $cancelNote = "Cancelled and merged into invoice #{$newInvoiceNumber}.";

                $originalInvoice->update([
                    'status' => 'cancelled',
                    'paid_at' => null,
                    'overdue_at' => null,
                    'notes' => $originalNotes.$cancelNote,
                ]);

                \App\Models\StatusAuditLog::logChange(
                    Invoice::class,
                    $originalInvoice->id,
                    $previousStatus,
                    'cancelled',
                    'admin_update',
                    $request->user()?->id
                );

                try {
                    $commissionService->reverseEarningsOnRefund($originalInvoice);
                } catch (\Throwable $e) {
                    SystemLogger::write('module', 'Commission update failed on merge invoice cancellation.', [
                        'invoice_id' => $originalInvoice->id,
                        'error' => $e->getMessage(),
                    ], level: 'error');
                }

                SystemLogger::write('activity', 'Invoice merged and cancelled (bulk).', [
                    'original_invoice_id' => $originalInvoice->id,
                    'new_invoice_id' => $newInvoice->id,
                    'customer_id' => $customerId,
                ], $request->user()?->id, $request->ip());
            }

            return $newInvoice;
        });

        return redirect()->back()->with('status', "Merged selected invoices into new invoice #{$newInvoice->number} successfully.");
    }

    private function statusClass(string $status): string
    {
        return match ($status) {
            'paid' => 'bg-emerald-100 text-emerald-700',
            'overdue' => 'bg-rose-100 text-rose-700',
            'unpaid' => 'bg-amber-100 text-amber-700',
            'cancelled', 'refunded' => 'bg-slate-100 text-slate-700',
            default => 'bg-slate-100 text-slate-700',
        };
    }

    private function effectiveInvoiceStatus(string $status, float $outstandingAmount): string
    {
        if (in_array($status, ['unpaid', 'overdue'], true) && $outstandingAmount <= 0.009) {
            return 'paid';
        }

        return $status;
    }

    private function outstandingAmountSql(): string
    {
        return "(COALESCE(total, 0) - COALESCE((SELECT SUM(CASE WHEN type IN ('payment', 'credit') THEN amount ELSE 0 END) FROM accounting_entries WHERE accounting_entries.invoice_id = invoices.id), 0))";
    }

    private function formatMoney(string $currency, float $amount): string
    {
        return sprintf('%s %s', $currency, number_format($amount, 2));
    }

    private function statusTitle(?string $status): string
    {
        return match ($status) {
            'paid' => 'Paid Invoices',
            'unpaid' => 'Unpaid Invoices',
            'overdue' => 'Overdue Invoices',
            'cancelled' => 'Cancelled Invoices',
            'refunded' => 'Refunded Invoices',
            default => 'All Invoices',
        };
    }

    private function statusListUrl(?string $status, ?Project $project = null): string
    {
        if ($project) {
            return route('admin.projects.invoices', $project);
        }

        return match ($status) {
            'paid' => route('admin.invoices.paid'),
            'unpaid' => route('admin.invoices.unpaid'),
            'overdue' => route('admin.invoices.overdue'),
            'cancelled' => route('admin.invoices.cancelled'),
            'refunded' => route('admin.invoices.refunded'),
            default => route('admin.invoices.index'),
        };
    }
}
