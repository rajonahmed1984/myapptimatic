<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\License;
use App\Models\LicenseDomain;
use App\Jobs\ProvisionMyBuildingJob;
use App\Models\Order;
use App\Models\MyBuildingProvision;
use App\Models\Plan;
use App\Services\AdminNotificationService;
use App\Services\BillingService;
use App\Services\ClientNotificationService;
use App\Services\MyBuildingProvisioner;
use App\Support\SystemLogger;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response as InertiaResponse;

class OrderController extends Controller
{
    public function index(Request $request): InertiaResponse
    {
        $status = $request->query('status');
        $search = trim((string) $request->query('search', ''));
        $allowed = ['pending', 'accepted', 'cancelled'];

        $ordersQuery = Order::query()
            ->with(['customer', 'plan.product', 'invoice'])
            ->latest();

        if ($status === 'pending') {
            $ordersQuery->pending();
        } elseif ($status && in_array($status, $allowed, true)) {
            $ordersQuery->where('status', $status);
        }

        if ($search !== '') {
            $ordersQuery->where(function ($q) use ($search) {
                $q->where('order_number', 'like', "%{$search}%")
                  ->orWhere('status', 'like', "%{$search}%")
                  ->orWhereHas('customer', function ($cq) use ($search) {
                      $cq->where('name', 'like', "%{$search}%")
                         ->orWhere('email', 'like', "%{$search}%");
                  })
                  ->orWhereHas('plan', function ($pq) use ($search) {
                      $pq->where('name', 'like', "%{$search}%")
                         ->orWhereHas('product', function ($prodq) use ($search) {
                             $prodq->where('name', 'like', "%{$search}%");
                         });
                  });
            });
        }

        $orders = $ordersQuery->paginate(30)->withQueryString();

        return Inertia::render(
            'Admin/Orders/Index',
            $this->indexInertiaProps($orders, $status, $search)
        );
    }

    public function show(Order $order): InertiaResponse
    {
        $order->load([
            'customer',
            'plan.product.plans',
            'invoice',
            'subscription.licenses.domains',
            'approver',
            'canceller',
        ]);

        $planOptions = $order->plan?->product?->plans?->where('is_active', true) ?? collect();
        $intervalOptions = $planOptions
            ->pluck('interval')
            ->filter()
            ->unique()
            ->values();

        return Inertia::render(
            'Admin/Orders/Show',
            $this->showInertiaProps($order, $planOptions, $intervalOptions)
        );
    }

    public function approve(
        Request $request,
        Order $order,
        AdminNotificationService $adminNotifications,
        ClientNotificationService $clientNotifications
    ): RedirectResponse {
        if ($order->status !== 'pending') {
            return back()->with('status', 'Order already processed.');
        }

        $subscription = $order->subscription;
        if (! $subscription) {
            return back()->withErrors(['license_key' => 'No subscription found for this order.']);
        }

        $license = $subscription->licenses()->first();

        $data = $request->validate([
            'license_key' => [
                'required',
                'string',
                'max:255',
                Rule::unique('licenses', 'license_key')->ignore($license?->id),
            ],
            'license_url' => ['required', 'string', 'max:255'],
        ]);

        $domain = $this->normalizeDomain($data['license_url']);
        if (! $domain) {
            return back()->withErrors(['license_url' => 'Invalid URL format. Use a valid domain or URL.']);
        }

        $order->update([
            'status' => 'accepted',
            'approved_by' => auth()->id(),
            'approved_at' => Carbon::now(),
        ]);

        $subscription->update([
            'status' => 'active',
        ]);

        if (! $license) {
            $license = License::create([
                'subscription_id' => $subscription->id,
                'product_id' => $order->product_id ?? $subscription->plan?->product_id,
                'license_key' => $data['license_key'],
                'status' => 'active',
                'starts_at' => $subscription->start_date ?? Carbon::today()->toDateString(),
                'expires_at' => $subscription->current_period_end,
                'max_domains' => 1,
            ]);
        } else {
            $license->update([
                'license_key' => $data['license_key'],
                'status' => 'active',
            ]);
        }

        LicenseDomain::updateOrCreate(
            [
                'license_id' => $license->id,
                'domain' => $domain,
            ],
            [
                'status' => 'active',
                'verified_at' => Carbon::now(),
            ]
        );

        $license->domains()
            ->where('domain', '!=', $domain)
            ->update(['status' => 'revoked']);

        // MyBuilding orders create the building inside the customer's
        // installation. A failure here must never undo an accepted order, so
        // it is reported and left retryable from the MyBuilding page.
        $provisionWarning = $this->provisionMyBuilding($order, $license, $data['license_url']);

        $clientNotifications->sendOrderAccepted($order);
        $adminNotifications->sendOrderAccepted($order);

        SystemLogger::write('activity', 'Order approved.', [
            'order_id' => $order->id,
            'customer_id' => $order->customer_id,
            'subscription_id' => $subscription->id,
            'invoice_id' => $order->invoice_id,
        ], $request->user()?->id, $request->ip());

        if ($provisionWarning) {
            return back()
                ->with('status', 'Order accepted.')
                ->withErrors(['provision' => $provisionWarning]);
        }

        return back()->with('status', 'Order accepted.');
    }

    /**
     * Hand a MyBuilding order over to the customer's installation.
     *
     * @return string|null  a warning to surface, or null when nothing to do
     */
    private function provisionMyBuilding(Order $order, License $license, string $licenseUrl): ?string
    {
        $slug = $license->product?->slug ?? $order->product?->slug;

        if ($slug !== config('mybuilding.product_slug')) {
            return null;
        }

        $provision = MyBuildingProvision::where('license_id', $license->id)
            ->orWhere('order_id', $order->id)
            ->first();

        if (!$provision) {
            return 'This is a MyBuilding order but no building details were captured. '
                . 'Add them on the MyBuilding page, then provision it.';
        }

        // The approved domain is where the building has to be created.
        $installUrl = $provision->install_url ?: $this->installUrlFrom($licenseUrl);

        $provision->forceFill([
            'license_id' => $license->id,
            'order_id' => $provision->order_id ?: $order->id,
            'customer_id' => $provision->customer_id ?: $order->customer_id,
            'install_url' => $installUrl,
        ])->save();

        if (!app(MyBuildingProvisioner::class)->configured()) {
            return 'Order accepted, but MYBUILDING_PROVISION_SECRET is not configured, so the building was not created.';
        }

        // Queued: accepting an order must not wait on the customer's server,
        // and a brief outage there retries itself.
        ProvisionMyBuildingJob::dispatch($provision->id);

        return null;
    }

    /**
     * The licensed domain is stored bare; the installation needs a full URL.
     */
    private function installUrlFrom(string $licenseUrl): string
    {
        $trimmed = trim($licenseUrl);

        if (str_starts_with($trimmed, 'http://') || str_starts_with($trimmed, 'https://')) {
            return rtrim($trimmed, '/');
        }

        $host = $this->normalizeDomain($trimmed) ?: $trimmed;
        $scheme = in_array($host, ['localhost', '127.0.0.1'], true) || str_starts_with($host, '127.0.0.1')
            ? 'http'
            : 'https';

        return $scheme . '://' . $host;
    }

    public function cancel(Order $order, AdminNotificationService $adminNotifications): RedirectResponse
    {
        if ($order->status !== 'pending') {
            return back()->with('status', 'Order already processed.');
        }

        $order->update([
            'status' => 'cancelled',
            'cancelled_by' => auth()->id(),
            'cancelled_at' => Carbon::now(),
        ]);

        if ($order->invoice) {
            $order->invoice->update([
                'status' => 'cancelled',
            ]);
        }

        if ($order->subscription) {
            $order->subscription->update([
                'status' => 'cancelled',
                'auto_renew' => false,
                'cancelled_at' => Carbon::now(),
            ]);

            $order->subscription->licenses()
                ->whereIn('status', ['active', 'pending', 'suspended'])
                ->update(['status' => 'revoked']);
        }

        $adminNotifications->sendOrderCancelled($order->fresh(['customer', 'plan.product', 'invoice']));

        SystemLogger::write('activity', 'Order cancelled.', [
            'order_id' => $order->id,
            'customer_id' => $order->customer_id,
            'subscription_id' => $order->subscription_id,
            'invoice_id' => $order->invoice_id,
        ]);

        return back()->with('status', 'Order cancelled.');
    }

    public function updatePlan(Request $request, Order $order, BillingService $billingService): RedirectResponse
    {
        if (! in_array($order->status, ['pending', 'accepted'], true)) {
            return back()->with('status', 'Only pending or accepted orders can change interval.');
        }

        $data = $request->validate([
            'plan_id' => ['nullable', Rule::exists('plans', 'id')],
            'interval' => ['nullable', Rule::in(['monthly', 'yearly'])],
        ]);

        if (empty($data['plan_id']) && empty($data['interval'])) {
            return back()->withErrors(['interval' => 'Select an interval or plan.']);
        }

        $plan = null;

        if (! empty($data['plan_id'])) {
            $plan = Plan::query()->with('product')->findOrFail($data['plan_id']);
        }

        if (! $plan && ! empty($data['interval'])) {
            $planQuery = Plan::query()
                ->with('product')
                ->where('product_id', $order->product_id)
                ->where('interval', $data['interval'])
                ->where('is_active', true);

            if ($order->plan?->name) {
                $plan = (clone $planQuery)->where('name', $order->plan->name)->first();
            }

            $plan ??= $planQuery->orderBy('price')->first();
        }

        if (! $plan) {
            return back()->withErrors(['interval' => 'No matching plan found for this interval.']);
        }

        if ($order->product_id && $plan->product_id !== $order->product_id) {
            return back()->withErrors(['plan_id' => 'Selected plan does not match the order product.']);
        }

        $order->update([
            'plan_id' => $plan->id,
            'product_id' => $plan->product_id,
        ]);

        if ($order->subscription) {
            $subscription = $order->subscription;
            $startDate = Carbon::parse($subscription->current_period_start ?? $subscription->start_date ?? now());
            $periodEnd = $plan->interval === 'monthly'
                ? $startDate->copy()->endOfMonth()
                : $startDate->copy()->addYear();
            $nextInvoiceAt = $plan->interval === 'monthly'
                ? $periodEnd->copy()->addDay()
                : $periodEnd->copy();

            $subscription->update([
                'plan_id' => $plan->id,
                'current_period_end' => $periodEnd->toDateString(),
                'next_invoice_at' => $nextInvoiceAt->toDateString(),
            ]);
        }

        if ($order->invoice) {
            $billingService->recalculateInvoice($order->invoice->fresh('subscription.plan', 'items'));
        }

        SystemLogger::write('activity', 'Order updated.', [
            'order_id' => $order->id,
            'customer_id' => $order->customer_id,
            'plan_id' => $plan->id,
            'interval' => $plan->interval,
        ], $request->user()?->id, $request->ip());

        return back()->with('status', 'Order interval updated.');
    }

    public function updateAmounts(Request $request, Order $order, BillingService $billingService): RedirectResponse
    {
        if (! in_array($order->status, ['pending', 'accepted'], true)) {
            return back()->with('status', 'Only pending or accepted orders can update billing amounts.');
        }

        $data = $request->validate([
            'invoice_total' => ['nullable', 'numeric', 'min:0'],
            'recurring_amount' => ['nullable', 'numeric', 'min:0'],
        ]);

        $invoiceTotalProvided = array_key_exists('invoice_total', $data) && $data['invoice_total'] !== null && $data['invoice_total'] !== '';
        $recurringAmountProvided = array_key_exists('recurring_amount', $data) && $data['recurring_amount'] !== null && $data['recurring_amount'] !== '';

        if (! $invoiceTotalProvided && ! $recurringAmountProvided) {
            return back()->withErrors([
                'invoice_total' => 'Enter invoice total or recurring amount.',
            ]);
        }

        $invoice = $order->invoice?->fresh(['items']);
        $subscription = $order->subscription;

        $errors = [];
        if ($invoiceTotalProvided && ! $invoice) {
            $errors['invoice_total'] = 'No invoice found for this order.';
        }
        if ($recurringAmountProvided && ! $subscription) {
            $errors['recurring_amount'] = 'No subscription found for this order.';
        }
        if ($errors !== []) {
            return back()->withErrors($errors);
        }

        if ($recurringAmountProvided && $subscription) {
            $subscription->update([
                'subscription_amount' => round((float) $data['recurring_amount'], 2),
            ]);

            if ($invoice && in_array((string) $invoice->status, ['unpaid', 'overdue'], true)) {
                $billingService->recalculateInvoice($invoice->fresh('subscription.plan', 'items'));
                $invoice = $invoice->fresh(['items']);
            }
        }

        if ($invoiceTotalProvided && $invoice) {
            $desiredTotal = round((float) $data['invoice_total'], 2);
            $lateFee = (float) ($invoice->late_fee ?? 0);
            if ($desiredTotal < $lateFee) {
                return back()->withErrors([
                    'invoice_total' => 'Invoice total cannot be lower than late fee amount.',
                ]);
            }

            $ratePercent = $invoice->tax_rate_percent !== null ? (float) $invoice->tax_rate_percent : null;
            $mode = (string) ($invoice->tax_mode ?? '');
            $base = max(0, $desiredTotal - $lateFee);

            $subtotal = $base;
            $taxAmount = null;

            if ($ratePercent !== null && $ratePercent > 0) {
                if ($mode === 'exclusive') {
                    $subtotal = $base / (1 + ($ratePercent / 100));
                    $taxAmount = $base - $subtotal;
                } elseif ($mode === 'inclusive') {
                    $subtotal = $base;
                    $taxAmount = $subtotal * ($ratePercent / (100 + $ratePercent));
                }
            }

            $subtotal = round($subtotal, 2);
            $taxAmount = $taxAmount !== null ? round($taxAmount, 2) : null;

            $invoice->update([
                'subtotal' => $subtotal,
                'tax_amount' => $taxAmount,
                'total' => $desiredTotal,
            ]);

            if ($invoice->items->count() === 1) {
                $item = $invoice->items->first();
                if ($item) {
                    $item->update([
                        'quantity' => 1,
                        'unit_price' => $subtotal,
                        'line_total' => $subtotal,
                    ]);
                }
            }
        }

        SystemLogger::write('activity', 'Order billing amounts updated.', [
            'order_id' => $order->id,
            'customer_id' => $order->customer_id,
            'invoice_id' => $order->invoice_id,
            'subscription_id' => $order->subscription_id,
            'invoice_total' => $invoiceTotalProvided ? round((float) $data['invoice_total'], 2) : null,
            'recurring_amount' => $recurringAmountProvided ? round((float) $data['recurring_amount'], 2) : null,
        ], $request->user()?->id, $request->ip());

        return back()->with('status', 'Order billing amounts updated.');
    }

    public function destroy(Order $order): RedirectResponse
    {
        SystemLogger::write('activity', 'Order deleted.', [
            'order_id' => $order->id,
            'customer_id' => $order->customer_id,
            'status' => $order->status,
        ]);

        $order->delete();

        return redirect()->route('admin.orders.index')
            ->with('status', 'Order deleted.');
    }

    private function normalizeDomain(string $input): ?string
    {
        $value = trim(strtolower($input));

        if (Str::startsWith($value, ['http://', 'https://'])) {
            $value = parse_url($value, PHP_URL_HOST) ?: '';
        }

        $value = preg_replace('/^www\./', '', $value);

        if ($value === '' || ! preg_match('/^[a-z0-9.-]+$/', $value)) {
            return null;
        }

        return $value;
    }

    private function indexInertiaProps(LengthAwarePaginator $orders, ?string $status, ?string $search = ''): array
    {
        $dateFormat = config('app.date_format', 'd-m-Y');

        return [
            'pageTitle' => 'Orders',
            'status' => (string) ($status ?? ''),
            'search' => (string) ($search ?? ''),
            'routes' => [
                'index' => route('admin.orders.index'),
            ],
            'orders' => collect($orders->items())->map(function (Order $order) use ($dateFormat) {
                $plan = $order->plan;
                $product = $plan?->product;
                $service = $product
                    ? $product->name.' - '.($plan?->name ?? '')
                    : ($plan?->name ?? '--');

                $invoice = $order->invoice;
                $invoiceNumber = '--';
                $invoiceAmount = '--';

                if ($invoice) {
                    $invoiceNumber = is_numeric($invoice->number) ? (string) $invoice->number : (string) $invoice->id;
                    $invoiceAmount = trim((string) (($invoice->currency ?? '').' '.number_format((float) ($invoice->total ?? 0), 2)));
                }

                return [
                    'id' => $order->id,
                    'order_number' => (string) ($order->order_number ?? $order->id),
                    'customer_name' => (string) ($order->customer?->name ?? '--'),
                    'service' => (string) $service,
                    'status' => (string) $order->status,
                    'status_label' => ucfirst((string) $order->status),
                    'invoice_number' => $invoiceNumber,
                    'invoice_amount' => $invoiceAmount,
                    'created_at_display' => $order->created_at?->format($dateFormat) ?? '--',
                    // Keep legacy key false to prevent older cached bundles from showing Accept action.
                    'can_process' => false,
                    'can_cancel' => (string) $order->status === 'pending',
                    'routes' => [
                        'show' => route('admin.orders.show', $order),
                        'invoice_show' => $invoice ? route('admin.invoices.show', $invoice) : null,
                        'cancel' => route('admin.orders.cancel', $order),
                        'destroy' => route('admin.orders.destroy', $order),
                    ],
                ];
            })->values()->all(),
            'pagination' => [
                'has_pages' => $orders->hasPages(),
                'previous_url' => $orders->previousPageUrl(),
                'next_url' => $orders->nextPageUrl(),
            ],
        ];
    }

    private function showInertiaProps(Order $order, $planOptions, $intervalOptions): array
    {
        $dateFormat = config('app.date_format', 'd-m-Y');
        $invoice = $order->invoice;
        $recurringAmount = $order->subscription?->subscription_amount;
        $planInterval = strtolower((string) ($order->plan?->interval ?? ''));
        $billingCycleDays = match ($planInterval) {
            'monthly' => 30,
            'yearly' => 365,
            default => null,
        };

        if ($recurringAmount === null && $order->plan) {
            $recurringAmount = (float) $order->plan->price;
        }

        return [
            'pageTitle' => 'Order Details',
            'order' => [
                'id' => $order->id,
                'plan_id' => $order->plan_id ? (int) $order->plan_id : null,
                'order_number' => (string) ($order->order_number ?? $order->id),
                'status' => (string) $order->status,
                'status_label' => ucfirst((string) $order->status),
                'customer_name' => (string) ($order->customer?->name ?? '--'),
                'customer_email' => (string) ($order->customer?->email ?? '--'),
                'plan_name' => (string) ($order->plan?->name ?? '--'),
                'product_name' => (string) ($order->plan?->product?->name ?? '--'),
                'plan_interval' => $planInterval,
                'plan_interval_label' => $planInterval !== '' ? ucfirst($planInterval) : '',
                'billing_cycle_days' => $billingCycleDays,
                'created_at_iso' => $order->created_at?->toDateString(),
                'created_at_display' => $order->created_at?->format(config('app.datetime_format', 'd-m-Y h:i A')) ?? '--',
                'approved_at_display' => $order->approved_at?->format(config('app.datetime_format', 'd-m-Y h:i A')) ?? '--',
                'cancelled_at_display' => $order->cancelled_at?->format(config('app.datetime_format', 'd-m-Y h:i A')) ?? '--',
                'invoice_number' => $invoice ? (string) ($invoice->number ?? $invoice->id) : '--',
                'invoice_currency' => (string) ($invoice?->currency ?? ''),
                'invoice_total_display' => $invoice
                    ? trim((string) (($invoice->currency ?? '').' '.number_format((float) ($invoice->total ?? 0), 2)))
                    : '--',
                'invoice_total_value' => $invoice ? number_format((float) ($invoice->total ?? 0), 2, '.', '') : '',
                'recurring_amount_value' => $recurringAmount !== null ? number_format((float) $recurringAmount, 2, '.', '') : '',
                'invoice_url' => $invoice ? route('admin.invoices.show', $invoice) : null,
                'license_key' => (string) ($order->subscription?->licenses?->first()?->license_key ?? ''),
                'license_url' => (string) ($order->subscription?->licenses?->first()?->domains?->firstWhere('status', 'active')?->domain ?? ''),
            ],
            'plan_options' => collect($planOptions)->values()->map(fn (Plan $plan) => [
                'id' => $plan->id,
                'name' => (string) $plan->name,
                'interval' => (string) $plan->interval,
                'price' => (float) $plan->price,
                'currency' => (string) ($plan->currency ?? ''),
            ])->all(),
            'interval_options' => collect($intervalOptions)->values()->map(fn ($interval) => (string) $interval)->all(),
            'routes' => [
                'index' => route('admin.orders.index'),
                'approve' => route('admin.orders.approve', $order),
                'cancel' => route('admin.orders.cancel', $order),
                'update_plan' => route('admin.orders.plan', $order),
                'update_amounts' => route('admin.orders.amounts', $order),
                'destroy' => route('admin.orders.destroy', $order),
            ],
        ];
    }
}
