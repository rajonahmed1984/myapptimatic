<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Employee;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Order;
use App\Models\Project;
use App\Models\ProjectMaintenance;
use App\Models\ProjectMessageRead;
use App\Models\ProjectTask;
use App\Models\ProjectTaskSubtask;
use App\Models\SalesRepresentative;
use App\Models\Setting;
use App\Models\Subscription;
use App\Models\User;
use App\Services\BillingService;
use App\Services\ChatAiSummaryCache;
use App\Services\CommissionService;
use App\Services\GeminiService;
use App\Services\InvoiceVatService;
use App\Services\ProjectStatusAiService;
use App\Services\TaskQueryService;
use App\Services\TaskStatusNotificationService;
use App\Support\AjaxResponse;
use App\Support\Currency;
use App\Support\SystemLogger;
use App\Support\TaskActivityLogger;
use App\Support\TaskAssignees;
use App\Support\TaskAssignmentManager;
use App\Support\TaskCompletionManager;
use App\Support\TaskSettings;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response as InertiaResponse;

class ProjectController extends Controller
{
    private const STATUSES = ['ongoing', 'hold', 'complete', 'cancel'];

    private const TYPES = ['software', 'website', 'other'];

    private const TASK_STATUSES = ['pending', 'in_progress', 'blocked', 'completed'];

    public function index(Request $request): InertiaResponse
    {
        $statusFilter = $request->query('status');
        $typeFilter = $request->query('type');
        $user = $request->user();
        $isAdmin = $user?->isAdmin();
        $employeeId = $user?->employee?->id;
        $salesRepId = \App\Models\SalesRepresentative::where('user_id', $user?->id)->value('id');

        $projects = Project::query()
            ->with(['customer', 'order', 'subscription', 'employees', 'salesRepresentatives'])
            ->withCount([
                'tasks as open_tasks_count' => fn ($q) => $q->whereIn('status', ['pending', 'in_progress', 'blocked', 'todo']),
                'tasks as done_tasks_count' => fn ($q) => $q->whereIn('status', ['completed', 'done']),
                'subtasks as open_subtasks_count' => fn ($q) => $q->where('is_completed', false),
            ])
            ->when($statusFilter, fn ($q) => $q->where('status', $statusFilter))
            ->when($typeFilter, fn ($q) => $q->where('type', $typeFilter))
            ->when(! $isAdmin && $user?->isClient(), fn ($q) => $q->where('customer_id', $user->customer_id))
            ->when(! $isAdmin && $user?->isEmployee() && $employeeId, fn ($q) => $q->whereHas('employees', fn ($sub) => $sub->whereKey($employeeId)))
            ->when(! $isAdmin && $user?->isSales() && $salesRepId, fn ($q) => $q->whereHas('salesRepresentatives', fn ($sub) => $sub->whereKey($salesRepId)))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return Inertia::render('Admin/Projects/Index', [
            'pageTitle' => 'All Projects',
            'projects' => $projects
                ->through(fn (Project $project) => $this->serializeProjectIndexRow($project))
                ->values(),
            'pagination' => $this->paginationPayload($projects),
            'statuses' => self::STATUSES,
            'types' => self::TYPES,
            'filters' => [
                'status' => $statusFilter,
                'type' => $typeFilter,
            ],
            'routes' => [
                'index' => route('admin.projects.index'),
                'create' => route('admin.projects.create'),
            ],
        ]);
    }

    public function all(Request $request)
    {
        return redirect()->route('admin.projects.index', $request->query());
    }

    public function create(Request $request): InertiaResponse
    {
        $defaultCurrency = strtoupper((string) Setting::getValue('currency', Currency::DEFAULT));
        if (! Currency::isAllowed($defaultCurrency)) {
            $defaultCurrency = Currency::DEFAULT;
        }

        $customers = Customer::orderBy('name')->get(['id', 'name', 'company_name']);
        $requestedCustomerId = $request->integer('customer_id');
        $selectedCustomerId = $customers->contains('id', $requestedCustomerId) ? (string) $requestedCustomerId : '';
        $employees = Employee::where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'designation', 'employment_type']);
        $salesReps = SalesRepresentative::where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'email']);

        $selectedSalesRepIds = collect(old('sales_rep_ids', []))
            ->map(fn ($id) => (int) $id)
            ->values();
        $selectedEmployeeIds = collect(old('employee_ids', []))
            ->map(fn ($id) => (int) $id)
            ->values();

        $tasks = old('tasks', [[
            'title' => '',
            'task_type' => 'feature',
            'priority' => 'medium',
            'descriptions' => [''],
            'start_date' => now()->toDateString(),
            'due_date' => '',
            'assignee' => '',
            'customer_visible' => false,
        ]]);
        return Inertia::render('Admin/Projects/Create', [
            'pageTitle' => 'New Project',
            'statuses' => self::STATUSES,
            'types' => self::TYPES,
            'customers' => $customers
                ->map(fn (Customer $customer) => [
                    'id' => $customer->id,
                    'display_name' => $customer->display_name,
                ])
                ->values(),
            'orders' => Order::latest()->limit(50)->get(['id', 'order_number']),
            'subscriptions' => Subscription::latest()->limit(50)->get(['id']),
            'invoices' => Invoice::latest('issue_date')->limit(50)->get(['id', 'number', 'total']),
            'employees' => $employees->map(fn (Employee $employee) => [
                'id' => $employee->id,
                'name' => $employee->name,
                'designation' => $employee->designation,
                'employment_type' => $employee->employment_type,
                'selected' => $selectedEmployeeIds->contains($employee->id),
                'contract_amount' => old('contract_employee_amounts.'.$employee->id, ''),
            ])->values(),
            'salesReps' => $salesReps->map(fn (SalesRepresentative $salesRep) => [
                'id' => $salesRep->id,
                'name' => $salesRep->name,
                'email' => $salesRep->email,
                'selected' => $selectedSalesRepIds->contains($salesRep->id),
                'amount' => old('sales_rep_amounts.'.$salesRep->id, 0),
            ])->values(),
            'currencyOptions' => Currency::allowed(),
            'taskTypeOptions' => TaskSettings::taskTypeOptions(),
            'priorityOptions' => TaskSettings::priorityOptions(),
            'form' => [
                'name' => old('name'),
                'customer_id' => old('customer_id', $selectedCustomerId),
                'type' => old('type'),
                'status' => old('status'),
                'start_date' => old('start_date'),
                'expected_end_date' => old('expected_end_date'),
                'due_date' => old('due_date'),
                'notes' => old('notes'),
                'total_budget' => old('total_budget'),
                'initial_payment_amount' => old('initial_payment_amount'),
                'currency' => old('currency', $defaultCurrency),
                'budget_amount' => old('budget_amount'),
                'software_overhead' => old('software_overhead'),
                'website_overhead' => old('website_overhead'),
                'selected_sales_rep_ids' => $selectedSalesRepIds->all(),
                'selected_employee_ids' => $selectedEmployeeIds->all(),
            ],
            'tasks' => $tasks,
            'routes' => [
                'index' => route('admin.projects.index'),
                'store' => route('admin.projects.store'),
            ],
        ]);
    }

    public function edit(Project $project): InertiaResponse
    {
        $project->loadMissing(['salesRepresentatives', 'employees']);

        $employees = Employee::where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'designation', 'employment_type']);
        $salesReps = SalesRepresentative::where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'email']);

        $selectedSalesRepIds = collect(old('sales_rep_ids', $project->salesRepresentatives->pluck('id')->all()))
            ->map(fn ($id) => (int) $id)
            ->values();
        $selectedEmployeeIds = collect(old('employee_ids', $project->employees->pluck('id')->all()))
            ->map(fn ($id) => (int) $id)
            ->values();

        $assignedContractCount = $project->employees->where('employment_type', 'contract')->count();

        return Inertia::render('Admin/Projects/Edit', [
            'pageTitle' => 'Edit Project #'.$project->id,
            'project' => [
                'id' => $project->id,
                'name' => $project->name,
                'contract_file_path' => $project->contract_file_path,
                'contract_original_name' => $project->contract_original_name,
                'proposal_file_path' => $project->proposal_file_path,
                'proposal_original_name' => $project->proposal_original_name,
            ],
            'statuses' => self::STATUSES,
            'types' => self::TYPES,
            'customers' => Customer::orderBy('name')
                ->get(['id', 'name', 'company_name'])
                ->map(fn (Customer $customer) => [
                    'id' => $customer->id,
                    'display_name' => $customer->display_name,
                ])
                ->values(),
            'employees' => $employees->map(function (Employee $employee) use ($project, $selectedEmployeeIds, $assignedContractCount) {
                $isAssigned = $selectedEmployeeIds->contains($employee->id);
                $defaultContractAmount = ($assignedContractCount === 1 && $isAssigned && $employee->employment_type === 'contract')
                    ? ($project->contract_amount ?? '')
                    : '';

                return [
                    'id' => $employee->id,
                    'name' => $employee->name,
                    'designation' => $employee->designation,
                    'employment_type' => $employee->employment_type,
                    'selected' => $isAssigned,
                    'contract_amount' => old('contract_employee_amounts.'.$employee->id, $defaultContractAmount),
                ];
            })->values(),
            'salesReps' => $salesReps->map(function (SalesRepresentative $salesRep) use ($project, $selectedSalesRepIds) {
                $assignedRep = $project->salesRepresentatives->firstWhere('id', $salesRep->id);

                return [
                    'id' => $salesRep->id,
                    'name' => $salesRep->name,
                    'email' => $salesRep->email,
                    'selected' => $selectedSalesRepIds->contains($salesRep->id),
                    'amount' => old('sales_rep_amounts.'.$salesRep->id, $assignedRep?->pivot?->amount ?? 0),
                ];
            })->values(),
            'currencyOptions' => Currency::allowed(),
            'form' => [
                'name' => old('name', $project->name),
                'customer_id' => old('customer_id', $project->customer_id),
                'type' => old('type', $project->type),
                'status' => old('status', $project->status),
                'start_date' => old('start_date', optional($project->start_date)->format(config('app.date_format', 'd-m-Y'))),
                'expected_end_date' => old('expected_end_date', optional($project->expected_end_date)->format(config('app.date_format', 'd-m-Y'))),
                'due_date' => old('due_date', optional($project->due_date)->format(config('app.date_format', 'd-m-Y'))),
                'notes' => old('notes', $project->notes),
                'total_budget' => old('total_budget', $project->total_budget),
                'initial_payment_amount' => old('initial_payment_amount', $project->initial_payment_amount),
                'currency' => old('currency', $project->currency),
                'budget_amount' => old('budget_amount', $project->budget_amount),
                'software_overhead' => old('software_overhead', $project->software_overhead),
                'website_overhead' => old('website_overhead', $project->website_overhead),
                'selected_sales_rep_ids' => $selectedSalesRepIds->all(),
                'selected_employee_ids' => $selectedEmployeeIds->all(),
            ],
            'moveRelatedCounts' => [
                'invoices' => (int) Invoice::where('project_id', $project->id)->count(),
                'maintenances' => (int) ProjectMaintenance::where('project_id', $project->id)->count(),
                'client_users' => (int) $project->projectClients()->count(),
            ],
            'routes' => [
                'index' => route('admin.projects.all'),
                'show' => route('admin.projects.show', $project),
                'update' => route('admin.projects.update', $project),
                'move_owner' => route('admin.projects.move-owner', $project),
                'download_contract' => $project->contract_file_path
                    ? route('admin.projects.download', ['project' => $project, 'type' => 'contract'])
                    : null,
                'download_proposal' => $project->proposal_file_path
                    ? route('admin.projects.download', ['project' => $project, 'type' => 'proposal'])
                    : null,
            ],
        ]);
    }

    public function store(Request $request, BillingService $billingService, InvoiceVatService $vatService, CommissionService $commissionService): RedirectResponse
    {
        $taskTypeOptions = array_keys(TaskSettings::taskTypeOptions());
        $priorityOptions = array_keys(TaskSettings::priorityOptions());
        $maxMb = TaskSettings::uploadMaxMb();

        $data = $request->validate([
            'name' => ['required', 'string', 'max:190'],
            'customer_id' => ['required', 'exists:customers,id'],
            'order_id' => ['nullable', 'exists:orders,id'],
            'subscription_id' => ['nullable', 'exists:subscriptions,id'],
            'advance_invoice_id' => ['nullable', 'exists:invoices,id'],
            'final_invoice_id' => ['nullable', 'exists:invoices,id'],
            'type' => ['required', 'in:software,website,other'],
            'status' => ['required', 'in:ongoing,hold,complete,cancel'],
            'start_date' => ['nullable', 'date'],
            'expected_end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'due_date' => ['nullable', 'date'],
            'description' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'total_budget' => ['required', 'numeric', 'min:0'],
            'initial_payment_amount' => ['required', 'numeric', 'min:0'],
            'currency' => ['required', 'string', 'size:3', Rule::in(Currency::allowed())],
            'budget_amount' => ['nullable', 'numeric', 'min:0'],
            'software_overhead' => ['nullable', 'numeric', 'min:0'],
            'website_overhead' => ['nullable', 'numeric', 'min:0'],
            'contract_file' => ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png,webp', 'max:10240'],
            'proposal_file' => ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png,webp', 'max:10240'],
            'sales_rep_ids' => ['array'],
            'sales_rep_ids.*' => ['exists:sales_representatives,id'],
            'sales_rep_amounts' => ['array'],
            'sales_rep_amounts.*' => ['nullable', 'numeric', 'min:0'],
            'employee_ids' => ['array'],
            'employee_ids.*' => ['exists:employees,id'],
            'contract_employee_amounts' => ['array'],
            'contract_employee_amounts.*' => ['nullable', 'numeric', 'min:0'],
            'tasks' => ['required', 'array', 'min:1'],
            'tasks.*.title' => ['required', 'string', 'max:255'],
            'tasks.*.descriptions' => ['nullable', 'array'],
            'tasks.*.descriptions.*' => ['nullable', 'string'],
            'tasks.*.task_type' => ['required', Rule::in($taskTypeOptions)],
            'tasks.*.priority' => ['nullable', Rule::in($priorityOptions)],
            'tasks.*.time_estimate_minutes' => ['nullable', 'integer', 'min:0'],
            'tasks.*.tags' => ['nullable', 'string'],
            'tasks.*.relationship_ids' => ['nullable', 'string'],
            'tasks.*.start_date' => ['required', 'date'],
            'tasks.*.due_date' => ['required', 'date'],
            'tasks.*.assignee' => ['required', 'string'], // format: type:id
            'tasks.*.attachment' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,pdf,docx,xlsx', 'max:'.($maxMb * 1024)],
            'tasks.*.customer_visible' => ['nullable', 'boolean'],
        ]);

        foreach ($data['tasks'] as $index => $task) {
            if (isset($task['start_date'], $task['due_date'])) {
                $start = Carbon::parse($task['start_date']);
                $due = Carbon::parse($task['due_date']);
                if ($due->lt($start)) {
                    return back()
                        ->withErrors(['tasks' => 'Task due date must be on or after start date.'])
                        ->withInput();
                }
            }

            if (($task['task_type'] ?? null) === 'upload' && ! $request->file("tasks.{$index}.attachment")) {
                return back()
                    ->withErrors(['tasks' => 'Upload tasks require at least one file.'])
                    ->withInput();
            }
        }

        $salesRepSync = [];
        if (! empty($data['sales_rep_ids'])) {
            $salesRepSync = $this->buildSalesRepSyncData($request, $data['sales_rep_ids']);
            $totalSalesRepAmount = array_sum(array_column($salesRepSync, 'amount'));
            if ($totalSalesRepAmount > (float) $data['total_budget']) {
                return back()
                    ->withErrors(['sales_rep_amounts' => 'Total sales rep amounts cannot exceed total budget.'])
                    ->withInput();
            }
        }

        $contractEmployeeTotal = null;
        $contractEmployeePayable = null;
        $contractEmployeePayoutStatus = null;

        $contractEmployeeIds = [];
        if (! empty($data['employee_ids'])) {
            $contractEmployeeIds = Employee::whereIn('id', $data['employee_ids'])
                ->where('employment_type', 'contract')
                ->pluck('id')
                ->all();
        }

        if (! empty($contractEmployeeIds)) {
            $amounts = $request->input('contract_employee_amounts', []);
            $errors = [];
            $contractEmployeeTotal = 0.0;

            foreach ($contractEmployeeIds as $employeeId) {
                $amount = $amounts[$employeeId] ?? null;
                if ($amount === null || $amount === '') {
                    $errors["contract_employee_amounts.{$employeeId}"] = 'Amount is required for contract employees.';

                    continue;
                }
                if (! is_numeric($amount) || (float) $amount < 0) {
                    $errors["contract_employee_amounts.{$employeeId}"] = 'Amount must be at least 0.';

                    continue;
                }

                $contractEmployeeTotal += (float) $amount;
            }

            if (! empty($errors)) {
                return back()->withErrors($errors)->withInput();
            }

            $isComplete = $data['status'] === 'complete';
            $contractEmployeePayable = $isComplete ? $contractEmployeeTotal : 0.0;
            $contractEmployeePayoutStatus = $isComplete ? 'payable' : 'earned';
        }

        $project = DB::transaction(function () use ($data, $request, $billingService, $vatService, $salesRepSync, $commissionService, $contractEmployeeTotal, $contractEmployeePayable, $contractEmployeePayoutStatus) {
            $project = Project::create([
                'name' => $data['name'],
                'customer_id' => $data['customer_id'],
                'order_id' => $data['order_id'] ?? null,
                'subscription_id' => $data['subscription_id'] ?? null,
                'advance_invoice_id' => $data['advance_invoice_id'] ?? null,
                'final_invoice_id' => $data['final_invoice_id'] ?? null,
                'type' => $data['type'],
                'status' => $data['status'],
                'start_date' => $data['start_date'] ?? null,
                'expected_end_date' => $data['expected_end_date'] ?? null,
                'due_date' => $data['due_date'] ?? null,
                'description' => $data['description'] ?? null,
                'notes' => $data['notes'] ?? null,
                'total_budget' => $data['total_budget'],
                'initial_payment_amount' => $data['initial_payment_amount'],
                'currency' => strtoupper($data['currency']),
                'sales_rep_ids' => $data['sales_rep_ids'] ?? [],
                'budget_amount' => $data['budget_amount'] ?? null,
                'software_overhead' => $data['software_overhead'] ?? null,
                'website_overhead' => $data['website_overhead'] ?? null,
                'contract_amount' => $contractEmployeeTotal,
                'contract_employee_total_earned' => $contractEmployeeTotal,
                'contract_employee_payable' => $contractEmployeePayable,
                'contract_employee_payout_status' => $contractEmployeePayoutStatus,
            ]);

            if (! empty($data['employee_ids'])) {
                $project->employees()->sync($data['employee_ids']);
            }

            if (! empty($data['sales_rep_ids'])) {
                $project->salesRepresentatives()->sync($salesRepSync);
                $commissionService->syncProjectEarnings($project, $salesRepSync);
            }

            foreach ($data['tasks'] as $index => $task) {
                $assignees = TaskAssignees::parse([$task['assignee']]);
                if (empty($assignees)) {
                    [$assignedType, $assignedId] = $this->parseAssignee($task['assignee']);
                    $assignees = [['type' => $assignedType, 'id' => $assignedId]];
                } else {
                    $assignedType = $assignees[0]['type'];
                    $assignedId = $assignees[0]['id'];
                }

                // Combine multiple descriptions with newlines
                $descriptions = $task['descriptions'] ?? [];
                $description = implode("\n", array_filter($descriptions));

                $projectTask = ProjectTask::create([
                    'project_id' => $project->id,
                    'title' => $task['title'],
                    'description' => $description ?: null,
                    'task_type' => $task['task_type'],
                    'status' => 'pending',
                    'priority' => $task['priority'] ?? 'medium',
                    'start_date' => $task['start_date'],
                    'due_date' => $task['due_date'],
                    'assigned_type' => $assignedType,
                    'assigned_id' => $assignedId,
                    'customer_visible' => (bool) ($task['customer_visible'] ?? false),
                    'created_by' => $request->user()?->id,
                    'time_estimate_minutes' => $task['time_estimate_minutes'] ?? null,
                    'tags' => $this->parseTags($task['tags'] ?? null),
                    'relationship_ids' => $this->parseRelationships($task['relationship_ids'] ?? null),
                ]);

                TaskAssignmentManager::sync($projectTask, $assignees);
                TaskActivityLogger::record($projectTask, $request, 'system', 'Task created.');

                $attachment = $request->file("tasks.{$index}.attachment");
                if ($attachment) {
                    $path = $this->storeTaskAttachment($attachment, $projectTask);
                    TaskActivityLogger::record($projectTask, $request, 'upload', null, [], $path);
                }
            }

            $issueDate = Carbon::today();
            $dueDays = (int) Setting::getValue('invoice_due_days');
            $dueDate = $issueDate->copy()->addDays($dueDays);

            $initialPayment = (float) $project->initial_payment_amount;
            $softwareOverhead = (float) ($project->software_overhead ?? 0);
            $websiteOverhead = (float) ($project->website_overhead ?? 0);
            $invoiceSubtotal = $initialPayment + $softwareOverhead + $websiteOverhead;

            $taxData = $vatService->calculateTotals($invoiceSubtotal, 0.0, $issueDate);

            $invoice = Invoice::create([
                'customer_id' => $project->customer_id,
                'project_id' => $project->id,
                'number' => $billingService->nextInvoiceNumber(),
                'status' => 'unpaid',
                'issue_date' => $issueDate->toDateString(),
                'due_date' => $dueDate->toDateString(),
                'subtotal' => $invoiceSubtotal,
                'tax_rate_percent' => $taxData['tax_rate_percent'],
                'tax_mode' => $taxData['tax_mode'],
                'tax_amount' => $taxData['tax_amount'],
                'late_fee' => 0,
                'total' => $taxData['total'],
                'currency' => $project->currency,
                'type' => 'project_initial_payment',
            ]);

            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'description' => sprintf('Initial payment for project %s', $project->name),
                'quantity' => 1,
                'unit_price' => $project->initial_payment_amount,
                'line_total' => $project->initial_payment_amount,
            ]);

            if ($softwareOverhead > 0) {
                InvoiceItem::create([
                    'invoice_id' => $invoice->id,
                    'description' => sprintf('Software overhead for project %s', $project->name),
                    'quantity' => 1,
                    'unit_price' => $softwareOverhead,
                    'line_total' => $softwareOverhead,
                ]);
            }

            if ($websiteOverhead > 0) {
                InvoiceItem::create([
                    'invoice_id' => $invoice->id,
                    'description' => sprintf('Website overhead for project %s', $project->name),
                    'quantity' => 1,
                    'unit_price' => $websiteOverhead,
                    'line_total' => $websiteOverhead,
                ]);
            }

            SystemLogger::write('activity', 'Project created.', [
                'project_id' => $project->id,
                'customer_id' => $project->customer_id,
                'order_id' => $project->order_id,
                'invoice_id' => $invoice->id,
            ], $request->user()?->id, $request->ip());

            $this->storeProjectFile($project, $request->file('contract_file'), 'contract');
            $this->storeProjectFile($project, $request->file('proposal_file'), 'proposal');

            return $project;
        });

        return redirect()->route('admin.projects.show', $project)
            ->with('status', 'Project created with initial tasks and invoice.');
    }

    public function show(Request $request, Project $project): InertiaResponse
    {
        $this->authorize('view', $project);

        $project->load([
            'customer',
            'order.invoice',
            'subscription',
            'advanceInvoice',
            'finalInvoice',
            'overheads.invoice',
            'employees',
            'salesRepresentatives',
            'maintenances' => fn ($query) => $query->withCount('invoices')->orderBy('next_billing_date'),
        ]);

        $user = $request->user();

        $statusCounts = $project->tasks()
            ->selectRaw('status, COUNT(*) as aggregate')
            ->groupBy('status')
            ->pluck('aggregate', 'status');

        $totalTasks = (int) $statusCounts->values()->sum();
        $inProgressTasks = (int) ($statusCounts['in_progress'] ?? 0);
        $completedTasks = (int) (($statusCounts['completed'] ?? 0) + ($statusCounts['done'] ?? 0));

        $initialInvoice = $project->invoices()
            ->where('type', 'project_initial_payment')
            ->latest('issue_date')
            ->first();

        $remainingBudgetInvoices = $project->invoices()
            ->where('type', 'project_remaining_budget')
            ->latest('issue_date')
            ->get();

        $readerType = 'user';
        $readerId = $user?->id;
        $lastReadId = null;
        if ($readerId) {
            $lastReadId = ProjectMessageRead::query()
                ->where('project_id', $project->id)
                ->where('reader_type', $readerType)
                ->where('reader_id', $readerId)
                ->value('last_read_message_id');
        }

        $projectChatUnreadCount = $project->messages()
            ->when($lastReadId, fn ($query) => $query->where('id', '>', $lastReadId))
            ->count();

        $tasks = app(TaskQueryService::class)->visibleTasksForUser($user)
            ->where('project_id', $project->id)
            ->with(['assignments.employee', 'assignments.salesRep', 'creator'])
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->paginate(25)
            ->withQueryString();

        $financials = $this->financials($project);

        $transferService = app(\App\Services\ProjectTransferService::class);
        $transferIneligibleReason = $transferService->eligibilityError($project);

        return Inertia::render('Admin/Projects/Show', [
            'pageTitle' => 'Project #'.$project->id,
            'project' => array_merge(
                $this->serializeProjectShow($project, $financials, (int) $projectChatUnreadCount),
                [
                    'transfer_eligible' => $transferIneligibleReason === null,
                    'transfer_ineligible_reason' => $transferIneligibleReason,
                ]
            ),
            'transferCustomers' => \App\Models\Customer::query()
                ->where('id', '!=', $project->customer_id)
                ->orderBy('name')
                ->get(['id', 'name'])
                ->map(fn ($c) => ['id' => (string) $c->id, 'name' => (string) $c->name])
                ->all(),
            'statuses' => self::STATUSES,
            'types' => self::TYPES,
            'taskStatuses' => self::TASK_STATUSES,
            'tasks' => $tasks
                ->through(fn (ProjectTask $task) => $this->serializeProjectTaskPreview($project, $task))
                ->values(),
            'tasksPagination' => $this->paginationPayload($tasks),
            'initialInvoice' => $initialInvoice ? $this->serializeProjectInvoice($initialInvoice) : null,
            'remainingBudgetInvoices' => $remainingBudgetInvoices
                ->map(fn (Invoice $invoice) => $this->serializeProjectInvoice($invoice))
                ->values(),
            'projectChatUnreadCount' => (int) $projectChatUnreadCount,
            'aiReady' => (bool) config('google_ai.api_key'),
            'taskStats' => [
                'total' => $totalTasks,
                'in_progress' => $inProgressTasks,
                'completed' => $completedTasks,
                'unread' => (int) $projectChatUnreadCount,
            ],
            'routes' => [
                'index' => route('admin.projects.index'),
                'edit' => route('admin.projects.edit', $project),
                'destroy' => route('admin.projects.destroy', $project),
                'complete' => route('admin.projects.complete', $project),
                'invoices' => route('admin.projects.invoices', $project),
                'tasks' => route('admin.projects.tasks.index', $project),
                'chat' => route('admin.projects.chat', $project),
                'ai_summary' => route('admin.projects.ai', $project),
                'invoice_remaining' => route('admin.projects.invoice-remaining', $project),
                'overheads_index' => route('admin.projects.overheads.index', $project),
                'overheads_store' => route('admin.projects.overheads.store', $project),
                'maintenance_create' => route('admin.project-maintenances.create', ['project_id' => $project->id]),
                'transfer_store' => route('admin.projects.transfers.store', $project),
            ],
        ]);
    }

    public function aiSummary(
        Request $request,
        Project $project,
        ProjectStatusAiService $aiService,
        GeminiService $geminiService,
        ChatAiSummaryCache $summaryCache
    ): JsonResponse {
        $this->authorize('view', $project);

        if (! config('google_ai.api_key')) {
            return response()->json(['error' => 'Missing GOOGLE_AI_API_KEY.'], 422);
        }

        try {
            $result = $aiService->analyze($project, $geminiService, $summaryCache);

            return response()->json($result);
        } catch (\Throwable $e) {
            report($e);

            return response()->json(['error' => 'Unable to generate AI summary right now.'], 422);
        }
    }

    public function tasks(Request $request, Project $project): InertiaResponse
    {
        $this->authorize('view', $project);

        $user = $request->user();
        $statusFilter = (string) $request->query('status', '');
        $statusFilter = in_array($statusFilter, ['pending', 'in_progress', 'blocked', 'completed'], true)
            ? $statusFilter
            : null;
        $tasksQuery = $project->tasks()
            ->with(['assignments.employee', 'assignments.salesRep', 'creator'])
            ->withCount([
                'subtasks',
                'subtasks as completed_subtasks_count' => fn ($query) => $query->where('is_completed', true),
            ])
            ->orderByDesc('created_at')
            ->orderByDesc('id');

        $tasksQuery->when($user?->isClient(), fn ($q) => $q->where('customer_visible', true));
        $tasksQuery->when($statusFilter, function ($query, $status) {
            if ($status === 'completed') {
                $query->whereIn('status', ['completed', 'done']);

                return;
            }

            $query->where('status', $status);
        });

        $tasks = $tasksQuery->paginate(25)->withQueryString();

        $baseSummary = $project->tasks()
            ->selectRaw("SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count")
            ->selectRaw("SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_count")
            ->selectRaw("SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked_count")
            ->selectRaw("SUM(CASE WHEN status IN ('completed', 'done') THEN 1 ELSE 0 END) as completed_count")
            ->first();

        $summary = [
            'total' => (int) $project->tasks()->count(),
            'pending' => (int) ($baseSummary->pending_count ?? 0),
            'in_progress' => (int) ($baseSummary->in_progress_count ?? 0),
            'blocked' => (int) ($baseSummary->blocked_count ?? 0),
            'completed' => (int) ($baseSummary->completed_count ?? 0),
        ];

        $readerType = 'user';
        $readerId = $user?->id;
        $lastReadId = null;
        if ($readerId) {
            $lastReadId = ProjectMessageRead::query()
                ->where('project_id', $project->id)
                ->where('reader_type', $readerType)
                ->where('reader_id', $readerId)
                ->value('last_read_message_id');
        }

        $projectChatUnreadCount = $project->messages()
            ->when($lastReadId, fn ($query) => $query->where('id', '>', $lastReadId))
            ->count();

        $taskTypeOptions = TaskSettings::taskTypeOptions();

        return Inertia::render('Admin/Projects/Tasks', [
            'pageTitle' => 'Project #'.$project->id.' Tasks',
            'project' => [
                'id' => $project->id,
                'name' => $project->name,
                'status' => $project->status,
                'routes' => [
                    'show' => route('admin.projects.show', $project),
                    'chat' => route('admin.projects.chat', $project),
                    'edit' => route('admin.projects.edit', $project),
                ],
            ],
            'summary' => $summary,
            'statusFilter' => $statusFilter,
            'projectChatUnreadCount' => (int) $projectChatUnreadCount,
            'taskTypeOptions' => $taskTypeOptions,
            'canCreateTask' => (bool) ($user?->can('createTask', $project) ?? false),
            'taskCreateUrl' => route('admin.projects.tasks.create', array_filter([
                'project' => $project,
                'status' => $statusFilter,
            ], fn ($value) => $value !== null && $value !== '')),
            'statusUrls' => [
                'all' => route('admin.projects.tasks.index', $project),
                'pending' => route('admin.projects.tasks.index', ['project' => $project, 'status' => 'pending']),
                'in_progress' => route('admin.projects.tasks.index', ['project' => $project, 'status' => 'in_progress']),
                'blocked' => route('admin.projects.tasks.index', ['project' => $project, 'status' => 'blocked']),
                'completed' => route('admin.projects.tasks.index', ['project' => $project, 'status' => 'completed']),
            ],
            'tasks' => $tasks->through(function (ProjectTask $task) use ($project, $taskTypeOptions, $statusFilter, $user) {
                $currentStatus = (string) ($task->status ?? 'pending');
                $assigneeNames = $task->assignments->map(fn ($assignment) => $assignment->assigneeName())->filter()->implode(', ');
                if ($assigneeNames === '' && $task->assigned_type && $task->assigned_id) {
                    $assigneeNames = ucfirst(str_replace('_', ' ', $task->assigned_type)).' #'.$task->assigned_id;
                }

                return [
                    'id' => $task->id,
                    'title' => (string) $task->title,
                    'description' => (string) ($task->description ?? ''),
                    'task_type_label' => (string) ($taskTypeOptions[$task->task_type] ?? ucfirst((string) ($task->task_type ?? 'Task'))),
                    'assignee_names' => $assigneeNames ?: '--',
                    'progress' => max(0, min(100, (int) ($task->progress ?? 0))),
                    'subtasks_count' => (int) ($task->subtasks_count ?? 0),
                    'completed_subtasks_count' => (int) ($task->completed_subtasks_count ?? 0),
                    'created_at_date' => $task->created_at?->format(config('app.date_format', 'd-m-Y')) ?? '--',
                    'created_at_time' => $task->created_at?->format(config('app.time_format', 'h:i A')) ?? '--',
                    'creator_name' => $task->creator?->name ?? 'System',
                    'status' => $currentStatus,
                    'can_update' => (bool) ($user?->can('update', $task) ?? false),
                    'can_delete' => (bool) ($user?->can('delete', $task) ?? false),
                    'routes' => [
                        'show' => route('admin.projects.tasks.show', [$project, $task]),
                        'edit' => route('admin.projects.tasks.edit', array_filter([
                            'project' => $project,
                            'task' => $task,
                            'status' => $statusFilter,
                        ], fn ($value) => $value !== null && $value !== '')),
                        'change_status' => route('admin.projects.tasks.changeStatus', [$project, $task]),
                        'destroy' => route('admin.projects.tasks.destroy', [$project, $task]),
                    ],
                ];
            })->values(),
            'pagination' => [
                'has_pages' => $tasks->hasPages(),
                'previous_url' => $tasks->previousPageUrl(),
                'next_url' => $tasks->nextPageUrl(),
            ],
        ]);
    }

    public function invoiceRemainingBudget(
        Request $request,
        Project $project,
        BillingService $billingService,
        InvoiceVatService $vatService
    ): RedirectResponse {
        $this->authorize('view', $project);

        $remainingBudget = (float) ($this->financials($project)['remaining_budget_invoiceable'] ?? 0);
        if ($remainingBudget <= 0) {
            return back()->with('status', 'No remaining budget available to invoice.');
        }

        $data = $request->validate([
            'amount' => [
                'required',
                'numeric',
                'min:0.01',
                'lte:'.$remainingBudget,
            ],
        ]);

        $amount = (float) $data['amount'];
        $remainingAmountAfterInvoice = max(0, round($remainingBudget - $amount, 2));
        $issueDate = Carbon::today();
        $dueDays = (int) Setting::getValue('invoice_due_days');
        $dueDate = $issueDate->copy()->addDays($dueDays);

        $taxData = $vatService->calculateTotals($amount, 0.0, $issueDate);
        $remainingAmountNote = $remainingAmountAfterInvoice > 0
            ? sprintf(
                'Remaining budget after this invoice: %s %s',
                (string) $project->currency,
                number_format($remainingAmountAfterInvoice, 2, '.', '')
            )
            : null;

        $invoice = Invoice::create([
            'customer_id' => $project->customer_id,
            'project_id' => $project->id,
            'number' => $billingService->nextInvoiceNumber(),
            'status' => 'unpaid',
            'issue_date' => $issueDate->toDateString(),
            'due_date' => $dueDate->toDateString(),
            'subtotal' => $amount,
            'tax_rate_percent' => $taxData['tax_rate_percent'],
            'tax_mode' => $taxData['tax_mode'],
            'tax_amount' => $taxData['tax_amount'],
            'late_fee' => 0,
            'total' => $taxData['total'],
            'currency' => $project->currency,
            'notes' => $remainingAmountNote,
            'type' => 'project_remaining_budget',
        ]);

        InvoiceItem::create([
            'invoice_id' => $invoice->id,
            'description' => sprintf('Remaining budget for project %s', $project->name),
            'quantity' => 1,
            'unit_price' => $amount,
            'line_total' => $amount,
        ]);

        if ($remainingAmountAfterInvoice > 0) {
            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'description' => (string) $remainingAmountNote,
                'quantity' => 1,
                'unit_price' => 0,
                'line_total' => 0,
            ]);
        }

        SystemLogger::write('activity', 'Project remaining budget invoiced.', [
            'project_id' => $project->id,
            'invoice_id' => $invoice->id,
            'amount' => $amount,
            'remaining_amount_after_invoice' => $remainingAmountAfterInvoice,
        ], $request->user()?->id, $request->ip());

        $statusMessage = sprintf(
            'Invoice #%s created for %s %s.',
            $invoice->number ?? $invoice->id,
            $project->currency,
            number_format($amount, 2)
        );
        if ($remainingAmountAfterInvoice > 0) {
            $statusMessage .= sprintf(
                ' Remaining budget: %s %s.',
                $project->currency,
                number_format($remainingAmountAfterInvoice, 2)
            );
        }

        return redirect()->route('admin.projects.show', $project)
            ->with('status', $statusMessage);
    }

    /**
     * Move a project to another client. Kept separate from update() because it
     * has to carry the project's maintenances and invoices across and drop the
     * previous client's portal users, none of which a field edit should do.
     */
    public function moveOwner(
        Request $request,
        Project $project,
        \App\Services\OwnershipMoveService $moveService
    ): RedirectResponse {
        $this->authorize('update', $project);

        $data = $request->validate([
            'customer_id' => [
                'required',
                'exists:customers,id',
                Rule::notIn([$project->customer_id]),
            ],
            'move_invoices' => ['nullable', 'boolean'],
            'move_maintenances' => ['nullable', 'boolean'],
        ]);

        $target = \App\Models\Customer::findOrFail((int) $data['customer_id']);

        $moved = $moveService->moveProject(
            $project,
            $target,
            [
                'invoices' => (bool) ($data['move_invoices'] ?? false),
                'maintenances' => (bool) ($data['move_maintenances'] ?? false),
            ],
            $request->user()?->id
        );

        return redirect()->route('admin.projects.show', $project)
            ->with('status', sprintf(
                'Project moved to %s (%d invoice(s), %d maintenance record(s), %d portal user(s) removed).',
                $target->name,
                (int) ($moved['invoices'] ?? 0),
                (int) ($moved['maintenances'] ?? 0),
                (int) ($moved['client_users_detached'] ?? 0)
            ));
    }

    public function update(Request $request, Project $project, CommissionService $commissionService): RedirectResponse
    {
        $this->authorize('update', $project);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:190'],
            'customer_id' => ['required', 'exists:customers,id'],
            'order_id' => ['nullable', 'exists:orders,id'],
            'subscription_id' => ['nullable', 'exists:subscriptions,id'],
            'type' => ['required', 'in:software,website,other'],
            'status' => ['required', 'in:ongoing,hold,complete,cancel'],
            'start_date' => ['nullable', 'date'],
            'expected_end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'due_date' => ['nullable', 'date'],
            'description' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'advance_invoice_id' => ['nullable', 'exists:invoices,id'],
            'final_invoice_id' => ['nullable', 'exists:invoices,id'],
            'total_budget' => ['required', 'numeric', 'min:0'],
            'initial_payment_amount' => ['required', 'numeric', 'min:0'],
            'currency' => ['required', 'string', 'size:3', Rule::in(Currency::allowed())],
            'budget_amount' => ['nullable', 'numeric', 'min:0'],
            'software_overhead' => ['nullable', 'numeric', 'min:0'],
            'website_overhead' => ['nullable', 'numeric', 'min:0'],
            'contract_file' => ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png,webp', 'max:10240'],
            'proposal_file' => ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png,webp', 'max:10240'],
            'sales_rep_ids' => ['array'],
            'sales_rep_ids.*' => ['exists:sales_representatives,id'],
            'sales_rep_amounts' => ['array'],
            'sales_rep_amounts.*' => ['nullable', 'numeric', 'min:0'],
            'employee_ids' => ['array'],
            'employee_ids.*' => ['exists:employees,id'],
            'contract_employee_amounts' => ['array'],
            'contract_employee_amounts.*' => ['nullable', 'numeric', 'min:0'],
        ]);

        $salesRepSync = $this->buildSalesRepSyncData($request, $data['sales_rep_ids'] ?? []);
        $totalSalesRepAmount = array_sum(array_column($salesRepSync, 'amount'));
        if ($totalSalesRepAmount > (float) $data['total_budget']) {
            return back()
                ->withErrors(['sales_rep_amounts' => 'Total sales rep amounts cannot exceed total budget.'])
                ->withInput();
        }

        $contractEmployeeTotal = null;
        $contractEmployeePayable = null;
        $contractEmployeePayoutStatus = null;
        $contractEmployeePayoutReference = null;

        $contractEmployeeIds = [];
        if (! empty($data['employee_ids'])) {
            $contractEmployeeIds = Employee::whereIn('id', $data['employee_ids'])
                ->where('employment_type', 'contract')
                ->pluck('id')
                ->all();
        }

        if (! empty($contractEmployeeIds)) {
            $amounts = $request->input('contract_employee_amounts', []);
            $errors = [];
            $contractEmployeeTotal = 0.0;

            foreach ($contractEmployeeIds as $employeeId) {
                $amount = $amounts[$employeeId] ?? null;
                if ($amount === null || $amount === '') {
                    $errors["contract_employee_amounts.{$employeeId}"] = 'Amount is required for contract employees.';

                    continue;
                }
                if (! is_numeric($amount) || (float) $amount < 0) {
                    $errors["contract_employee_amounts.{$employeeId}"] = 'Amount must be at least 0.';

                    continue;
                }

                $contractEmployeeTotal += (float) $amount;
            }

            if (! empty($errors)) {
                return back()->withErrors($errors)->withInput();
            }

            $isComplete = $data['status'] === 'complete';
            $contractEmployeePayable = $isComplete ? $contractEmployeeTotal : 0.0;
            $contractEmployeePayoutStatus = $isComplete ? 'payable' : 'earned';
        } else {
            $contractEmployeePayoutReference = null;
        }

        if (! empty($contractEmployeeIds)) {
            $contractPayload = [
                'contract_amount' => $contractEmployeeTotal,
                'contract_employee_total_earned' => $contractEmployeeTotal,
                'contract_employee_payable' => $contractEmployeePayable,
                'contract_employee_payout_status' => $contractEmployeePayoutStatus,
            ];
        } else {
            $contractPayload = [
                'contract_amount' => null,
                'contract_employee_total_earned' => null,
                'contract_employee_payable' => null,
                'contract_employee_payout_status' => null,
                'contract_employee_payout_reference' => $contractEmployeePayoutReference,
            ];
        }

        $previousStatus = $project->status;
        $previousCurrency = $project->currency;
        $data['currency'] = strtoupper($data['currency']);
        $project->update(array_merge($data, $contractPayload));

        if ($previousCurrency !== $project->currency) {
            $project->maintenances()->update([
                'currency' => $project->currency,
            ]);
        }

        $project->employees()->sync($data['employee_ids'] ?? []);

        $project->salesRepresentatives()->sync($salesRepSync);
        $project->update([
            'sales_rep_ids' => $data['sales_rep_ids'] ?? [],
        ]);
        $commissionService->syncProjectEarnings($project, $salesRepSync);

        SystemLogger::write('activity', 'Project updated.', [
            'project_id' => $project->id,
            'status' => $project->status,
        ], $request->user()?->id, $request->ip());

        if ($previousStatus !== 'complete' && $project->status === 'complete') {
            if ($project->contract_employee_total_earned !== null) {
                $totalEarned = (float) $project->contract_employee_total_earned;
                $currentPayable = (float) ($project->contract_employee_payable ?? 0);
                $updates = [];

                if ($currentPayable < $totalEarned) {
                    $updates['contract_employee_payable'] = $totalEarned;
                }

                if ($project->contract_employee_payout_status !== 'payable') {
                    $updates['contract_employee_payout_status'] = 'payable';
                }

                if (! empty($updates)) {
                    $project->update($updates);
                }
            }

            try {
                $commissionService->markEarningPayableOnProjectCompleted($project);
            } catch (\Throwable $e) {
                SystemLogger::write('module', 'Commission payable transition failed on project completion.', [
                    'project_id' => $project->id,
                    'error' => $e->getMessage(),
                ], level: 'error');
            }
        }

        $this->storeProjectFile($project, $request->file('contract_file'), 'contract');
        $this->storeProjectFile($project, $request->file('proposal_file'), 'proposal');

        return back()->with('status', 'Project updated.');
    }

    public function markComplete(Request $request, Project $project, CommissionService $commissionService): RedirectResponse
    {
        if ($project->status === 'complete') {
            return back()->with('status', 'Project is already completed.');
        }

        $previousStatus = $project->status;
        $project->update(['status' => 'complete']);

        SystemLogger::write('activity', 'Project marked complete.', [
            'project_id' => $project->id,
            'previous_status' => $previousStatus,
            'status' => $project->status,
        ], $request->user()?->id, $request->ip());

        if ($previousStatus !== 'complete') {
            if ($project->contract_employee_total_earned !== null) {
                $totalEarned = (float) $project->contract_employee_total_earned;
                $currentPayable = (float) ($project->contract_employee_payable ?? 0);
                $updates = [];

                if ($currentPayable < $totalEarned) {
                    $updates['contract_employee_payable'] = $totalEarned;
                }

                if ($project->contract_employee_payout_status !== 'payable') {
                    $updates['contract_employee_payout_status'] = 'payable';
                }

                if (! empty($updates)) {
                    $project->update($updates);
                }
            }

            try {
                $commissionService->markEarningPayableOnProjectCompleted($project);
            } catch (\Throwable $e) {
                SystemLogger::write('module', 'Commission payable transition failed on project completion.', [
                    'project_id' => $project->id,
                    'error' => $e->getMessage(),
                ], level: 'error');
            }
        }

        return back()->with('status', 'Project marked as complete.');
    }

    public function downloadFile(Project $project, string $type)
    {
        $this->authorize('view', $project);

        if (! in_array($type, ['contract', 'proposal'], true)) {
            abort(404);
        }

        $pathColumn = "{$type}_file_path";
        $nameColumn = "{$type}_original_name";

        $path = $project->{$pathColumn};
        if (! $path || ! Storage::disk('public')->exists($path)) {
            abort(404);
        }

        $originalName = $project->{$nameColumn} ?: ucfirst($type);

        return Storage::disk('public')->download($path, $originalName);
    }

    public function destroy(Project $project): RedirectResponse
    {
        $this->authorize('delete', $project);

        $project->delete();

        SystemLogger::write('activity', 'Project deleted.', [
            'project_id' => $project->id,
            'customer_id' => $project->customer_id,
        ]);

        return redirect()->route('admin.projects.index')->with('status', 'Project deleted.');
    }

    public function storeTask(Request $request, Project $project): RedirectResponse
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'status' => ['required', 'in:todo,in_progress,blocked,done'],
            'assignee_id' => ['nullable', 'exists:users,id'],
            'due_date' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        $taskData = array_merge($data, [
            'completed_at' => $data['status'] === 'done' ? Carbon::now() : null,
            'created_by' => $request->user()?->id,
        ]);

        $task = $project->tasks()->create($taskData);

        SystemLogger::write('activity', 'Project task created.', [
            'project_id' => $project->id,
            'task_id' => $task->id,
            'status' => $task->status,
        ], $request->user()?->id, $request->ip());

        app(TaskStatusNotificationService::class)->notifyTaskOpened($task);

        return back()->with('status', 'Task added.');
    }

    public function updateTask(Request $request, Project $project, ProjectTask $task): RedirectResponse|JsonResponse
    {
        $this->ensureTaskBelongsToProject($project, $task);
        $this->authorize('update', $task);

        if (! $request->user()?->isMasterAdmin() && $task->creatorEditWindowExpired($request->user()?->id)) {
            $message = 'You can only edit this task within 24 hours of creation.';
            if ($request->expectsJson()) {
                return AjaxResponse::ajaxError($message, 403);
            }

            return back()->withErrors(['task' => $message]);
        }

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'status' => ['required', 'in:todo,in_progress,blocked,done'],
            'assignee_id' => ['nullable', 'exists:users,id'],
            'due_date' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        if (! $request->user()?->isMasterAdmin()
            && $data['status'] === 'done'
            && TaskCompletionManager::hasSubtasks($task)
            && ! TaskCompletionManager::allSubtasksCompleted($task)) {
            return back()->withErrors(['status' => 'Complete all subtasks before completing this task.']);
        }

        $payload = array_merge($data, [
            'completed_at' => $data['status'] === 'done'
                ? ($task->completed_at ?: Carbon::now())
                : null,
        ]);

        $task->update($payload);

        SystemLogger::write('activity', 'Project task updated.', [
            'project_id' => $project->id,
            'task_id' => $task->id,
            'status' => $task->status,
        ], $request->user()?->id, $request->ip());

        return back()->with('status', 'Task updated.');
    }

    public function destroyTask(Project $project, ProjectTask $task): RedirectResponse
    {
        $this->ensureTaskBelongsToProject($project, $task);

        $task->delete();

        SystemLogger::write('activity', 'Project task deleted.', [
            'project_id' => $project->id,
            'task_id' => $task->id,
        ]);

        return back()->with('status', 'Task deleted.');
    }

    private function ensureTaskBelongsToProject(Project $project, ProjectTask $task): void
    {
        if ($task->project_id !== $project->id) {
            abort(404);
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeProjectIndexRow(Project $project): array
    {
        $openTasks = (int) ($project->open_tasks_count ?? 0);
        $doneTasks = (int) ($project->done_tasks_count ?? 0);
        $openSubtasks = (int) ($project->open_subtasks_count ?? 0);
        $hasOpenWork = ($openTasks > 0) || ($openSubtasks > 0);

        return [
            'id' => $project->id,
            'name' => (string) $project->name,
            'type_label' => ucfirst((string) $project->type),
            'status' => (string) $project->status,
            'status_label' => ucfirst(str_replace('_', ' ', (string) $project->status)),
            'status_class' => $this->projectStatusClass((string) $project->status),
            'customer_name' => (string) ($project->customer?->name ?? '--'),
            'customer_company' => (string) ($project->customer?->company_name ?? ''),
            'due_date' => $project->due_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            'employees' => $project->employees->pluck('name')->filter()->values(),
            'sales_reps' => $project->salesRepresentatives->pluck('name')->filter()->values(),
            'tasks' => [
                'open_count' => $openTasks,
                'done_count' => $doneTasks,
                'done_label' => sprintf('%d/%d done', $doneTasks, $openTasks + $doneTasks),
                'has_open_work' => $hasOpenWork,
            ],
            'routes' => [
                'show' => route('admin.projects.show', $project),
                'edit' => route('admin.projects.edit', $project),
                'destroy' => route('admin.projects.destroy', $project),
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeProjectDashboardRow(Project $project): array
    {
        $totalTasks = (int) ($project->total_tasks_count ?? 0);
        $completedTasks = (int) ($project->completed_tasks_count ?? 0);
        $completionRate = $totalTasks > 0
            ? (int) round(($completedTasks / $totalTasks) * 100)
            : 0;

        return [
            'id' => (int) $project->id,
            'name' => (string) $project->name,
            'customer_name' => (string) ($project->customer?->name ?? '--'),
            'status_label' => ucfirst(str_replace('_', ' ', (string) $project->status)),
            'status_class' => $this->projectStatusClass((string) $project->status),
            'type_label' => ucfirst((string) $project->type),
            'due_date' => $project->due_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            'open_tasks' => (int) ($project->open_tasks_count ?? 0),
            'completed_tasks' => $completedTasks,
            'overdue_tasks' => (int) ($project->overdue_tasks_count ?? 0),
            'due_soon_tasks' => (int) ($project->due_soon_tasks_count ?? 0),
            'active_maintenances' => (int) ($project->active_maintenances_count ?? 0),
            'completion_rate' => $completionRate,
            'routes' => [
                'show' => route('admin.projects.show', $project),
                'edit' => route('admin.projects.edit', $project),
            ],
        ];
    }

    /**
     * @param  array<string, mixed>  $financials
     * @return array<string, mixed>
     */
    private function serializeProjectShow(Project $project, array $financials, int $projectChatUnreadCount): array
    {
        $overheadTotal = (float) ($financials['overhead_total'] ?? $project->overhead_total);
        $budgetWithOverhead = (float) ($financials['budget_with_overhead'] ?? ((float) ($project->total_budget ?? 0) + $overheadTotal));
        $remainingBudget = (float) ($financials['remaining_budget'] ?? $project->remaining_budget ?? 0);
        $remainingBudgetInvoiceable = (float) ($financials['remaining_budget_invoiceable'] ?? $remainingBudget);
        $paidPayment = (float) ($financials['paid_payment'] ?? 0);
        $employeeSalaryTotal = (float) ($financials['employee_salary_total'] ?? ($project->contract_amount ?? $project->contract_employee_total_earned ?? 0));
        $salesRepTotal = (float) ($financials['sales_rep_total'] ?? $project->sales_rep_total);
        $profit = (float) ($financials['profit'] ?? 0);

        return [
            'id' => $project->id,
            'name' => (string) $project->name,
            'status' => (string) $project->status,
            'status_label' => ucfirst(str_replace('_', ' ', (string) $project->status)),
            'type_label' => ucfirst((string) $project->type),
            'description' => $project->description ?: 'No description provided.',
            'notes' => $project->notes,
            'currency' => (string) ($project->currency ?? 'USD'),
            'customer' => [
                'id' => $project->customer_id,
                'name' => (string) ($project->customer?->name ?? '--'),
            ],
            'dates' => [
                'start' => $project->start_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
                'expected_end' => $project->expected_end_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
                'due' => $project->due_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            ],
            'files' => [
                'contract' => $project->contract_file_path ? [
                    'name' => (string) ($project->contract_original_name ?: 'Download contract'),
                    'url' => route('admin.projects.download', ['project' => $project, 'type' => 'contract']),
                ] : null,
                'proposal' => $project->proposal_file_path ? [
                    'name' => (string) ($project->proposal_original_name ?: 'Download proposal'),
                    'url' => route('admin.projects.download', ['project' => $project, 'type' => 'proposal']),
                ] : null,
            ],
            'team' => [
                'employees' => $project->employees->pluck('name')->filter()->values(),
                'sales_reps' => $project->salesRepresentatives
                    ->map(function ($rep) use ($project) {
                        $amount = (float) ($rep->pivot?->amount ?? 0);
                        $amountText = $amount > 0 ? sprintf(' (%s %s)', $project->currency, number_format($amount, 2)) : '';

                        return trim((string) $rep->name.$amountText);
                    })
                    ->filter()
                    ->values(),
            ],
            'financials' => [
                'total_budget_display' => $project->total_budget !== null ? sprintf('%s %s', $project->currency, number_format((float) $project->total_budget, 2)) : '--',
                'overhead_total_display' => sprintf('%s %s', $project->currency, number_format($overheadTotal, 2)),
                'budget_with_overhead_display' => sprintf('%s %s', $project->currency, number_format($budgetWithOverhead, 2)),
                'initial_payment_display' => $project->initial_payment_amount !== null ? sprintf('%s %s', $project->currency, number_format((float) $project->initial_payment_amount, 2)) : '--',
                'paid_payment_display' => sprintf('%s %s', $project->currency, number_format($paidPayment, 2)),
                'remaining_budget_display' => sprintf('%s %s', $project->currency, number_format($remainingBudget, 2)),
                'remaining_budget_invoiceable_display' => sprintf('%s %s', $project->currency, number_format($remainingBudgetInvoiceable, 2)),
                'budget_amount_display' => $project->budget_amount !== null ? sprintf('%s %s', $project->currency, number_format((float) $project->budget_amount, 2)) : '--',
                'employee_salary_total_display' => sprintf('%s %s', $project->currency, number_format($employeeSalaryTotal, 2)),
                'sales_rep_total_display' => sprintf('%s %s', $project->currency, number_format($salesRepTotal, 2)),
                'profit_display' => sprintf('%s %s', $project->currency, number_format($profit, 2)),
                // Contract lines preserved for existing assertions.
                'remaining_budget_line' => sprintf('Remaining budget: %s %s', $project->currency, number_format($remainingBudget, 2)),
                'profit_line' => sprintf('Profit: %s %s', $project->currency, number_format($profit, 2)),
            ],
            'overheads' => $project->overheads
                ->map(fn ($overhead) => $this->serializeProjectOverhead($project, $overhead))
                ->values(),
            'maintenances' => $project->maintenances
                ->map(fn (ProjectMaintenance $maintenance) => $this->serializeProjectMaintenance($project, $maintenance))
                ->values(),
            'can_mark_complete' => $project->status !== 'complete',
            'project_chat_unread_count' => $projectChatUnreadCount,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeProjectTaskPreview(Project $project, ProjectTask $task): array
    {
        $status = (string) ($task->status ?? 'pending');
        $statusLabel = match ($status) {
            'pending', 'todo' => 'Open',
            'in_progress' => 'Inprogress',
            'blocked' => 'Blocked',
            'completed', 'done' => 'Completed',
            default => ucfirst(str_replace('_', ' ', $status)),
        };

        return [
            'id' => $task->id,
            'title' => (string) $task->title,
            'description' => (string) ($task->description ?? ''),
            'created_at' => $task->created_at?->format(config('app.datetime_format', 'd-m-Y h:i A')) ?? '--',
            'creator_name' => (string) ($task->creator?->name ?? 'System'),
            'status' => $status,
            'status_label' => $statusLabel,
            'route' => route('admin.projects.tasks.show', [$project, $task]),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeProjectInvoice(Invoice $invoice): array
    {
        $remainingAmountDisplay = $this->remainingAmountDisplayForProjectInvoice($invoice);

        return [
            'id' => $invoice->id,
            'number_display' => '#'.($invoice->number ?: $invoice->id),
            'invoiced_amount_display' => sprintf('%s %s', $invoice->currency, number_format((float) $invoice->subtotal, 2)),
            'total_display' => sprintf('%s %s', $invoice->currency, number_format((float) $invoice->total, 2)),
            'remaining_amount_display' => $remainingAmountDisplay,
            'issue_date' => $invoice->issue_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            'due_date' => $invoice->due_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            'paid_at' => $invoice->paid_at?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            'status' => (string) $invoice->status,
            'status_label' => ucfirst((string) $invoice->status),
            'show_route' => route('admin.invoices.show', $invoice),
        ];
    }

    private function remainingAmountDisplayForProjectInvoice(Invoice $invoice): ?string
    {
        if ((string) $invoice->type !== 'project_remaining_budget') {
            return null;
        }

        $note = trim((string) ($invoice->notes ?? ''));
        if ($note === '') {
            return null;
        }

        if (! preg_match('/Remaining budget after this invoice:\s*([A-Z]{3})\s*([0-9]+(?:\.[0-9]{1,2})?)/i', $note, $matches)) {
            return null;
        }

        $currency = strtoupper((string) ($matches[1] ?? ''));
        $amount = isset($matches[2]) ? (float) $matches[2] : 0.0;
        if ($currency === '' || $amount <= 0) {
            return null;
        }

        return sprintf('%s %s', $currency, number_format($amount, 2));
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeProjectOverhead(Project $project, $overhead): array
    {
        $invoice = $overhead->invoice;
        $invoiceStatus = strtolower((string) ($invoice->status ?? ''));

        $statusLabel = 'Unpaid';
        if (! $invoice) {
            $statusLabel = 'Not invoiced';
        } elseif ($invoiceStatus === 'paid') {
            $statusLabel = 'Paid';
        } elseif ($invoiceStatus === 'cancelled') {
            $statusLabel = 'Cancelled';
        }

        return [
            'id' => $overhead->id,
            'details' => (string) $overhead->short_details,
            'amount_display' => sprintf('%s %s', $project->currency, number_format((float) $overhead->amount, 2)),
            'date' => $overhead->created_at?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            'status_label' => $statusLabel,
            'invoice_number' => $invoice ? '#'.($invoice->number ?: $invoice->id) : '--',
            'invoice_show_route' => $invoice ? route('admin.invoices.show', ['invoice' => $invoice->id]) : null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeProjectMaintenance(Project $project, ProjectMaintenance $maintenance): array
    {
        return [
            'id' => $maintenance->id,
            'title' => (string) $maintenance->title,
            'cycle' => ucfirst((string) $maintenance->billing_cycle),
            'next_billing_date' => $maintenance->next_billing_date?->format(config('app.date_format', 'd-m-Y')) ?? '--',
            'status' => (string) $maintenance->status,
            'auto_invoice' => (bool) $maintenance->auto_invoice,
            'amount_display' => sprintf('%s %s', $maintenance->currency, number_format((float) $maintenance->amount, 2)),
            'invoices_count' => (int) ($maintenance->invoices_count ?? 0),
            'invoices_route' => route('admin.invoices.index', ['maintenance_id' => $maintenance->id]),
            'edit_route' => route('admin.project-maintenances.edit', $maintenance),
        ];
    }

    private function projectStatusClass(string $status): string
    {
        return match ($status) {
            'ongoing' => 'bg-emerald-100 text-emerald-700 ring-emerald-200',
            'hold' => 'bg-amber-100 text-amber-700 ring-amber-200',
            'complete' => 'bg-blue-100 text-blue-700 ring-blue-200',
            'cancel' => 'bg-rose-100 text-rose-700 ring-rose-200',
            default => 'bg-slate-100 text-slate-700 ring-slate-200',
        };
    }

    /**
     * @param  iterable<int, mixed>  $rows
     * @return array<int, array{currency:string,amount:float,display:string}>
     */
    private function summarizeCurrencyTotals(iterable $rows, callable $amountResolver, string $fallbackCurrency): array
    {
        return collect($rows)
            ->map(function ($row) use ($amountResolver, $fallbackCurrency) {
                $currency = strtoupper((string) ($row->currency ?? $fallbackCurrency));
                if (! Currency::isAllowed($currency)) {
                    $currency = $fallbackCurrency;
                }

                return [
                    'currency' => $currency,
                    'amount' => (float) $amountResolver($row),
                ];
            })
            ->groupBy('currency')
            ->map(function ($items, $currency) {
                $amount = (float) collect($items)->sum('amount');

                return [
                    'currency' => (string) $currency,
                    'amount' => $amount,
                    'display' => sprintf('%s %s', $currency, number_format($amount, 2)),
                ];
            })
            ->sortByDesc('amount')
            ->values()
            ->all();
    }

    /**
     * @param  array<string, mixed>  $snapshot
     * @param  array<int, array<string, mixed>>  $riskProjects
     * @param  array<int, array<string, mixed>>  $recentProjects
     * @param  array<int, array<string, mixed>>  $focusProjects
     * @return array{0:?string,1:?string}
     */
    private function buildPortfolioAiSummary(
        GeminiService $geminiService,
        array $snapshot,
        array $riskProjects,
        array $recentProjects,
        array $focusProjects,
        bool $forceRefresh = false
    ): array {
        if (! config('google_ai.api_key')) {
            return [null, 'Missing GOOGLE_AI_API_KEY.'];
        }

        $cacheKey = 'admin_projects_dashboard_ai_'.md5(json_encode([
            'snapshot' => $snapshot,
            'risk' => $riskProjects,
            'recent' => $recentProjects,
            'focus' => $focusProjects,
        ]));

        try {
            $builder = function () use ($geminiService, $snapshot, $riskProjects, $recentProjects, $focusProjects) {
                $budgetTotals = collect($snapshot['budget_totals'] ?? [])
                    ->take(3)
                    ->pluck('display')
                    ->implode(', ');

                $paidTotals = collect($snapshot['paid_totals'] ?? [])
                    ->take(3)
                    ->pluck('display')
                    ->implode(', ');

                $riskNames = collect($riskProjects)
                    ->take(5)
                    ->map(fn ($project) => sprintf(
                        '%s (overdue: %d, due soon: %d)',
                        $project['name'] ?? 'Project',
                        (int) ($project['overdue_tasks'] ?? 0),
                        (int) ($project['due_soon_tasks'] ?? 0)
                    ))
                    ->implode(', ');

                $recentNames = collect($recentProjects)
                    ->take(5)
                    ->map(fn ($project) => sprintf(
                        '%s [%s]',
                        $project['name'] ?? 'Project',
                        $project['status_label'] ?? 'Unknown'
                    ))
                    ->implode(', ');

                $focusProjectsJson = json_encode(
                    collect($focusProjects)
                        ->map(fn (array $project) => [
                            'project' => [
                                'name' => $project['name'] ?? 'Project',
                                'customer' => $project['customer_name'] ?? '--',
                                'status' => $project['status_label'] ?? '--',
                                'timeline' => [
                                    'label' => data_get($project, 'timeline.label'),
                                    'note' => data_get($project, 'timeline.note'),
                                    'start' => data_get($project, 'timeline.start'),
                                    'expected_end' => data_get($project, 'timeline.expected_end'),
                                    'due' => data_get($project, 'timeline.due'),
                                ],
                            ],
                            'profitability' => [
                                'label' => data_get($project, 'profitability.label'),
                                'profit' => data_get($project, 'profitability.profit_display'),
                                'budget_with_overhead' => data_get($project, 'financials.budget_with_overhead_display'),
                                'payouts_total' => data_get($project, 'financials.payouts_total_display'),
                            ],
                            'tasks' => [
                                'total' => data_get($project, 'tasks.total'),
                                'open' => data_get($project, 'tasks.open'),
                                'in_progress' => data_get($project, 'tasks.in_progress'),
                                'blocked' => data_get($project, 'tasks.blocked'),
                                'completed' => data_get($project, 'tasks.completed'),
                                'overdue' => data_get($project, 'tasks.overdue'),
                                'due_soon' => data_get($project, 'tasks.due_soon'),
                                'completion_rate' => data_get($project, 'tasks.completion_rate'),
                                'next_due' => data_get($project, 'tasks.next_due'),
                            ],
                            'subtasks' => [
                                'total' => data_get($project, 'subtasks.total'),
                                'open' => data_get($project, 'subtasks.open'),
                                'completed' => data_get($project, 'subtasks.completed'),
                                'overdue' => data_get($project, 'subtasks.overdue'),
                                'due_soon' => data_get($project, 'subtasks.due_soon'),
                                'completion_rate' => data_get($project, 'subtasks.completion_rate'),
                                'next_due' => data_get($project, 'subtasks.next_due'),
                            ],
                            'chat' => [
                                'project_summary' => data_get($project, 'project_chat.summary'),
                                'project_latest_activity' => data_get($project, 'project_chat.latest_activity'),
                                'task_chat_summaries' => data_get($project, 'task_chats'),
                            ],
                        ])
                        ->values()
                        ->all(),
                    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
                );

                $prompt = <<<PROMPT
You are a PMO analyst. Summarize the projects dashboard in Bengali.

Rules:
- Use only the provided data. Do not invent facts.
- Focus on project profitability, task and subtask delivery pressure, timeline risk, and chat context.
- If any chat summary is missing, say the chat insight is unavailable instead of guessing.
- Return 6-10 concise bullet points in Bengali.
- Mention immediate priorities where needed.

Portfolio snapshot:
- Total projects: {$snapshot['total_projects']}
- Ongoing: {$snapshot['ongoing_projects']}
- On hold: {$snapshot['hold_projects']}
- Completed: {$snapshot['completed_projects']}
- Cancelled: {$snapshot['cancelled_projects']}
- Total tasks: {$snapshot['total_tasks']}
- Open tasks: {$snapshot['open_tasks']}
- In progress tasks: {$snapshot['in_progress_tasks']}
- Completed tasks: {$snapshot['completed_tasks']}
- Completion rate: {$snapshot['completion_rate']}%
- Overdue tasks: {$snapshot['overdue_tasks']}
- Due soon (7d): {$snapshot['due_soon_tasks']}
- Active maintenances: {$snapshot['active_maintenances']}
- Budget totals: {$budgetTotals}
- Paid totals: {$paidTotals}

Risk projects: {$riskNames}
Recent projects: {$recentNames}
Focus projects (JSON):
{$focusProjectsJson}

PROMPT;

                return $geminiService->generateText($prompt);
            };

            $summary = Cache::get($cacheKey);
            if ($summary === null || $forceRefresh) {
                \App\Jobs\GenerateDashboardAiSummaryJob::dispatch('project', $cacheKey, [
                    'snapshot' => $snapshot,
                    'riskProjects' => $riskProjects,
                    'recentProjects' => $recentProjects,
                    'focusProjects' => $focusProjects,
                ]);

                if ($summary === null) {
                    $summary = 'AI summary is being generated in the background. Please refresh in a moment.';
                }
            }

            return [$summary, null];
        } catch (\Throwable $e) {
            return [null, $e->getMessage()];
        }
    }

    /**
     * @param  array<int, int|string>  $projectIds
     * @return array<int, array<string, mixed>>
     */
    private function buildDashboardAiProjects(
        array $projectIds,
        ChatAiSummaryCache $summaryCache,
        string $defaultCurrency
    ): array {
        $orderedIds = collect($projectIds)
            ->map(fn ($id) => (int) $id)
            ->filter(fn (int $id) => $id > 0)
            ->unique()
            ->values()
            ->all();

        if ($orderedIds === []) {
            return [];
        }

        $today = now()->toDateString();
        $dueSoonThreshold = now()->addDays(7)->toDateString();

        return Project::query()
            ->whereIn('id', $orderedIds)
            ->with([
                'customer:id,name',
                'salesRepresentatives:id,name',
                'overheads:id,project_id,amount',
            ])
            ->withCount([
                'tasks as total_tasks_count',
                'tasks as open_tasks_count' => fn ($query) => $query->whereIn('status', ['pending', 'in_progress', 'blocked', 'todo']),
                'tasks as in_progress_tasks_count' => fn ($query) => $query->where('status', 'in_progress'),
                'tasks as blocked_tasks_count' => fn ($query) => $query->where('status', 'blocked'),
                'tasks as completed_tasks_count' => fn ($query) => $query->whereIn('status', ['completed', 'done']),
                'tasks as overdue_tasks_count' => fn ($query) => $query
                    ->whereNotNull('due_date')
                    ->whereDate('due_date', '<', $today)
                    ->whereNotIn('status', ['completed', 'done']),
                'tasks as due_soon_tasks_count' => fn ($query) => $query
                    ->whereNotNull('due_date')
                    ->whereDate('due_date', '>=', $today)
                    ->whereDate('due_date', '<=', $dueSoonThreshold)
                    ->whereNotIn('status', ['completed', 'done']),
                'subtasks as total_subtasks_count',
                'subtasks as open_subtasks_count' => fn ($query) => $query->where('is_completed', false),
                'subtasks as completed_subtasks_count' => fn ($query) => $query->where('is_completed', true),
                'subtasks as overdue_subtasks_count' => fn ($query) => $query
                    ->whereNotNull('project_task_subtasks.due_date')
                    ->whereDate('project_task_subtasks.due_date', '<', $today)
                    ->where('is_completed', false),
                'subtasks as due_soon_subtasks_count' => fn ($query) => $query
                    ->whereNotNull('project_task_subtasks.due_date')
                    ->whereDate('project_task_subtasks.due_date', '>=', $today)
                    ->whereDate('project_task_subtasks.due_date', '<=', $dueSoonThreshold)
                    ->where('is_completed', false),
                'messages as project_messages_count',
            ])
            ->get([
                'id',
                'name',
                'customer_id',
                'status',
                'type',
                'currency',
                'total_budget',
                'initial_payment_amount',
                'contract_amount',
                'contract_employee_total_earned',
                'start_date',
                'expected_end_date',
                'due_date',
                'software_overhead',
                'website_overhead',
            ])
            ->sortBy(fn (Project $project) => array_search((int) $project->id, $orderedIds, true))
            ->values()
            ->map(fn (Project $project) => $this->serializeDashboardAiProject($project, $summaryCache, $defaultCurrency))
            ->all();
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeDashboardAiProject(
        Project $project,
        ChatAiSummaryCache $summaryCache,
        string $defaultCurrency
    ): array {
        $financials = $this->financials($project);
        $currency = strtoupper((string) ($project->currency ?: $defaultCurrency));
        if (! Currency::isAllowed($currency)) {
            $currency = $defaultCurrency;
        }

        $totalTasks = (int) ($project->total_tasks_count ?? 0);
        $completedTasks = (int) ($project->completed_tasks_count ?? 0);
        $taskCompletionRate = $totalTasks > 0
            ? (int) round(($completedTasks / $totalTasks) * 100)
            : 0;

        $totalSubtasks = (int) ($project->total_subtasks_count ?? 0);
        $completedSubtasks = (int) ($project->completed_subtasks_count ?? 0);
        $subtaskCompletionRate = $totalSubtasks > 0
            ? (int) round(($completedSubtasks / $totalSubtasks) * 100)
            : 0;

        $nextDueTask = $project->tasks()
            ->whereNotNull('due_date')
            ->whereNotIn('status', ['completed', 'done'])
            ->orderBy('due_date')
            ->orderBy('id')
            ->first(['id', 'title', 'status', 'start_date', 'due_date']);

        $nextDueSubtask = ProjectTaskSubtask::query()
            ->select([
                'project_task_subtasks.id',
                'project_task_subtasks.title',
                'project_task_subtasks.due_date',
                'project_task_subtasks.status',
                'project_tasks.title as task_title',
            ])
            ->join('project_tasks', 'project_tasks.id', '=', 'project_task_subtasks.project_task_id')
            ->where('project_tasks.project_id', $project->id)
            ->whereNotNull('project_task_subtasks.due_date')
            ->where('project_task_subtasks.is_completed', false)
            ->orderBy('project_task_subtasks.due_date')
            ->orderBy('project_task_subtasks.id')
            ->first();

        $cachedProjectChat = $summaryCache->getProject($project->id) ?? [];
        $latestProjectMessage = $project->messages()
            ->with(['userAuthor:id,name', 'employeeAuthor:id,name', 'salesRepAuthor:id,name'])
            ->latest('id')
            ->first();

        $taskChats = $project->tasks()
            ->withCount('messages')
            ->whereHas('messages')
            ->orderByDesc('messages_count')
            ->orderBy('due_date')
            ->limit(2)
            ->get(['id', 'title', 'status', 'due_date'])
            ->map(function (ProjectTask $task) use ($summaryCache) {
                $cachedSummary = $summaryCache->getTask($task->id) ?? [];
                $latestMessage = $task->messages()
                    ->with(['userAuthor:id,name', 'employeeAuthor:id,name', 'salesRepAuthor:id,name'])
                    ->latest('id')
                    ->first();

                return [
                    'task_title' => (string) $task->title,
                    'status' => (string) ($task->status ?? 'pending'),
                    'due_date' => $this->formatDateValue($task->due_date),
                    'messages_count' => (int) ($task->messages_count ?? 0),
                    'summary' => trim((string) ($cachedSummary['summary'] ?? '')),
                    'priority' => $cachedSummary['priority'] ?? null,
                    'sentiment' => $cachedSummary['sentiment'] ?? null,
                    'latest_activity' => $latestMessage ? $this->chatActivitySnippet($latestMessage) : null,
                ];
            })
            ->values()
            ->all();

        $profit = (float) ($financials['profit'] ?? 0);

        return [
            'id' => (int) $project->id,
            'name' => (string) $project->name,
            'customer_name' => (string) ($project->customer?->name ?? '--'),
            'status_label' => ucfirst(str_replace('_', ' ', (string) $project->status)),
            'status_class' => $this->projectStatusClass((string) $project->status),
            'timeline' => $this->projectTimelinePayload($project),
            'financials' => [
                'currency' => $currency,
                'budget_with_overhead_display' => Currency::format((float) ($financials['budget_with_overhead'] ?? 0), $currency),
                'payouts_total_display' => Currency::format((float) ($financials['payouts_total'] ?? 0), $currency),
                'profit_display' => Currency::format($profit, $currency),
            ],
            'profitability' => [
                'label' => ($financials['profitable'] ?? false) ? 'Profitable' : 'Loss',
                'profit_display' => Currency::format($profit, $currency),
                'tone_class' => ($financials['profitable'] ?? false)
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                    : 'border-rose-200 bg-rose-50 text-rose-700',
            ],
            'tasks' => [
                'total' => $totalTasks,
                'open' => (int) ($project->open_tasks_count ?? 0),
                'in_progress' => (int) ($project->in_progress_tasks_count ?? 0),
                'blocked' => (int) ($project->blocked_tasks_count ?? 0),
                'completed' => $completedTasks,
                'overdue' => (int) ($project->overdue_tasks_count ?? 0),
                'due_soon' => (int) ($project->due_soon_tasks_count ?? 0),
                'completion_rate' => $taskCompletionRate,
                'next_due' => $nextDueTask ? [
                    'title' => (string) $nextDueTask->title,
                    'status' => (string) ($nextDueTask->status ?? 'pending'),
                    'start' => $this->formatDateValue($nextDueTask->start_date),
                    'due' => $this->formatDateValue($nextDueTask->due_date),
                ] : null,
            ],
            'subtasks' => [
                'total' => $totalSubtasks,
                'open' => (int) ($project->open_subtasks_count ?? 0),
                'completed' => $completedSubtasks,
                'overdue' => (int) ($project->overdue_subtasks_count ?? 0),
                'due_soon' => (int) ($project->due_soon_subtasks_count ?? 0),
                'completion_rate' => $subtaskCompletionRate,
                'next_due' => $nextDueSubtask ? [
                    'title' => (string) ($nextDueSubtask->title ?? 'Subtask'),
                    'task_title' => (string) ($nextDueSubtask->task_title ?? 'Task'),
                    'status' => (string) ($nextDueSubtask->status ?? 'pending'),
                    'due' => $this->formatDateValue($nextDueSubtask->due_date),
                ] : null,
            ],
            'project_chat' => [
                'summary' => trim((string) ($cachedProjectChat['summary'] ?? '')),
                'priority' => $cachedProjectChat['priority'] ?? null,
                'sentiment' => $cachedProjectChat['sentiment'] ?? null,
                'generated_at' => $cachedProjectChat['generated_at'] ?? null,
                'messages_count' => (int) ($project->project_messages_count ?? 0),
                'latest_activity' => $latestProjectMessage ? $this->chatActivitySnippet($latestProjectMessage) : null,
            ],
            'task_chats' => $taskChats,
            'routes' => [
                'show' => route('admin.projects.show', $project),
                'edit' => route('admin.projects.edit', $project),
            ],
        ];
    }

    /**
     * @return array<string, string>
     */
    private function projectTimelinePayload(Project $project): array
    {
        $today = now()->startOfDay();
        $isClosed = in_array((string) $project->status, ['complete', 'cancel'], true);
        $dueDate = $project->due_date?->copy()->startOfDay();
        $expectedEndDate = $project->expected_end_date?->copy()->startOfDay();

        $label = 'On Track';
        $note = 'Timeline looks stable.';

        if ($dueDate && ! $isClosed && $dueDate->lt($today)) {
            $label = 'Past Due';
            $note = $dueDate->diffInDays($today).' days overdue.';
        } elseif ($dueDate && ! $isClosed && $dueDate->lte($today->copy()->addDays(7))) {
            $label = 'Due Soon';
            $note = $today->diffInDays($dueDate).' days left to due date.';
        } elseif ($expectedEndDate && ! $isClosed && $expectedEndDate->lt($today)) {
            $label = 'Past Expected End';
            $note = 'Expected end date already passed.';
        } elseif (! $dueDate && ! $expectedEndDate) {
            $label = 'Timeline Missing';
            $note = 'No expected end or due date set.';
        } elseif ($isClosed) {
            $label = 'Closed';
            $note = 'Project is already marked '.$this->projectStatusLabel((string) $project->status).'.';
        } elseif ($dueDate) {
            $note = $today->diffInDays($dueDate).' days left to due date.';
        } elseif ($expectedEndDate) {
            $note = 'Expected end on '.$this->formatDateValue($expectedEndDate).'.';
        }

        return [
            'label' => $label,
            'note' => $note,
            'tone_class' => $this->timelineToneClass($label),
            'start' => $this->formatDateValue($project->start_date),
            'expected_end' => $this->formatDateValue($project->expected_end_date),
            'due' => $this->formatDateValue($project->due_date),
        ];
    }

    private function timelineToneClass(string $label): string
    {
        return match ($label) {
            'Past Due', 'Past Expected End' => 'border-rose-200 bg-rose-50 text-rose-700',
            'Due Soon' => 'border-amber-200 bg-amber-50 text-amber-700',
            'Closed' => 'border-slate-200 bg-slate-100 text-slate-700',
            'Timeline Missing' => 'border-slate-200 bg-slate-50 text-slate-600',
            default => 'border-emerald-200 bg-emerald-50 text-emerald-700',
        };
    }

    private function projectStatusLabel(string $status): string
    {
        return ucfirst(str_replace('_', ' ', $status));
    }

    private function formatDateValue($date): string
    {
        return $date?->format(config('app.date_format', 'd-m-Y')) ?? '--';
    }

    private function chatActivitySnippet(object $message): string
    {
        $author = method_exists($message, 'authorName')
            ? (string) $message->authorName()
            : 'User';

        $body = Str::squish((string) ($message->message ?? ''));
        if ($body === '' && ! empty($message->attachment_path)) {
            $body = '[attachment]';
        }

        if ($body === '') {
            $body = 'No text message.';
        }

        return $author.': '.Str::limit($body, 140);
    }

    /**
     * @return array<string, mixed>
     */
    private function paginationPayload($paginator): array
    {
        return [
            'current_page' => $paginator->currentPage(),
            'last_page' => $paginator->lastPage(),
            'per_page' => $paginator->perPage(),
            'total' => $paginator->total(),
            'from' => $paginator->firstItem(),
            'to' => $paginator->lastItem(),
            'previous_url' => $paginator->previousPageUrl(),
            'next_url' => $paginator->nextPageUrl(),
            'has_pages' => $paginator->hasPages(),
        ];
    }

    private function parseAssignee(string $value): array
    {
        [$type, $id] = array_pad(explode(':', $value, 2), 2, null);
        $id = $id ? (int) $id : null;

        if (! $type || ! $id) {
            abort(422, 'Invalid assignee');
        }

        if (! in_array($type, ['employee', 'sales_rep'], true)) {
            abort(422, 'Invalid assignee type');
        }

        if ($type === 'employee' && ! Employee::whereKey($id)->exists()) {
            abort(422, 'Employee not found');
        }

        if ($type === 'sales_rep' && ! SalesRepresentative::whereKey($id)->exists()) {
            abort(422, 'Sales representative not found');
        }

        return [$type, $id];
    }

    private function financials(Project $project): array
    {
        $budget = (float) ($project->total_budget ?? 0);
        $overhead = $project->overhead_total;
        $budgetWithOverhead = $budget + $overhead;
        $salesRepTotal = (float) ($project->sales_rep_total ?? 0);
        $employeeSalaryTotal = (float) ($project->contract_amount ?? $project->contract_employee_total_earned ?? 0);
        $payoutsTotal = $salesRepTotal + $employeeSalaryTotal;
        $initialPayment = (float) ($project->initial_payment_amount ?? 0);
        $paidPayment = (float) $project->invoices()
            ->whereIn('type', ['project_initial_payment', 'project_remaining_budget'])
            ->where('status', 'paid')
            ->sum('total');
        $pendingRemainingBudgetInvoiced = (float) $project->invoices()
            ->where('type', 'project_remaining_budget')
            ->whereIn('status', ['unpaid', 'overdue'])
            ->sum('total');
        $remainingBudget = $budgetWithOverhead - $paidPayment;
        $remainingBudgetInvoiceable = max(0, $remainingBudget - $pendingRemainingBudgetInvoiced);
        $profit = $budgetWithOverhead - $salesRepTotal - $employeeSalaryTotal;

        return [
            'budget' => $budget,
            'overhead_total' => $overhead,
            'budget_with_overhead' => $budgetWithOverhead,
            'initial_payment' => $initialPayment,
            'paid_payment' => $paidPayment,
            'employee_salary_total' => $employeeSalaryTotal,
            'sales_rep_total' => $salesRepTotal,
            'payouts_total' => $payoutsTotal,
            'remaining_budget' => $remainingBudget,
            'pending_remaining_budget_invoiced' => $pendingRemainingBudgetInvoiced,
            'remaining_budget_invoiceable' => $remainingBudgetInvoiceable,
            'profit' => $profit,
            'profitable' => $profit >= 0,
        ];
    }

    private function buildSalesRepSyncData(Request $request, array $repIds): array
    {
        $amounts = $request->input('sales_rep_amounts', []);
        $syncData = [];

        foreach ($repIds as $repId) {
            $amount = isset($amounts[$repId]) && $amounts[$repId] !== ''
                ? (float) $amounts[$repId]
                : 0.0;
            $syncData[$repId] = ['amount' => $amount];
        }

        return $syncData;
    }

    private function parseTags(?string $tags, array $fallback = []): array
    {
        if ($tags === null) {
            return $fallback;
        }

        $parsed = array_filter(array_map('trim', explode(',', $tags)));

        return array_values(array_unique($parsed));
    }

    private function parseRelationships(?string $relationships, array $fallback = []): array
    {
        if ($relationships === null) {
            return $fallback;
        }

        $ids = array_filter(array_map('trim', explode(',', $relationships)));
        $ids = array_values(array_unique(array_filter($ids, fn ($id) => is_numeric($id))));

        return array_map('intval', $ids);
    }

    private function storeTaskAttachment($attachment, ProjectTask $task): string
    {
        $name = pathinfo((string) $attachment->getClientOriginalName(), PATHINFO_FILENAME);
        $name = $name !== '' ? Str::slug($name) : 'attachment';
        $extension = $attachment->getClientOriginalExtension();
        $fileName = $name.'-'.Str::random(8).'.'.$extension;

        return $attachment->storeAs('project-task-activities/'.$task->id, $fileName, 'public');
    }

    private function storeProjectFile(Project $project, ?UploadedFile $file, string $type): void
    {
        if (! $file) {
            return;
        }

        $columnPath = "{$type}_file_path";
        $columnOriginalName = "{$type}_original_name";
        $previousPath = $project->{$columnPath};

        if ($previousPath) {
            Storage::disk('public')->delete($previousPath);
        }

        $fileName = Str::slug("{$type}-{$project->id}-".time());
        $fileName .= '.'.$file->getClientOriginalExtension();
        $path = $file->storeAs("projects/{$project->id}", $fileName, 'public');

        $project->update([
            $columnPath => $path,
            $columnOriginalName => $file->getClientOriginalName(),
        ]);
    }

    private function createColumnOverheadInvoiceItems(Invoice $invoice, Project $project): void
    {
        foreach (['software', 'website'] as $type) {
            $column = "{$type}_overhead";
            $amount = (float) ($project->{$column} ?? 0);
            if ($amount <= 0) {
                continue;
            }

            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'description' => sprintf('%s overhead for project %s', ucfirst($type), $project->name),
                'quantity' => 1,
                'unit_price' => $amount,
                'line_total' => $amount,
            ]);
        }
    }

    private function createProjectOverheads(Project $project, array $rows, ?User $creator): void
    {
        $filtered = collect($rows)
            ->map(fn ($row) => [
                'short_details' => trim((string) ($row['short_details'] ?? '')),
                'amount' => isset($row['amount']) ? (float) $row['amount'] : 0.0,
            ])
            ->filter(fn ($row) => $row['short_details'] !== '' && $row['amount'] > 0)
            ->values();

        if ($filtered->isEmpty()) {
            return;
        }

        foreach ($filtered as $entry) {
            $project->overheads()->create([
                'short_details' => $entry['short_details'],
                'amount' => $entry['amount'],
                'created_by' => $creator?->id,
            ]);
        }

        $project->loadMissing('overheads');
    }
}
