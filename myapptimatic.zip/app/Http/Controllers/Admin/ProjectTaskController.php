<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use App\Http\Requests\UpdateTaskStatusRequest;
use App\Models\Employee;
use App\Models\Project;
use App\Models\ProjectTask;
use App\Models\SalesRepresentative;
use App\Support\AjaxResponse;
use App\Support\SystemLogger;
use App\Support\TaskActivityLogger;
use App\Support\TaskAssignees;
use App\Support\TaskAssignmentManager;
use App\Support\TaskCompletionManager;
use App\Support\TaskSettings;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response as InertiaResponse;

class ProjectTaskController extends Controller
{
    public function create(Request $request, Project $project): InertiaResponse
    {
        $this->authorize('createTask', $project);

        $statusFilter = old('task_status_filter', $request->query('status'));
        $statusFilter = in_array($statusFilter, ['pending', 'in_progress', 'blocked', 'completed'], true)
            ? $statusFilter
            : null;
        $returnToUrl = route('admin.projects.tasks.index', array_filter([
            'project' => $project,
            'status' => $statusFilter,
        ], fn ($value) => $value !== null && $value !== ''));

        return Inertia::render('Admin/Projects/TaskFormPage', [
            ...$this->taskFormInertiaData($project, null, false, $statusFilter, $returnToUrl),
            'pageTitle' => 'Add Task',
        ]);
    }

    public function edit(Request $request, Project $project, ProjectTask $task): InertiaResponse
    {
        $this->ensureTaskBelongsToProject($project, $task);
        $this->authorize('update', $task);

        $statusFilter = old('task_status_filter', $request->query('status'));
        $statusFilter = in_array($statusFilter, ['pending', 'in_progress', 'blocked', 'completed'], true)
            ? $statusFilter
            : null;
        $returnToUrl = route('admin.projects.tasks.index', array_filter([
            'project' => $project,
            'status' => $statusFilter,
        ], fn ($value) => $value !== null && $value !== ''));

        return Inertia::render('Admin/Projects/TaskFormPage', [
            ...$this->taskFormInertiaData($project, $task, true, $statusFilter, $returnToUrl),
            'pageTitle' => 'Edit Task',
        ]);
    }

    public function store(StoreTaskRequest $request, Project $project): RedirectResponse|JsonResponse
    {
        $this->authorize('createTask', $project);

        $data = $request->validated();

        $assigneeInputs = $data['assignees'] ?? [];
        if (empty($assigneeInputs) && ! empty($data['assignee'])) {
            $assigneeInputs = [$data['assignee']];
        }

        $assignees = TaskAssignees::parse($assigneeInputs);
        if (empty($assignees)) {
            return $this->validationError($request, ['assignees' => 'Select at least one assignee.']);
        }

        $description = $this->combineDescriptions($data);
        $taskType = $data['task_type'];

        if ($taskType === 'upload' && ! $request->hasFile('attachment')) {
            return $this->validationError($request, ['attachment' => 'Upload tasks require at least one file.']);
        }

        $task = ProjectTask::create([
            'project_id' => $project->id,
            'title' => $data['title'],
            'description' => $description,
            'task_type' => $taskType,
            'status' => 'pending',
            'priority' => $data['priority'] ?? 'medium',
            'start_date' => $data['start_date'],
            'due_date' => $data['due_date'],
            'assigned_type' => $assignees[0]['type'] ?? null,
            'assigned_id' => $assignees[0]['id'] ?? null,
            'customer_visible' => (bool) ($data['customer_visible'] ?? TaskSettings::defaultCustomerVisible()),
            'progress' => 0,
            'created_by' => $request->user()?->id,
            'time_estimate_minutes' => $data['time_estimate_minutes'] ?? null,
            'tags' => $this->parseTags($data['tags'] ?? null),
            'relationship_ids' => $this->parseRelationships($data['relationship_ids'] ?? null),
        ]);

        TaskAssignmentManager::sync($task, $assignees);

        TaskActivityLogger::record($task, $request, 'system', 'Task created.');

        if ($request->hasFile('attachment')) {
            $path = $this->storeAttachment($request, $task);
            TaskActivityLogger::record($task, $request, 'upload', null, [], $path);
        }

        SystemLogger::write('activity', 'Project task created.', [
            'project_id' => $project->id,
            'task_id' => $task->id,
            'status' => $task->status,
            'actor_type' => 'admin',
            'actor_id' => $request->user()?->id,
        ], $request->user()?->id, $request->ip());

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                $this->tasksRedirectUrl($request, $project),
                'Task added.',
                closeModal: true
            );
        }

        if ($request->filled('return_to')) {
            return redirect()->to((string) $request->input('return_to'))->with('status', 'Task added.');
        }

        return back()->with('status', 'Task added.');
    }

    public function update(UpdateTaskRequest $request, Project $project, ProjectTask $task): RedirectResponse|JsonResponse
    {
        $this->ensureTaskBelongsToProject($project, $task);
        $this->authorize('update', $task);

        if ($request->hasAny(['start_date', 'due_date'])) {
            return $this->validationError($request, ['dates' => 'Task dates cannot be changed after creation.']);
        }

        if (! $request->user()?->isMasterAdmin() && $task->creatorEditWindowExpired($request->user()?->id)) {
            return $this->forbiddenResponse($request, 'You can only edit this task within 24 hours of creation.');
        }

        $data = $request->validated();

        if (! $request->user()?->isMasterAdmin()
            && in_array($data['status'] ?? $task->status, ['completed', 'done'], true)
            && TaskCompletionManager::hasSubtasks($task)
            && ! TaskCompletionManager::allSubtasksCompleted($task)) {
            return $this->validationError($request, [
                'status' => 'Complete all subtasks before completing this task.',
            ]);
        }

        $taskType = $data['task_type'] ?? $task->task_type ?? 'feature';
        if ($taskType === 'upload' && ! $this->taskHasUploadFiles($task)) {
            return $this->validationError($request, ['task_type' => 'Upload tasks require at least one file.']);
        }

        $maxMb = TaskSettings::uploadMaxMb();
        $request->validate([
            'images' => ['sometimes', 'nullable', 'array'],
            'images.*' => ['image', 'max:' . ($maxMb * 1024)],
            'image' => ['sometimes', 'nullable', 'image', 'max:' . ($maxMb * 1024)],
        ]);

        $payload = [
            'title' => array_key_exists('title', $data) ? $data['title'] : $task->title,
            'description' => array_key_exists('description', $data) ? $data['description'] : $task->description,
            'task_type' => $taskType,
            'status' => array_key_exists('status', $data) ? $data['status'] : $task->status,
            'priority' => $data['priority'] ?? $task->priority ?? 'medium',
            'time_estimate_minutes' => $data['time_estimate_minutes'] ?? $task->time_estimate_minutes,
            'tags' => $this->parseTags($data['tags'] ?? null, $task->tags ?? []),
            'relationship_ids' => $this->parseRelationships($data['relationship_ids'] ?? null, $task->relationship_ids ?? []),
            'progress' => $data['progress'] ?? $task->progress,
            'customer_visible' => (bool) ($data['customer_visible'] ?? $task->customer_visible),
            'notes' => array_key_exists('notes', $data) ? $data['notes'] : $task->notes,
        ];

        if ($request->hasFile('images') || $request->hasFile('image')) {
            $newPaths = [];
            $files = $request->hasFile('images') ? (array) $request->file('images') : [$request->file('image')];
            foreach ($files as $file) {
                if ($file && $file->isValid()) {
                    $name = pathinfo((string) $file->getClientOriginalName(), PATHINFO_FILENAME);
                    $name = $name !== '' ? Str::slug($name) : 'task-image';
                    $extension = $file->getClientOriginalExtension();
                    $fileName = $name . '-' . Str::random(8) . '.' . $extension;
                    $newPaths[] = $file->storeAs('project-tasks/' . $task->id, $fileName, 'public');
                }
            }
            if (! empty($newPaths)) {
                $existing = $task->allAttachmentUrls();
                $payload['attachment_paths'] = array_values(array_unique(array_merge($existing, $newPaths)));
            }
        }

        $previousStatus = $task->status;

        $isCompleted = in_array($payload['status'], ['completed', 'done'], true);
        if ($task->status !== 'completed' && $isCompleted) {
            $payload['completed_at'] = Carbon::now();
        }

        $task->update($payload);

        if ($previousStatus !== $task->status) {
            TaskActivityLogger::record($task, $request, 'status', 'Status changed to '.ucfirst(str_replace('_', ' ', $task->status)).'.');
        }

        if (! empty($data['assignees'])) {
            $assignees = TaskAssignees::parse($data['assignees']);
            if (empty($assignees)) {
                return $this->validationError($request, ['assignees' => 'Select at least one valid assignee.']);
            }
            $changes = TaskAssignmentManager::sync($task, $assignees);
            if ($changes['before'] !== $changes['after']) {
                TaskActivityLogger::record($task, $request, 'assignment', 'Assignees updated.');
            }
        }

        if ($previousStatus === $task->status && empty($data['assignees'])) {
            TaskActivityLogger::record($task, $request, 'system', 'Task updated.');
        }

        SystemLogger::write('activity', 'Project task updated.', [
            'project_id' => $project->id,
            'task_id' => $task->id,
            'status' => $task->status,
            'actor_type' => 'admin',
            'actor_id' => $request->user()?->id,
        ], $request->user()?->id, $request->ip());

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                $this->tasksRedirectUrl($request, $project),
                'Task updated.',
                closeModal: true
            );
        }

        if ($request->filled('return_to')) {
            return redirect()->to((string) $request->input('return_to'))->with('status', 'Task updated.');
        }

        return back()->with('status', 'Task updated.');
    }

    public function updateAssignees(Request $request, Project $project, ProjectTask $task): JsonResponse
    {
        $this->ensureTaskBelongsToProject($project, $task);
        $this->authorize('update', $task);

        if (! $request->user()?->isMasterAdmin() && $task->creatorEditWindowExpired($request->user()?->id)) {
            return AjaxResponse::ajaxError('You can only edit this task within 24 hours of creation.', 403);
        }

        $data = $request->validate([
            'employee_ids' => ['nullable', 'array'],
            'employee_ids.*' => ['integer', 'exists:employees,id'],
        ]);

        $employeeIds = array_values(array_unique($data['employee_ids'] ?? []));
        $employeeAssignees = array_map(fn ($id) => ['type' => 'employee', 'id' => $id], $employeeIds);

        $otherAssignees = $task->assignments()
            ->where('assignee_type', '!=', 'employee')
            ->get(['assignee_type', 'assignee_id'])
            ->map(fn ($assignment) => ['type' => $assignment->assignee_type, 'id' => $assignment->assignee_id])
            ->all();

        $assignees = array_values(array_merge($employeeAssignees, $otherAssignees));

        if (empty($assignees)) {
            $task->assignments()->delete();
            $task->assigned_type = null;
            $task->assigned_id = null;
            $task->save();
        } else {
            TaskAssignmentManager::sync($task, $assignees);
        }

        $task->load(['assignments.employee', 'assignments.salesRep']);

        $payload = $task->assignments
            ->map(fn ($assignment) => [
                'type' => $assignment->assignee_type,
                'id' => $assignment->assignee_id,
                'name' => $assignment->assigneeName(),
            ])
            ->values();

        return response()->json([
            'ok' => true,
            'assignees' => $payload,
        ]);
    }

    public function changeStatus(UpdateTaskStatusRequest $request, Project $project, ProjectTask $task): RedirectResponse|JsonResponse
    {
        $this->ensureTaskBelongsToProject($project, $task);
        $this->authorize('update', $task);

        if (! $request->user()?->isMasterAdmin() && $task->creatorEditWindowExpired($request->user()?->id)) {
            return $this->forbiddenResponse($request, 'You can only edit this task within 24 hours of creation.');
        }

        $data = $request->validated();

        if (! $request->user()?->isMasterAdmin()
            && in_array($data['status'], ['completed', 'done'], true)
            && TaskCompletionManager::hasSubtasks($task)
            && ! TaskCompletionManager::allSubtasksCompleted($task)) {
            return $this->validationError($request, [
                'status' => 'Complete all subtasks before completing this task.',
            ]);
        }

        $payload = [
            'status' => $data['status'],
            'progress' => $data['progress'] ?? $task->progress,
        ];

        $previousStatus = $task->status;

        $isCompleted = in_array($data['status'], ['completed', 'done'], true);
        if ($task->status !== 'completed' && $isCompleted) {
            $payload['completed_at'] = Carbon::now();
        }

        $task->update($payload);

        if ($previousStatus !== $task->status) {
            TaskActivityLogger::record($task, $request, 'status', 'Status changed to '.ucfirst(str_replace('_', ' ', $task->status)).'.');
        }

        SystemLogger::write('activity', 'Project task status updated.', [
            'project_id' => $project->id,
            'task_id' => $task->id,
            'status' => $task->status,
            'actor_type' => 'admin',
            'actor_id' => $request->user()?->id,
        ], $request->user()?->id, $request->ip());

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                $this->tasksRedirectUrl($request, $project),
                'Task status updated.'
            );
        }

        return back()->with('status', 'Task status updated.');
    }

    public function destroy(Request $request, Project $project, ProjectTask $task): RedirectResponse|JsonResponse
    {
        $this->ensureTaskBelongsToProject($project, $task);
        $this->authorize('delete', $task);

        if (! $request->user()?->isMasterAdmin() && $task->status === 'completed') {
            return $this->validationError($request, ['task' => 'Completed tasks cannot be deleted.']);
        }

        $task->delete();

        SystemLogger::write('activity', 'Project task deleted.', [
            'project_id' => $project->id,
            'task_id' => $task->id,
            'actor_type' => 'admin',
            'actor_id' => $request->user()?->id,
        ], $request->user()?->id, $request->ip());

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                $this->tasksRedirectUrl($request, $project),
                'Task removed.'
            );
        }

        return back()->with('status', 'Task removed.');
    }

    private function validationError(Request $request, array $errors): RedirectResponse|JsonResponse
    {
        if (AjaxResponse::ajaxFromRequest($request)) {
            $message = collect($errors)->flatten()->first() ?? 'Validation failed.';

            return AjaxResponse::ajaxValidation($errors, null, $message);
        }

        return back()->withErrors($errors)->withInput();
    }

    private function forbiddenResponse(Request $request, string $message): RedirectResponse|JsonResponse
    {
        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxError($message, 403);
        }

        return back()->withErrors(['task' => $message]);
    }

    private function ensureTaskBelongsToProject(Project $project, ProjectTask $task): void
    {
        if ($task->project_id !== $project->id) {
            abort(404);
        }
    }

    private function taskFormData(Project $project, ?ProjectTask $task = null): array
    {
        return [
            'project' => $project,
            'task' => $task?->loadMissing(['assignments.employee', 'assignments.salesRep']),
            'taskTypeOptions' => TaskSettings::taskTypeOptions(),
            'priorityOptions' => TaskSettings::priorityOptions(),
            'employees' => Employee::query()
                ->where('status', 'active')
                ->orderBy('name')
                ->get(['id', 'name', 'designation']),
            'salesReps' => SalesRepresentative::query()
                ->where('status', 'active')
                ->orderBy('name')
                ->get(['id', 'name', 'email']),
            'statusOptions' => ['pending', 'in_progress', 'blocked', 'completed'],
        ];
    }

    private function taskFormInertiaData(
        Project $project,
        ?ProjectTask $task,
        bool $isEdit,
        ?string $statusFilter,
        string $returnToUrl
    ): array {
        $task?->loadMissing(['assignments.employee', 'assignments.salesRep']);
        $selectedAssignees = old(
            'assignees',
            $isEdit && $task
                ? $task->assignments
                    ->map(fn ($assignment) => $assignment->assignee_type.':'.$assignment->assignee_id)
                    ->filter()
                    ->values()
                    ->all()
                : []
        );

        return [
            'isEdit' => $isEdit,
            'project' => [
                'id' => $project->id,
                'name' => $project->name,
            ],
            'task' => $task ? [
                'id' => $task->id,
                'title' => $task->title,
                'description' => $task->description,
                'task_type' => $task->task_type,
                'priority' => $task->priority,
                'status' => $task->status,
                'progress' => (int) ($task->progress ?? 0),
                'time_estimate_minutes' => $task->time_estimate_minutes,
                'tags' => $task->tags ? implode(', ', $task->tags) : '',
                'relationship_ids' => $task->relationship_ids ? implode(', ', $task->relationship_ids) : '',
                'notes' => $task->notes,
                'customer_visible' => (bool) $task->customer_visible,
            ] : null,
            'taskStatusFilter' => $statusFilter,
            'returnToUrl' => $returnToUrl,
            'taskTypeOptions' => TaskSettings::taskTypeOptions(),
            'priorityOptions' => TaskSettings::priorityOptions(),
            'statusOptions' => ['pending', 'in_progress', 'blocked', 'completed'],
            'employees' => Employee::query()
                ->where('status', 'active')
                ->orderBy('name')
                ->get(['id', 'name', 'designation'])
                ->map(fn (Employee $employee) => [
                    'id' => $employee->id,
                    'name' => $employee->name,
                    'designation' => $employee->designation,
                ])
                ->values(),
            'salesReps' => SalesRepresentative::query()
                ->where('status', 'active')
                ->orderBy('name')
                ->get(['id', 'name', 'email'])
                ->map(fn (SalesRepresentative $salesRep) => [
                    'id' => $salesRep->id,
                    'name' => $salesRep->name,
                    'email' => $salesRep->email,
                ])
                ->values(),
            'form' => [
                'task_status_filter' => old('task_status_filter', $statusFilter),
                'return_to' => old('return_to', $returnToUrl),
                'title' => old('title', $task?->title ?? ''),
                'start_date' => old('start_date', now()->toDateString()),
                'due_date' => old('due_date'),
                'status' => old('status', $task?->status),
                'task_type' => old('task_type', $task?->task_type),
                'priority' => old('priority', $task?->priority ?? 'medium'),
                'progress' => old('progress', (int) ($task?->progress ?? 0)),
                'time_estimate_minutes' => old('time_estimate_minutes', $task?->time_estimate_minutes),
                'description' => old('description', $task?->description ?? ''),
                'tags' => old('tags', $task && $task->tags ? implode(', ', $task->tags) : ''),
                'relationship_ids' => old('relationship_ids', $task && $task->relationship_ids ? implode(', ', $task->relationship_ids) : ''),
                'notes' => old('notes', $task?->notes ?? ''),
                'customer_visible' => (bool) old('customer_visible', $task?->customer_visible ?? false),
                'assignees' => array_values(array_filter((array) $selectedAssignees)),
            ],
            'routes' => [
                'index' => route('admin.projects.tasks.index', $project),
                'submit' => $isEdit
                    ? route('admin.projects.tasks.update', [$project, $task])
                    : route('admin.projects.tasks.store', $project),
            ],
        ];
    }

    private function tasksRedirectUrl(Request $request, Project $project): string
    {
        if ($request->filled('return_to')) {
            return (string) $request->input('return_to');
        }

        $statusFilter = (string) ($request->query('status') ?? $request->input('task_status_filter', ''));
        $statusFilter = in_array($statusFilter, ['pending', 'in_progress', 'blocked', 'completed'], true)
            ? $statusFilter
            : null;

        return route('admin.projects.tasks.index', array_filter([
            'project' => $project,
            'status' => $statusFilter,
        ], fn ($value) => $value !== null && $value !== ''));
    }

    private function parseAssignee(string $value): array
    {
        [$type, $id] = array_pad(explode(':', $value, 2), 2, null);
        $id = $id ? (int) $id : null;

        if (! $type || ! $id) {
            abort(422, 'Invalid assignee');
        }

        if ($type === 'employee' && ! Employee::whereKey($id)->exists()) {
            abort(422, 'Employee not found');
        }

        if ($type === 'sales_rep' && ! SalesRepresentative::whereKey($id)->exists()) {
            abort(422, 'Sales representative not found');
        }

        return [$type, $id];
    }

    private function combineDescriptions(array $data): ?string
    {
        if (! empty($data['descriptions']) && is_array($data['descriptions'])) {
            $description = implode("\n", array_filter($data['descriptions']));

            return $description !== '' ? $description : null;
        }

        return $data['description'] ?? null;
    }

    private function parseTags(?string $tags, array $fallback = []): array
    {
        if ($tags === null) {
            return $fallback;
        }

        $parsed = array_filter(array_map('trim', explode(',', $tags)));

        return array_values(array_unique($parsed));
    }

    private function parseRelationships(?string $relationships, array $fallback = []): array
    {
        if ($relationships === null) {
            return $fallback;
        }

        $ids = array_filter(array_map('trim', explode(',', $relationships)));
        $ids = array_values(array_unique(array_filter($ids, fn ($id) => is_numeric($id))));

        return array_map('intval', $ids);
    }

    private function storeAttachment(Request $request, ProjectTask $task): ?string
    {
        if (! $request->hasFile('attachment')) {
            return null;
        }

        $file = $request->file('attachment');
        $name = pathinfo((string) $file->getClientOriginalName(), PATHINFO_FILENAME);
        $name = $name !== '' ? Str::slug($name) : 'attachment';
        $extension = $file->getClientOriginalExtension();
        $fileName = $name.'-'.Str::random(8).'.'.$extension;

        return $file->storeAs('project-task-activities/'.$task->id, $fileName, 'public');
    }

    private function taskHasUploadFiles(ProjectTask $task): bool
    {
        try {
            $files = Storage::disk('public')->files('project-task-activities/'.$task->id);
        } catch (\Throwable) {
            return false;
        }

        return ! empty($files);
    }

    public function deleteAttachment(Request $request, Project $project, ProjectTask $task)
    {
        $this->ensureTaskBelongsToProject($project, $task);
        $this->authorize('update', $task);

        $pathToDelete = $request->input('path');
        if (! $pathToDelete) {
            return back()->withErrors(['task' => 'Attachment path is required.']);
        }

        $allPaths = $task->allAttachmentUrls();
        $updatedPaths = array_values(array_filter($allPaths, fn ($p) => $p !== $pathToDelete));

        if (Storage::disk('public')->exists($pathToDelete)) {
            Storage::disk('public')->delete($pathToDelete);
        }

        $task->update(['attachment_paths' => $updatedPaths]);

        if ($request->wantsJson()) {
            return response()->json(['message' => 'Task attachment deleted.', 'attachment_paths' => $updatedPaths]);
        }

        return back()->with('status', 'Task attachment deleted.');
    }
}
