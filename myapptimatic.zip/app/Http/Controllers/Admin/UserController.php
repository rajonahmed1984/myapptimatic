<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Role;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreSupportUserRequest;
use App\Models\User;
use App\Support\AjaxResponse;
use App\Support\PublicStorageUrl;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response as InertiaResponse;

class UserController extends Controller
{
    public function index(string $role): InertiaResponse
    {
        $role = $this->normalizeRole($role);
        $roles = $this->adminRoles();
        $users = User::query()
            ->whereIn('role', array_keys($roles))
            ->when($role, fn ($q) => $q->where('role', $role))
            ->orderBy('name')
            ->get();

        return Inertia::render(
            'Admin/Users/Index',
            $this->indexInertiaProps($users, $role, $roles)
        );
    }

    public function create(string $role): InertiaResponse
    {
        $role = $this->normalizeRole($role);

        return Inertia::render(
            'Admin/Users/Form',
            $this->formInertiaProps(
                user: null,
                selectedRole: $role,
                roles: $this->adminRoles()
            )
        );
    }

    public function store(Request $request, string $role): RedirectResponse|JsonResponse
    {
        $role = $this->normalizeRole($role);

        $data = $this->validateStoreRequest($request, $role);

        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'role' => $role,
            'customer_id' => null,
        ]);

        $uploadPaths = $this->handleUploads($request, $user);
        if (! empty($uploadPaths)) {
            $user->update($uploadPaths);
        }

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                route('admin.users.index', $role),
                'User created.'
            );
        }

        return redirect()->route('admin.users.index', $role)->with('status', 'User created.');
    }

    public function edit(User $user): InertiaResponse
    {
        $this->abortIfNotAdminRole($user);

        return Inertia::render(
            'Admin/Users/Form',
            $this->formInertiaProps(
                user: $user,
                selectedRole: (string) old('role', $user->role),
                roles: $this->adminRoles()
            )
        );
    }

    public function update(Request $request, User $user): RedirectResponse|JsonResponse
    {
        $this->abortIfNotAdminRole($user);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
            'role' => ['required', Rule::in(array_keys($this->adminRoles()))],
            'avatar' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'nid_file' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:10240'],
            'cv_file' => ['nullable', 'file', 'mimes:pdf', 'max:10240'],
        ]);

        // Prevent self from downgrading own role to avoid lockout.
        if ($request->user()?->id === $user->id && $data['role'] !== $user->role) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('You cannot change your own role.', 422);
            }

            return back()->withInput()->with('status', 'You cannot change your own role.');
        }

        if ($user->role === 'master_admin' && $data['role'] !== 'master_admin') {
            $otherMasters = User::query()
                ->where('role', 'master_admin')
                ->where('id', '!=', $user->id)
                ->count();

            if ($otherMasters === 0) {
                if (AjaxResponse::ajaxFromRequest($request)) {
                    return AjaxResponse::ajaxError('At least one master admin must remain.', 422);
                }

                return back()->withInput()->with('status', 'At least one master admin must remain.');
            }
        }

        $updates = [
            'name' => $data['name'],
            'email' => $data['email'],
            'role' => $data['role'],
        ];

        if (! empty($data['password'])) {
            $updates['password'] = $data['password'];
        }

        $user->update($updates);

        $uploadPaths = $this->handleUploads($request, $user);
        if (! empty($uploadPaths)) {
            $user->update($uploadPaths);
        }

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                route('admin.users.index', $data['role']),
                'User updated.'
            );
        }

        return redirect()->route('admin.users.index', $data['role'])->with('status', 'User updated.');
    }

    public function destroy(Request $request, User $user): RedirectResponse|JsonResponse
    {
        $this->abortIfNotAdminRole($user);

        if ($request->user()?->id === $user->id) {
            if (AjaxResponse::ajaxFromRequest($request)) {
                return AjaxResponse::ajaxError('You cannot delete your own account.', 422);
            }

            return back()->with('status', 'You cannot delete your own account.');
        }

        if ($user->role === 'master_admin') {
            $otherMasters = User::query()
                ->where('role', 'master_admin')
                ->where('id', '!=', $user->id)
                ->count();

            if ($otherMasters === 0) {
                if (AjaxResponse::ajaxFromRequest($request)) {
                    return AjaxResponse::ajaxError('At least one master admin must remain.', 422);
                }

                return back()->with('status', 'At least one master admin must remain.');
            }
        }

        $deletedRole = $user->role;
        $user->delete();

        if (AjaxResponse::ajaxFromRequest($request)) {
            return AjaxResponse::ajaxRedirect(
                route('admin.users.index', $deletedRole),
                'User deleted.'
            );
        }

        return redirect()->route('admin.users.index', $deletedRole)->with('status', 'User deleted.');
    }

    private function normalizeRole(string $role): string
    {
        if (! array_key_exists($role, $this->adminRoles())) {
            abort(404);
        }

        return $role;
    }

    private function abortIfNotAdminRole(User $user): void
    {
        if (! array_key_exists($user->role, $this->adminRoles())) {
            abort(404);
        }
    }

    private function adminRoles(): array
    {
        return [
            Role::MASTER_ADMIN => 'Master Admin',
            Role::SUB_ADMIN => 'Sub Admin',
            Role::SUPPORT => 'Support',
        ];
    }

    private function validateStoreRequest(Request $request, string $role): array
    {
        if ($role === Role::SUPPORT) {
            return $this->resolveFormRequest(StoreSupportUserRequest::class, $request);
        }

        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'avatar' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'nid_file' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:10240'],
            'cv_file' => ['nullable', 'file', 'mimes:pdf', 'max:10240'],
        ]);
    }

    private function resolveFormRequest(string $class, Request $request): array
    {
        /** @var \Illuminate\Foundation\Http\FormRequest $formRequest */
        $formRequest = $class::createFrom($request);
        $formRequest->setContainer(app())->setRedirector(app('redirect'));
        $formRequest->setUserResolver($request->getUserResolver());
        $formRequest->setRouteResolver($request->getRouteResolver());
        $formRequest->validateResolved();

        return $formRequest->validated();
    }

    private function handleUploads(Request $request, User $user): array
    {
        $paths = [];

        if ($request->hasFile('avatar')) {
            $paths['avatar_path'] = $request->file('avatar')
                ->store('avatars/users/'.$user->id, 'public');
        }

        if ($request->hasFile('nid_file')) {
            $paths['nid_path'] = $request->file('nid_file')
                ->store('nid/users/'.$user->id, 'public');
        }

        if ($request->hasFile('cv_file')) {
            $paths['cv_path'] = $request->file('cv_file')
                ->store('cv/users/'.$user->id, 'public');
        }

        return $paths;
    }

    private function indexInertiaProps($users, string $selectedRole, array $roles): array
    {
        return [
            'pageTitle' => 'Admin Users',
            'selected_role' => $selectedRole,
            'selected_role_label' => $roles[$selectedRole] ?? ucfirst(str_replace('_', ' ', $selectedRole)),
            'roles' => collect($roles)->map(fn ($label, $value) => [
                'value' => (string) $value,
                'label' => (string) $label,
                'route' => route('admin.users.index', $value),
            ])->values()->all(),
            'routes' => [
                'create' => route('admin.users.create', $selectedRole),
            ],
            'users' => $users->values()->map(function (User $user) use ($roles) {
                return [
                    'id' => $user->id,
                    'name' => (string) $user->name,
                    'email' => (string) $user->email,
                    'role' => (string) $user->role,
                    'role_label' => (string) ($roles[$user->role] ?? $user->role),
                    'avatar_url' => $this->fileUrl($user->avatar_path),
                    'routes' => [
                        'edit' => route('admin.users.edit', $user),
                        'destroy' => route('admin.users.destroy', $user),
                    ],
                ];
            })->all(),
        ];
    }

    private function formInertiaProps(?User $user, string $selectedRole, array $roles): array
    {
        $isEdit = $user !== null;
        $selectedRole = $this->normalizeRole($selectedRole);

        return [
            'pageTitle' => $isEdit ? 'Edit User' : 'Create User',
            'is_edit' => $isEdit,
            'roles' => collect($roles)->map(fn ($label, $value) => [
                'value' => (string) $value,
                'label' => (string) $label,
            ])->values()->all(),
            'selected_role' => $selectedRole,
            'selected_role_label' => (string) ($roles[$selectedRole] ?? ucfirst($selectedRole)),
            'form' => [
                'action' => $isEdit
                    ? route('admin.users.update', $user)
                    : route('admin.users.store', $selectedRole),
                'method' => $isEdit ? 'PUT' : 'POST',
                'fields' => [
                    'name' => (string) old('name', (string) ($user?->name ?? '')),
                    'email' => (string) old('email', (string) ($user?->email ?? '')),
                    'role' => (string) old('role', (string) ($user?->role ?? $selectedRole)),
                ],
                'documents' => [
                    'avatar_url' => $isEdit ? $this->fileUrl($user?->avatar_path) : null,
                    'nid_url' => ($isEdit && $user?->nid_path)
                        ? route('admin.user-documents.show', ['type' => 'user', 'id' => $user->id, 'doc' => 'nid'])
                        : null,
                    'cv_url' => ($isEdit && $user?->cv_path)
                        ? route('admin.user-documents.show', ['type' => 'user', 'id' => $user->id, 'doc' => 'cv'])
                        : null,
                ],
            ],
            'routes' => [
                'index' => route('admin.users.index', $selectedRole),
            ],
        ];
    }

    private function fileUrl(?string $path): ?string
    {
        if (! is_string($path) || $path === '') {
            return null;
        }

        return PublicStorageUrl::fromPath($path);
    }
}
