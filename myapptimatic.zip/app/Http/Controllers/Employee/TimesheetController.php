<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use App\Models\Timesheet;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class TimesheetController extends Controller
{
    public function index(Request $request): View
    {
        $employee = $request->attributes->get('employee');

        $timesheets = Timesheet::query()
            ->where('employee_id', $employee->id)
            ->orderByDesc('id')
            ->paginate(15);

        return view('employee.timesheets.index', compact('timesheets'));
    }

    public function store(Request $request): RedirectResponse
    {
        $employee = $request->attributes->get('employee');

        $data = $request->validate([
            'period_start' => ['required', 'date'],
            'period_end' => ['required', 'date', 'after_or_equal:period_start'],
            'total_hours' => ['required', 'numeric', 'min:0'],
            'notes' => ['nullable', 'string', 'max:500'],
        ]);

        Timesheet::create([
            'employee_id' => $employee->id,
            'period_start' => $data['period_start'],
            'period_end' => $data['period_end'],
            'total_hours' => $data['total_hours'],
            'notes' => $data['notes'] ?? null,
            'status' => 'submitted',
            'submitted_at' => now(),
        ]);

        return back()->with('status', 'Timesheet submitted.');
    }
}
