<?php

namespace App\Http\Middleware;

use App\Services\AccessBlockService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

class PreventBlockedClientAccess
{
    public function __construct(
        private AccessBlockService $accessBlockService
    ) {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $customer = $request->user()?->customer;
        $blockStatus = $this->accessBlockService->invoiceBlockStatus($customer);
        $isManualInactiveBlock = ($blockStatus['reason'] ?? null) === 'customer_inactive';

        if (! $isManualInactiveBlock) {
            // Invoice due/overdue should never hard-block client area access.
            $blockStatus['blocked'] = false;
        }

        View::share('clientAccessBlock', $blockStatus);

        if ($isManualInactiveBlock && ! $this->allowsRoute($request)) {
            $message = $blockStatus['reason'] === 'customer_inactive'
                ? 'Your account is inactive. Please contact admin for access.'
                : 'Access is limited. Please contact admin for support.';

            return redirect()->route('client.dashboard')
                ->with('status', $message);
        }

        return $next($request);
    }

    private function allowsRoute(Request $request): bool
    {
        $route = $request->route();
        if (! $route) {
            return true;
        }

        $routeName = $route->getName();
        if (! $routeName) {
            return true;
        }

        $allowedPatterns = [
            'client.dashboard',
            'client.invoices.*',
            'client.support-tickets.*',
        ];

        foreach ($allowedPatterns as $pattern) {
            if (Str::is($pattern, $routeName)) {
                return true;
            }
        }

        return false;
    }
}
